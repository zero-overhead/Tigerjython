# TcpTicTacServer.py

from gamegrid import *
from tcpcom import TCPServer
import tictaclib

def onMousePressed(e):
     global isMyMove
     if not isMyMove or isOver:
          return
     loc = toLocationInGrid(e.getX(), e.getY())
     if getOneActorAt(loc) != None:
        return
     mark = Actor("sprites/mark.gif", 2)
     addActor(mark, loc)
     server.sendMessage(str(loc.x) + str(loc.y)) # send location 
     setStatusText("Wait!")
     mark.show(1)
     tictaclib.checkGameState()
     refresh()
     isMyMove = False

def onNotifyExit():
    server.terminate()
    dispose()
    
def onStateChanged(state, msg):
    global isMyMove, isOver
    if state == TCPServer.CONNECTED:
        setStatusText("Client connected. Wait!")
        isOver = False
    elif state == TCPServer.LISTENING:
        setStatusText("Waiting for a partner...")
    elif state == TCPServer.MESSAGE:
        x = int(msg[0])
        y = int(msg[1])
        loc = Location(x, y)
        mark = Actor("sprites/mark.gif", 2)
        addActor(mark, loc)
        mark.show(0)         
        setStatusText("Make a move!")
        tictaclib.checkGameState()
        refresh()
        isMyMove = True
    
makeGameGrid(3, 3, 70, Color.black, False, mousePressed = onMousePressed, 
             notifyExit = onNotifyExit)
setBgColor(makeColor("greenyellow"))                
addStatusBar(30)
show()
PORT = 5000
server = TCPServer(PORT, onStateChanged)
isOver = False
isMyMove = False


