# fourlib.py

from gamegrid import *

isOver = False

#----------class Token -------------------------------
class Token(Actor):
    def __init__(self, player):
        Actor.__init__(self, "sprites/token.png", 2)
        self.player = player
        self.show(player)
        self.nb = 0 

    def act(self):
        global isOver
        nextLoc = Location(self.getX(), self.getY() + 1)
        if (getOneActorAt(nextLoc) == None and self.isMoveValid()):
            if self.nb == 6:
                self.nb = 0
                self.setLocationOffset(Point(0, 0))
                self.move()
            else:
                self.setLocationOffset(Point(0, 10 * self.nb))
            self.nb = self.nb + 1 
        else:  # arrived
            self.setActEnabled(False)  # old token will stay where it is
            if checkOver(self.getLocation()):
                if self.player == 0:
                    won = "Yellow"
                else:
                    won = "Red"    
                setStatusText("Game Over, player " + won + " won!")             
                isOver = True   

#----------check Game over-------------------------------------
def getId(x, y):
    loc = Location(x, y)
    if getOneActorAt(loc) == None:
        return -1
    else:
        return getOneActorAt(loc).getIdVisible()

#check for four
def checkDiagonal(col, row):
    for j in range(4):
        nb = 0
        for i in range(4):
            if (col + i - j) >= 0 and (col + i - j) < 7 and (row + i - j) >= 1 \
               and (row + i - j) < 7 \
               and getId(col + i - j, row + i - j) == getId(col, row):
                nb = nb + 1
        if nb >= 4:
            return True
    return False

def checkDiagonal2(col, row):
    for j in range(4):
        nb = 0
        for i in range(4):
            if (col - i + j) >= 0 and (col - i + j) < 7 \
               and (row + i - j) >= 1 and (row + i - j) < 7 \
               and getId(col - i + j, row + i - j) == getId(col, row):
                 nb = nb + 1
        if nb >= 4:
            return True
    return False

def checkHorizontal(col, row):
    nb = 1
    i = 1
    while col - i >= 0 and getId(col - i, row) == getId(col, row):
        nb = nb + 1
        i += 1
    i = 1
    while col + i < 7 and getId(col + i, row) == getId(col, row):
        nb = nb + 1
        i += 1
    return nb >= 4

def checkVertical(col, row):
    nb = 1
    i = 1
    while row + i < 7 and getId(col, row + i) == getId(col, row):
       nb = nb + 1
       i += 1
    return nb >= 4

#return true, if four in a row
def checkOver(loc):
    col = loc.x
    row = loc.y
    return (checkVertical(col, row) 
      or checkHorizontal(col, row)
      or checkDiagonal(col, row)
      or checkDiagonal2(col, row)) 