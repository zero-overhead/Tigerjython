# TcpTicClient

from gamegrid import *
from tcpcom import TCPClient

def onMousePressed(e):
     global isMyMove
     if not isMyMove or isOver:
          return
     loc = toLocationInGrid(e.getX(), e.getY())
     if getOneActorAt(loc) != None:
        return
     mark = Actor("sprites/mark.gif", 2)
     addActor(mark, loc)
     client.sendMessage(str(loc.x) + str(loc.y)) # send location 
     setStatusText("Wait!")
     mark.show(0)     
     checkGameState()
     refresh()
     isMyMove = False
     
def setPattern(x, y):
    global pattern
    loc = Location(x, y)
    a = getOneActorAt(loc)
    if a == None:
        pattern += '-'
    elif a.getIdVisible() == 0:
        pattern += 'O'
    elif a.getIdVisible() == 1:
        pattern += 'X'
       
def checkGameState():
    # Convert board state into string pattern
    global pattern
    pattern = ""
    # Horizontal
    for y in range(3):
        for x in range(3):
            setPattern(x, y)
        pattern += ','  # Separator
    # Vertical
    for x in range(3):
        for y in range(3):
            setPattern(x, y)
        pattern += ','
    # Diagonal
    for x in range(3):
      setPattern(x, x);
    pattern += ','
    for x in range(3):
      setPattern(x, 2 - x);

    if "XXX" in pattern:
        setStatusText("X  won")
    elif "OOO" in pattern:
        setStatusText("O  won")
    elif not "-" in pattern:
        setStatusText("Board full")        
     
def onStateChanged(state, msg):
    global isMyMove
    if state == TCPClient.CONNECTED:
        setStatusText("Connection established. You play!")
    elif state == TCPClient.CONNECTION_FAILED:
        setStatusText("Connection failed")
    elif state == TCPClient.DISCONNECTED:
        setStatusText("Server died")
        isMyMove = False
    elif state == TCPClient.MESSAGE:
        x = int(msg[0])
        y = int(msg[1])
        loc = Location(x, y)
        mark = Actor("sprites/mark.gif", 2)
        addActor(mark, loc)
        mark.show(1)        
        setStatusText("Make a move!")        
        checkGameState()
        refresh()
        isMyMove = True

def onNotifyExit():
    client.disconnect()
    dispose()

makeGameGrid(3, 3, 70, Color.black,False, 
    mousePressed = onMousePressed, notifyExit = onNotifyExit)
setBgColor(makeColor("greenyellow"))    
addStatusBar(30)
nbShip = 8
show()
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
client.connect()
isMyMove = True
isOver = False

