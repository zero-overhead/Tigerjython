# FourClient.py

from gamegrid import *
from tcpcom import TCPClient
import fourlib                                                                            
       
def onMousePressed(e):
    global isMyMove, location
    if not isMyMove or fourlib.isOver:
        return
    location = toLocationInGrid(e.getX(), e.getY())
    token = fourlib.Token(0)
    addActor(token, location, Location.SOUTH)  
    token.setActEnabled(True)   
    client.sendMessage(str(location.x)) 
    setStatusText("Wait!")        
           
def onNotifyExit():
    client.disconnect()
    dispose()
   
def onStateChanged(state, msg):
    global isMyMove, location
    if state == TCPClient.CONNECTED:
        setStatusText("Connection established. You play!")
        isMyMove = True
    elif state == TCPClient.CONNECTION_FAILED:
        setStatusText("Connection failed")
    elif state == TCPClient.DISCONNECTED:
        setStatusText("Server died")
        isMyMove = False
    elif state == TCPClient.MESSAGE:        
        x = int(msg[0])           
        location = Location(x, 0)           
        token = fourlib.Token(1)
        addActor(token, location, Location.SOUTH)
        token.setActEnabled(True)
        isMyMove = True
        setStatusText("Make your move!")

makeGameGrid(7, 7, 70, None, "sprites/connectbg.png", False,
     mousePressed = onMousePressed, notifyExit = onNotifyExit)
setBgColor(makeColor("white"))
isMyMove = False 
addStatusBar(30)
show()
setSimulationPeriod(30)
doRun()
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
client.connect()

