# TcpShipClient

from gamegrid import *
from tcpcom import TCPClient

class Ship(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/boat.gif")

def onMousePressed(e):
     global isMyMove
     if not isMyMove or isOver:
          return
     loc = toLocationInGrid(e.getX(), e.getY())
     addActor(Actor("sprites/checkred.gif"), loc)
     client.sendMessage(str(loc.x) + str(loc.y)) # send location 
     setStatusText("Wait!")
     isMyMove = False
     
def onStateChanged(state, msg):
    global isMyMove, myHits, partnerHits, isOver, loc       
    if state == TCPClient.CONNECTED:
        setStatusText("Connection established. You play!")
    elif state == TCPClient.CONNECTION_FAILED:
        setStatusText("Connection failed")
    elif state == TCPClient.DISCONNECTED:
        setStatusText("Server died")
        isMyMove = False
    elif state == TCPClient.MESSAGE:
        if msg == "hit":
            myHits += 1
            setStatusText("Hit! Partner's fleet size " + str(nbShip - myHits) 
                + ". Wait!")            
            if myHits == nbShip:
                setStatusText("Game over, You won!")
                isOver = True        
        elif msg == "miss":
            setStatusText("Miss! Partner's fleet size " + str(nbShip - myHits)
               + ". Wait!")            
        else:
            x = int(msg[0])
            y = int(msg[1])
            loc = Location(x, y)
            actor = getOneActorAt(loc, Ship)         
            if actor != None:
                actor.removeSelf()     
                refresh()
                client.sendMessage("hit")
                partnerHits += 1             
                if partnerHits == nbShip:
                    setStatusText("Game over! Partner won")
                    isOver = True 
                    return  
            else:
                client.sendMessage("miss")
            setStatusText("You play! Partner's fleet size " + str(nbShip - myHits))            
            isMyMove = True

def onNotifyExit():
    client.disconnect()
    dispose()

makeGameGrid(5, 5, 50, Color.red, False, 
    mousePressed = onMousePressed, notifyExit = onNotifyExit)
addStatusBar(30)
nbShip = 8
for i in range(nbShip):
    addActor(Ship(), getRandomEmptyLocation())
show()
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
client.connect()
isMyMove = True
isOver = False
myHits = 0
partnerHits = 0

