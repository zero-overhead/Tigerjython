# TcpTicTacClient

from gamegrid import *
from tcpcom import TCPClient
import tictaclib

def onMousePressed(e):
     global isMyMove
     if not isMyMove or isOver:
          return
     loc = toLocationInGrid(e.getX(), e.getY())
     if getOneActorAt(loc) != None:
        return
     mark = Actor("sprites/mark.gif", 2)
     addActor(mark, loc)
     client.sendMessage(str(loc.x) + str(loc.y)) # send location 
     setStatusText("Wait!")
     mark.show(0)     
     tictaclib.checkGameState()
     refresh()
     isMyMove = False
     
def onStateChanged(state, msg):
    global isMyMove
    if state == TCPClient.CONNECTED:
        setStatusText("Connection established. You play!")
    elif state == TCPClient.CONNECTION_FAILED:
        setStatusText("Connection failed")
    elif state == TCPClient.DISCONNECTED:
        setStatusText("Server died")
        isMyMove = False
    elif state == TCPClient.MESSAGE:
        x = int(msg[0])
        y = int(msg[1])
        loc = Location(x, y)
        mark = Actor("sprites/mark.gif", 2)
        addActor(mark, loc)
        mark.show(1)        
        setStatusText("Make a move!")        
        tictaclib.checkGameState()
        refresh()
        isMyMove = True

def onNotifyExit():
    client.disconnect()
    dispose()

makeGameGrid(3, 3, 70, Color.black, False, mousePressed = onMousePressed,
             notifyExit = onNotifyExit)
setBgColor(makeColor("greenyellow"))   
addStatusBar(30)
nbShip = 8
show()
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
client.connect()
isMyMove = True
isOver = False

