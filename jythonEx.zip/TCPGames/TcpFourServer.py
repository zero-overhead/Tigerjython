# TcpFourServer.py

from gamegrid import *
from tcpcom import TCPServer
import fourlib                                                                    

def onMousePressed(e):
    global isMyMove, location
    if not isMyMove or fourlib.isOver:
          return
    location = toLocationInGrid(e.getX(), e.getY())
    token = fourlib.Token(1)
    addActor(token, location, Location.SOUTH)
    server.sendMessage(str(location.x)) # send location
    isMyMove = False
    setStatusText("Wait!")    

def onNotifyExit():
    server.terminate()
    dispose()
    
def onStateChanged(state, msg):
    global isMyMove, location
    if state == TCPServer.PORT_IN_USE:
        setStatusText("TCP port occupied. Restart IDE.")
    if state == TCPServer.LISTENING:
        setStatusText("Waiting for a partner to play")        
    if state == TCPServer.CONNECTED:
        setStatusText("Client connected. Wait for partner's move!")
    elif state == TCPServer.MESSAGE:        
        x = int(msg[0])        
        location = Location(x, 0)            
        token = fourlib.Token(0)
        addActor(token, location, Location.SOUTH)           
        isMyMove = True
        setStatusText("Make your move!")
    
makeGameGrid(7, 7, 70, None, "sprites/connectbg.png", False,
    mousePressed = onMousePressed, notifyExit = onNotifyExit)
setBgColor(makeColor("white"))
addStatusBar(30)
isMyMove = False 
show()
setSimulationPeriod(30)
doRun()
port = 5000
server = TCPServer(port, stateChanged = onStateChanged)





