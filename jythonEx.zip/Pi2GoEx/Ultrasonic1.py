# Ultrasonic1.py

from raspibrick import *

robot = Robot()
gear = Gear()
us = UltrasonicSensor()
gear.forward()

while not isEscapeHit():
    v = us.getDistance()
    print v
    if v < 20: 
        gear.left(550)
        gear.forward()
robot.exit()

