# Motor3.py

from raspibrick import *
# from raspisim import *

robot = Robot()
gear = Gear()
gear.forward()
Tools.delay(2000)
robot.exit()
