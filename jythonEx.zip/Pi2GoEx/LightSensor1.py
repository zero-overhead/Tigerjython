# LightSensor1.py

from raspibrick import *

robot = Robot()
gear = Gear()
ls = LightSensor(LS_FRONT_RIGHT)
gear.leftArc(0.15)
isBright = False

while not robot.isEscapeHit():
    v = ls.getValue()
    print v
    if  v > 950 and not isBright:  
        isBright = True
        Led.setColorAll(255, 0, 0) 
        gear.stop()
        Tools.delay(1500) 
        Led.clearAll()       
        gear.leftArc(0.15)
    if v < 900 and isBright:
        isBright = False                          
robot.exit()

