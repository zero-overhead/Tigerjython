# IRSensor2.py

from raspisim import *
#from raspibrick import *

RobotContext.useObstacle("sprites/racetrack.gif", 250, 250);
RobotContext.setStartPosition(420, 460)

robot = Robot()
gear = Gear()
irL = InfraredSensor(IR_LEFT)
irR = InfraredSensor(IR_RIGHT)
gear.forward()

while not isEscapeHit():
    vL = irL.getValue()
    vR = irR.getValue()
    if vL == 1:
        gear.backward(250)
        gear.right(180)
        gear.forward() 
    elif vR == 1:        
        gear.backward(250)
        gear.left(180)
        gear.forward()           
robot.exit()
