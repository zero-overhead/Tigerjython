# ChangeDirection2.py

from raspibrick import *
# from raspisim import *

robot = Robot()
gear = Gear()
gear.setSpeed(60)
gear.rightArc(0.15, 2000)
gear.leftArc(0.15, 3600)
robot.exit()

