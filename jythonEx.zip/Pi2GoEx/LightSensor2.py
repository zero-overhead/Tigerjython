# LightSensor2.py

from raspibrick import *

robot = Robot()
gear = Gear()
lsL = LightSensor(LS_FRONT_LEFT)
lsR = LightSensor(LS_FRONT_RIGHT)
gear.setSpeed(25)
gear.forward()
s = 0.1
while not isEscapeHit():
    vL = lsL.getValue()
    vR = lsR.getValue()
    print vL, vR
    d = (vL - vR) / (vL + vR)
    if d > -s and d < s:
        gear.forward()
    else:
        if d >= s:
            gear.leftArc(0.1)
        else:
            gear.rightArc(0.1)            
robot.exit()

