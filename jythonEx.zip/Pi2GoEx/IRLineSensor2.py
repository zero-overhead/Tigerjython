# IRLineSensor2.py

from raspisim import *
#from raspibrick import *

RobotContext.useBackground("sprites/border.gif")
RobotContext.setStartPosition(250, 490)

robot = Robot()
gear = Gear()
gear.setSpeed(30)
ir_left = InfraredSensor(IR_LINE_LEFT)
ir_right = InfraredSensor(IR_LINE_RIGHT)
gear.forward()

while not isEscapeHit():
    v1 = ir_left.getValue()
    v2 = ir_right.getValue()
    if v1 == 1 and v2 == 0:
        gear.forward()
    elif v1 == 1 and v2 == 1:   
        gear.rightArc(0.1)
    elif v1 == 0 and v2 == 0:
        gear.leftArc(0.1)    
robot.exit()

