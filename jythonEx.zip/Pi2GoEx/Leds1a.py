# Leds1a.py

from raspibrick import *

robot = Robot()
ledFront = Led(LED_FRONT)
ledLeft = Led(LED_LEFT)
ledRight = Led(LED_RIGHT)
ledRear = Led(LED_REAR)
ledFront.setColor("red")
Tools.delay(2000)
ledRear.setColor("green")
Tools.delay(2000)
ledLeft.setColor("yellow")
ledRight.setColor(255, 255, 0)
Tools.delay(2000)
Led.setColorAll("white")
Tools.delay(2000)
robot.exit()
