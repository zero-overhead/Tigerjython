# Ultrasonic4.py

from raspisim import *

mesh_hbar = [[200, 10], [-200, 10], [-200, -10], [200, -10]]
mesh_vbar = [[10, 200], [-10, 200], [-10, -200], [10, -200]]
RobotContext.useTarget("sprites/bar0.gif", mesh_hbar, 250, 100)
RobotContext.useTarget("sprites/bar0.gif", mesh_hbar, 250, 400)
RobotContext.useTarget("sprites/bar1.gif", mesh_vbar, 100, 250)
RobotContext.useTarget("sprites/bar1.gif", mesh_vbar, 400, 250)

def onNear(d):
    print d
    gear.left(900)
    gear.forward()

robot = Robot()
gear = Gear()
us = UltrasonicSensor(near = onNear)
us.setBeamAreaColor(Color.green)
us.setProximityCircleColor(Color.lightGray)
us.setTriggerLevel(30)
gear.setSpeed(30)
gear.forward()
   
while not isEscapeHit():
    continue
robot.exit()
   

