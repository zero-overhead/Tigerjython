# Leds3.py

from raspisim import *
#from raspibrick import *
import thread

def blinker(period):
    while isRunning:
        if isLeftBlinking:
           ledLeft.setColor("white")
           Tools.delay(period // 2)
           ledLeft.setColor("black")
        if isRightBlinking:
           ledRight.setColor("white")
           Tools.delay(period // 2)
           ledRight.setColor("black")
        Tools.delay(period // 2)
    print "Thread finished"    

robot = Robot()
gear = Gear()
gear.setSpeed(25)
ledLeft = Led(LED_LEFT)
ledRight = Led(LED_RIGHT)
isLeftBlinking = False
isRightBlinking = False    
isRunning = True
thread.start_new_thread(blinker, (500,))
    
while not isEscapeHit():
    if isLeftHit():
        isLeftBlinking = True
        isRightBlinking = False 
        gear.leftArc(0.1)      
    if isRightHit():
        isLeftBlinking = False
        isRightBlinking = True 
        gear.rightArc(0.1)  
    if isUpHit():
        isLeftBlinking = False
        isRightBlinking = False 
        gear.forward()          
    if isEnterHit():
        isLeftBlinking = False
        isRightBlinking = False
isRunning = False
robot.exit()

