# LightSensor1a.py

from raspisim import *

RobotContext.useTorch(1, 150, 250, 100)
RobotContext.setStartPosition(350, 250)
  
robot = Robot()
gear = Gear()
ls = LightSensor(LS_FRONT_RIGHT)
gear.leftArc(0.5)
isBright = False

while not isEscapeHit():
    v = ls.getValue()
    print v
    if v > 950 and not isBright:
        isBright = True
        Led.setColorAll(255, 255, 0)  
        gear.stop()
        Tools.delay(1500)
        Led.clearAll()        
        gear.leftArc(0.5)
    if v < 900 and isBright:       
        isBright = False 
robot.exit()

