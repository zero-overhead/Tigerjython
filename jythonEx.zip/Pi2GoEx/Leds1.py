# Leds1.py

#from raspisim import *
from raspibrick import *

robot = Robot()
ledFront = Led(LED_FRONT)
ledLeft = Led(LED_LEFT)
ledRight = Led(LED_RIGHT)
ledRear = Led(LED_REAR)
    
while not isEscapeHit():
    if isUpHit():
        Led.clearAll()
        ledFront.setColor("white")    
    if isLeftHit():
        Led.clearAll()
        ledLeft.setColor("yellow") 
    if isRightHit():
        Led.clearAll()
        ledRight.setColor("yellow")                
    if isDownHit():
        Led.clearAll()
        ledRear.setColor("red")         
robot.exit()

