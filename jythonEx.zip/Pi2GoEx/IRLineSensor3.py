# IRLineSensor3.py

from raspisim import *
#from raspibrick import *

RobotContext.useBackground("sprites/track.gif")

robot = Robot()
gear = Gear()
gear.setSpeed(20)
ir_right = InfraredSensor(IR_LINE_RIGHT)
ir_left = InfraredSensor(IR_LINE_LEFT)
gear.forward()

while not isEscapeHit():
    v1 = ir_right.getValue()
    v2 = ir_left.getValue()
    print v1, v2
    if v1 == 0 and v2 == 0:
        gear.forward()
    elif v1 == 1 and v2 == 0:
        gear.leftArc(0.06)
    elif v1 == 0 and v2 == 1:    
        gear.rightArc(0.06)                
robot.exit()

