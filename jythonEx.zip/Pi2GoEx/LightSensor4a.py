# LightSensor4a.py

from raspisim import *

RobotContext.useTorch(1, 250, 220, 100)
RobotContext.useShadow(110, 170, 390, 330)
RobotContext.setStartPosition(50, 250)
RobotContext.setStartDirection(0)
  
robot = Robot()
gear = Gear()
gear.setSpeed(25)
ls1 = LightSensor(LS_REAR_LEFT)
ls2 = LightSensor(LS_REAR_RIGHT)
ledFront = Led(LED_FRONT)
ledRear = Led(LED_REAR)
gear.forward()
isOn = False

while not isEscapeHit():
    v1 = ls1.getValue()
    v2 = ls2.getValue() 
    print v1, v2
    if (v1 == 0 or v2 == 0) and not isOn: 
        ledFront.setColor(255, 255, 255)
        ledRear.setColor(255, 0, 0)
        isOn = True
    if (v1 > 0 or v2 > 0) and isOn:
        Led.clearAll()       
        isOn = False     
robot.exit()   