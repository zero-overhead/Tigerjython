# Cam2.py, remote and and autonomous

from raspibrick import *
from gpanel import *

robot = Robot()
camera = Camera()

width = 640
height = 480
makeGPanel(Size(width - 2, height - 2))
window(0, width, 0, height)
for pos in range(-50, 55, 10):
    camera.setHorzPos(pos)
    jpeg = camera.captureAndTransfer(width, height)
    img = readImage(jpeg)
    image(img, -1, -1)
    Tools.delay(2000)
camera.setHorzPos(0)

camera.setPos(45, 45)
Tools.delay(3000)
robot.exit()

