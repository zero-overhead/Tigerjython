# Repeat3.py

from raspisim import *
#from raspibrick import *

robot = Robot()
gear = Gear()
gear.setSpeed(70)
while not isEscapeHit():
    gear.leftArc(0.2)
robot.exit()