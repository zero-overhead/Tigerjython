# Ultrasonic2.py

from raspisim import *
#from raspibrick import *

mesh = [[50, 0], [25, 43], [-25, 43], [-50, 0], 
          [-25, -43], [25, -43]] 
RobotContext.useTarget("sprites/redtarget.gif", 
          mesh, 400, 400)

def searchTarget():
    global left, right
    found = False
    step = 0
    while not robot.isEscapeHit():  
        gear.right(50)
        step = step + 1
        dist = us.getDistance()
        if dist != -1:
            if not found:
                found = True
                left = step
        else:
            if found:    
                right = step
                break

robot = Robot()
gear = Gear()
us = UltrasonicSensor()
us.setBeamAreaColor(Color.green)  
us.setProximityCircleColor(Color.lightGray)
gear.setSpeed(10)
searchTarget()

gear.left((right - left) * 25)
gear.forward()

while not isEscapeHit()and gear.isMoving(): 
    dist = us.getDistance()
    print dist  
    if dist <= 50:
        gear.stop()      
robot.exit()



