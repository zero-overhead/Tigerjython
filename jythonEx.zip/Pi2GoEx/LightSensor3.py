# Lightsensor3.py

from raspisim import *
  
robot = Robot()
gear = Gear()
ls = [0] * 4
for i in range(4):
   ls[i] = LightSensor(i)
gear.setSpeed(20)
gear.forward()
s = 0.1
isTurning = False
v = [0] * 4
while not isEscapeHit():
    for i in range(4):
        v[i] = ls[i].getValue()
    d = (v[0] - v[1]) / (v[0] + v[1])
    if v[2] + v[3] > v[0] + v[1]:  
        if not isTurning:
            if v[2] > v[3]:
                gear.right()
            else:
                gear.left()
            isTurning = True
    else:
        isTurning = False
        if d > -s and d < s:
            gear.forward()
        else:
            if d >= s:
                gear.leftArc(0.1)
            else:
                gear.rightArc(0.1)
robot.exit()   

