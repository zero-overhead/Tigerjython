# ChangeDirection1.py

from raspibrick import *
#from raspisim import *

robot = Robot()
gear = Gear()
gear.forward(2000)
gear.left(550)
gear.forward(2000)
robot.exit()
