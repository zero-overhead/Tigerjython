# Leds2.py

from raspibrick import *

robot = Robot()

while not robot.isEscapeHit():
    for i in range(3):
        Led.setColorAll("green")
        Tools.delay(300)     
        Led.clearAll()
        Tools.delay(300)
    for i in range(3):
        Led.setColorAll("red")
        Tools.delay(1500)      
        Led.clearAll()
        Tools.delay(300)
robot.exit()

