# KeyControl2.py

from raspisim import *
#from raspibrick import *

robot = Robot()
gear = Gear()
gear.setSpeed(20)

while not isEscapeHit():
    if isUpHit():
        gear.forward()
    elif isDownHit():
        gear.stop()
    elif isLeftHit():
        gear.left()
    elif isRightHit():
        gear.right()      
robot.exit()
