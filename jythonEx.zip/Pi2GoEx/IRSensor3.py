# IRSensor3.py

from raspisim import *
#from raspibrick import *

RobotContext.useObstacle("sprites/bar0.gif", 250, 100)
RobotContext.useObstacle("sprites/bar0.gif", 250, 400)
RobotContext.useObstacle("sprites/bar1.gif", 100, 250)
RobotContext.useObstacle("sprites/bar1.gif", 400, 250)
RobotContext.setStartPosition(350, 200)

def onActivated(id):
    gear.backward(600)
    gear.left(550)
    gear.forward()

robot = Robot()
ir_left = InfraredSensor(IR_CENTER, activated = onActivated)
gear = Gear()
gear.forward()

while not isEscapeHit():
    Tools.delay(100)   
robot.exit()