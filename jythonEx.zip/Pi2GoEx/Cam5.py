# Cam5.py, autonomous mode

from raspibrick import *
from gpanel import *

robot = Robot()
camera = Camera()

n = 1
for pos in range(-50, 55, 10):
    camera.setHorzPos(pos)
    filename = "home/pi/shot" + str(n) + ".jpg"
    jpeg = camera.captureAndSave(320, 240, filename)
    Tools.delay(2000)
    n += 1
camera.setHorzPos(0)
Tools.delay(3000)
robot.exit()

