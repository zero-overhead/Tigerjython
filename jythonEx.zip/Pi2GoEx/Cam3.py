# Cam3.py, remote mode

from raspibrick import *
from gpanel import *

def takeSnapshot():
    jpeg = camera.captureAndTransfer(width, height)
    img = readImage(jpeg)
    if img != None:
        image(img, 0, 0)

width = 640
height = 480

robot = Robot()
gear = Gear()
gear.setSpeed(30)
camera = Camera()
makeGPanel(Size(width, height))
window(0, width, 0, height)
takeSnapshot()
horzPos = 0
vertPos = 0
while robot.isConnected():
    doMove = False
    c = getKeyCode()
    if c == 65535:
        continue
    print c
    if c == 38 and vertPos < 50:     
        vertPos += 10
        doMove = True
    elif c == 40 and vertPos > - 50:
        vertPos -= 10
        doMove = True
    elif c == 37 and horzPos < 50:
        horzPos += 10
        doMove = True
    elif c == 39 and horzPos > - 50:
        horzPos -= 10
        doMove = True
    elif c == 65:  # a
        gear.leftArc(0.1)
    elif c == 87:  # w 
        gear.forward()
    elif c == 83:  # s 
        gear.rightArc(0.1)
    elif c == 88:  # x 
        gear.stop()
    elif c == 81:  # q    
       takeSnapshot()
    if doMove:
        camera.setPos(horzPos, vertPos)
robot.exit()

