# Motor1.py

from raspibrick import *
# from raspisim import *

robot = Robot()
mot1 = Motor(MOTOR_LEFT)
mot2 = Motor(MOTOR_RIGHT)
mot1.forward()
mot2.forward()
Tools.delay(2000)
robot.exit()
