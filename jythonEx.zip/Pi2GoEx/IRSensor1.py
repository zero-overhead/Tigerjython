# IRSensor1.py

from raspisim import *
#from raspibrick import *

RobotContext.useObstacle("sprites/field1.gif", 250, 250)

robot = Robot()
gear = Gear()
ir = InfraredSensor(IR_CENTER)
gear.forward()

while not robot.isEscapeHit():
    if ir.getValue() == 1:
        gear.backward(500)
        gear.left(550)
        gear.forward()        
robot.exit()

