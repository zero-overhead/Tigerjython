# LightSensor4.py

from raspibrick import *

robot = Robot()
gear = Gear()
ls1 = LightSensor(LS_REAR_LEFT)
ls2 = LightSensor(LS_REAR_RIGHT)
ledFront = Led(LED_FRONT)
ledRear = Led(LED_REAR)
gear.setSpeed(20)
gear.forward()
isOn = False

while not isEscapeHit():
    v1 = ls1.getValue()
    v2 = ls2.getValue() 
    print v1, v2
  
    if (v1 < 500 or v2 < 500) and not isOn: 
        ledFront.setColor(255, 255, 255)
        ledRear.setColor(20, 0, 0)
        isOn = True
        Tools.delay(100) 
     
    if (v1 > 600 or v2 > 600) and isOn:
        Led.clearAll()       
        isOn = False 
        Tools.delay(100)                  
robot.exit()
