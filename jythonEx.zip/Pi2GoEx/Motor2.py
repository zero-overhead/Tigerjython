# Motor2.py

from raspibrick import *
# from raspisim import *

robot = Robot()
gear = Gear()
gear.forward(3000)
robot.exit()
