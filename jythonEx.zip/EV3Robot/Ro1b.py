# Ro1b.py

from ev3robot import *
#from nxtrobot import *
  
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.forward(2000)
gear.left(600)
gear.forward(2000)
robot.exit()
