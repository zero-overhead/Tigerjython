#Ro17b.py

from ev3robot import *

html = """<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="3">
  </head>
  <body> 
    <h2>Sensirion Sensor</H2> 
    Current temperature: %s <br><br>Current humidity: %s
  </body>
</html>
"""

def onRequest(clientIP, state, params):
   temp, humi = sht.getValues()
   return html %(temp, humi)


robot = LegoRobot()
sht = SHTSensor(SensorPort.S1)
robot.addPart(sht)
server = HTTPServer(requestHandler = onRequest, port = 81)

while not robot.isEscapeHit():
    Tools.delay(100) 
server.terminate()
robot.exit()