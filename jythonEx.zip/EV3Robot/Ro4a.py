# Ro4a.py

from ev3robot import *
#from nxtrobot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ts = TouchSensor(SensorPort.S3)
robot.addPart(ts)
gear.setSpeed(30)
gear.forward()

while not robot.isEscapeHit():    
  if ts.isPressed():
      gear.backward(1500)
      gear.left(600)
      gear.forward()
robot.exit()
