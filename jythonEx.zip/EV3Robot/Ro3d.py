# Ro3d.py

from ev3robot import *
#from nxtrobot import *
  
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ls1 = LightSensor(SensorPort.S1)
robot.addPart(ls1)
ls1.activate(True)
ls2 = LightSensor(SensorPort.S2)
robot.addPart(ls2)
ls2.activate(True)
gear.setSpeed(20)
gear.forward()

while not robot.isEscapeHit():
   rightValue = ls1.getValue()
   leftValue = ls2.getValue()
   d = rightValue - leftValue
   if d < -100:  
      gear.rightArc(0.1)
   if d > 100: 
      gear.leftArc(0.1)
   if (d > -100 and d < 100):
       if rightValue < 500:
           gear.forward()
       else:
           gear.backward() 
robot.exit()

