# Ro7a.py

from ev3robot import *
#from nxtrobot import *
                                 
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
cs = ColorSensor(SensorPort.S3)
robot.addPart(cs)
gear.setSpeed(10)
gear.forward()

while not robot.isEscapeHit():
   c = cs.getColorStr()
   print(c)
   robot.drawString(c, 0, 1)
   Tools.delay(300)
robot.exit()

