# Ro2c.py

from ev3robot import *
#from nxtrobot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.setSpeed(50)
gear.leftArc(0.3)

while not robot.isEscapeHit():
    pass   
robot.exit()   


