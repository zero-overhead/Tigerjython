# Ro5a.py

from ev3robot import *
#from nxtrobot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ss = NxtSoundSensor(SensorPort.S1)
robot.addPart(ss)

while not robot.isEscapeHit():
   if ss.getValue() > 30:
      gear.forward()   
robot.exit()
