# Ro15e.py ADXL345

from ev3robot import *

robot = LegoRobot()
adxl = ADXLSensor(SensorPort.S3)
robot.addPart(adxl)
while not robot.isEscapeHit():
    v = adxl.getValues()
    robot.clearDisplay()
    robot.drawString("%.2f,%.2f,%.2f" %v, 0, 1) 
    print("%.2f,%.2f,%.2f" %v)
    Tools.delay(500)
robot.exit()