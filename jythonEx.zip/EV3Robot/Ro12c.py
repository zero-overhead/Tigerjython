# Ro12c.py

from ev3robot import *
   
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
irs = IRRemoteSensor(SensorPort.S1)
robot.addPart(irs)
tMove = 3200
tTurn = 545
memory = []    
gear.forward(tMove)

# learning
while not robot.isEscapeHit() and isRunning:
    command = irs.getCommand() 
    if command == 1: #
        gear.left(tTurn)
        memory.append(0)
        print(memory) 
        gear.forward(tMove)
    elif command == 3:
        gear.right(tTurn)
        memory.append(1)
        print(memory) 
        gear.right(tTurn)     
    elif command == 2:
        gear.stop() 

# running
    #set the robot at the startposition
    elif command == 4: 
        gear.forward(tMove)
        for i in memory:
            if i == 0:
                gear.left(tTurn)
                gear.forward(tMove)
            else:         
                gear.right(tTurn)
                gear.forward(tMove)
    elif command == 2:
        gear.stop()
        isRunning = False                     
robot.exit()

