# Ro6a.py

from ev3robot import *
#from nxtrobot import *

def searchTarget():
   global left, right
   found = False
   step = 0
   while not robot.isEscapeHit(): 
      gear.right(50)
      step = step + 1
      dist = us.getDistance()
      if dist != -1:
         if not found:
            found = True
            left = step
      else:
         if found:   
            right = step
            break

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
us = UltrasonicSensor(SensorPort.S3)
robot.addPart(us)
gear.setSpeed(10)
searchTarget()

gear.left((right - left) * 25)
gear.setSpeed(30)
gear.forward()

while not robot.isEscapeHit() and gear.isMoving(): 
   dist = us.getDistance()
   print "Distance = " + str(dist)
   if dist < 20:
      gear.stop()
robot.exit()
