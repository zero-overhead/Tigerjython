# Ro8b.py

from ev3robot import *
#from nxtrobot import *

def pressCallback(port):
   gear.stop()

def searchTarget():
   global left, right
   found = False
   step = 0
   while not robot.isEscapeHit():  
      gear.right(50)
      step = step + 1
      dist = us.getDistance()
      if dist < 80:
         if not found:
            found = True
            left = step
            print "Left border found at " + str(left)
      else:
         if found:   
            right = step
            print "Right border  found at " + str(right)
            break

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.setSpeed(10)
us = UltrasonicSensor(SensorPort.S1)
robot.addPart(us)
us.setBeamAreaColor(Color.green)  
us.setProximityCircleColor(Color.lightGray)
ts = TouchSensor(SensorPort.S3, pressed = pressCallback)
robot.addPart(ts)
left = 0
right = 0
print "Searching target..."
searchTarget()

print "Turning to target..."
gear.left((right - left) * 100)
print "Moving forward..."
gear.forward()

while not robot.isEscapeHit()and gear.isMoving(): 
   dist = us.getDistance()
   print "Distance = " + str(dist)
print "All done"      
robot.exit()
