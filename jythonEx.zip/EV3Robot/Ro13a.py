# Ro13a.py

from ev3robot import *

robot = LegoRobot()
temp = TemperatureSensor(SensorPort.S1)
robot.addPart(temp)
while not robot.isEscapeHit():
    T = temp.getTemperature()
    robot.drawString("T = " + str(T) + " deg.", 0, 1)
    print "T =", T, "degrees"
    Tools.delay(1000)
robot.exit()    