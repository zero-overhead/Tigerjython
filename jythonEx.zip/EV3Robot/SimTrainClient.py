# SimTrainClient.py

from simrobot import *
from tcpcom import TCPClient
import time

def onStateChanged(state, msg):
    global isWaiting, start
    if state == TCPClient.CONNECTED:
        print "connected"
    if state == TCPClient.DISCONNECTED:
        gear.stop()
    if state == TCPClient.MESSAGE:
        if msg == "go":
            isWaiting = False 
            start = time.time() 
            print "run"     
            
RobotContext.useBackground("sprites/train.png")
RobotContext.setStartPosition(285, 350)
RobotContext.setStartDirection(-20)

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ls1 = LightSensor(SensorPort.S3)
robot.addPart(ls1)
ls2 = LightSensor(SensorPort.S1)
robot.addPart(ls2)
gear.forward()
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
isWaiting = False
if client.connect():
    start = time.time()
    while not robot.isEscapeHit():
        if isWaiting:
            continue
        v1 = ls1.getValue()
        v2 = ls2.getValue()
        if v1 > 800:  
            gear.rightArc(0.2)
        else: 
            gear.leftArc(0.2) 
        if v2 > 500 and v2 < 750 and time.time() - start > 5: 
            print "ok"
            gear.stop()
            client.sendMessage("go")
            isWaiting = True   
        Tools.delay(200)            
    client.disconnect()                
robot.exit()
