# Ro3b.py

from ev3robot import *
#from nxtrobot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ls = LightSensor(SensorPort.S1)
robot.addPart(ls)
ls.activate(True)
gear.setSpeed(20)
gear.forward()

while not robot.isEscapeHit():
   v = ls.getValue()
   if v < 100:
      gear.forward()
   if v > 100 and v < 500:
      gear.leftArc(0.05)
   if v > 500:
      gear.rightArc(0.05)
   Tools.delay(10)         
robot.exit()