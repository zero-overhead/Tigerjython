# Ro13b.py 

from ev3robot import *
from gpanel import *

def init(tstart):
    tend = tstart  + 1000
    window(tstart - 100, tend + 100, -5, 55)
    clear()
    setColor("gray")
    drawGrid(tstart, tend, 0, 50)
    text(tstart - 100, 52,  "deg")
    text(tend, -4,  "sec")
    setColor("black")
    lineWidth(2)

robot = LegoRobot()
temp = TemperatureSensor(SensorPort.S1)
robot.addPart(temp)
makeGPanel()
title("Temperature Logger")
addStatusBar(20)
t = 0
while robot.isConnected() and not isDisposed():
    T = temp.getTemperature()
    if t % 1000 == 0:
        init(t)
        move(t, T)
    else:
        draw(t, T)
    setStatusText("Time: %5d s.  Temperature: %5.2f �C" %(t, T))
    Tools.delay(1000)
    t = t + 1
dispose()    
robot.exit()    