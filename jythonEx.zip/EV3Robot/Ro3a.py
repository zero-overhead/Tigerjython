# Ro3a.py

from ev3robot import *
#from nxtrobot import *
 
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ls = LightSensor(SensorPort.S3)
robot.addPart(ls)
ls.activate(True)
gear.setSpeed(20)
gear.forward()

while not robot.isEscapeHit():
   v = ls.getValue()
   if v < 500:
      gear.leftArc(0.1)
   else:
      gear.rightArc(0.1)
robot.exit()

