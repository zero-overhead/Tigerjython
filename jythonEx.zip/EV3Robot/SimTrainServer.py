# SimTrainServer.py

from simrobot import *
from tcpcom import TCPServer
import time

def onStateChanged(state, msg):
    global isWaiting, isStoped, start
    if state == TCPServer.LISTENING:
        gear.stop()
        isWaiting = True
    if state == TCPServer.CONNECTED:
        robot.drawString("Connected", 0, 1);
        playTone(260, 100) 
    if state == TCPServer.MESSAGE:
        if msg == "go":
            isWaiting = False
            start = time.time()
            print "run"
    
RobotContext.useBackground("sprites/train.png")
RobotContext.setStartPosition(230, 415)
RobotContext.setStartDirection(180)

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ls1 = LightSensor(SensorPort.S3)
robot.addPart(ls1)
ls2 = LightSensor(SensorPort.S1)
robot.addPart(ls2)
port = 5000
server = TCPServer(port, stateChanged = onStateChanged)
start = time.time()
isWaiting = True

while not robot.isEscapeHit():
    if isWaiting:
        continue
    v1 = ls1.getValue()
    v2 = ls2.getValue()
    if v1 > 800:  
        gear.rightArc(0.2)
    else: 
        gear.leftArc(0.2)
    if v2 > 500 and v2 < 750 and time.time() - start > 5: 
        server.sendMessage("go")
        print "ok"
        gear.stop()
        isWaiting = True           
    Tools.delay(200)                    
server.terminate()        
robot.exit()
