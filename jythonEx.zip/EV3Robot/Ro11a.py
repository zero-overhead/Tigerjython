# Ro11a.py

from ev3robot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
irs = IRRemoteSensor(SensorPort.S1)
robot.addPart(irs)
isRunning = True
robot.drawString("1: Forward" , 0, 1)
robot.drawString("3: Stop" , 0, 2)
robot.drawString("2: Left" , 0, 3)
robot.drawString("4: Right" , 0, 4)
robot.drawString("5: End Program" , 0, 4)

while not robot.isEscapeHit() and isRunning: 
    command = irs.getCommand()    
    if command == 1:
        gear.forward()        
    if command == 3:
        gear.stop()        
    if command == 2:
        gear.leftArc(0.2) 
    if command == 4:
        gear.rightArc(0.2)
    if command == 5:
        isRunning = False       
robot.exit()

