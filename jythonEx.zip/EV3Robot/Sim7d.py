# Sim7d.py

from simrobot import *

RobotContext.useBackground("sprites/colors.png")
RobotContext.setStartPosition(250, 480)
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
cs = ColorSensor(SensorPort.S3)
robot.addPart(cs)
gear.setSpeed(50)
gear.forward()
oldColor = "UNDEFINED"

while not robot.isEscapeHit():
    color = cs.getColorStr()
    if (color != oldColor):
        oldColor = color
        if color == "BLACK":
            robot.playTone(264, 500)
            gear.forward()
        elif color == "BLUE":
            robot.playTone(297, 500)
        elif color == "GREEN":
            robot.playTone(330, 500)
        elif color == "YELLOW":
            robot.playTone(352, 500)
        elif color == "RED":
            robot.playTone(396, 500)      
        elif color == "WHITE":       
            gear.backward()    
    print(color)                   
robot.exit()