# Ro15a.py

from ev3robot import *

robot = LegoRobot()
sht = SHTSensor(SensorPort.S1)
robot.addPart(sht)
while not robot.isEscapeHit():
    temp, humi = sht.getValues()
    print(temp)
    robot.drawString("Temp: " + str(temp), 0, 2)
    Tools.delay(1000)
robot.exit()

