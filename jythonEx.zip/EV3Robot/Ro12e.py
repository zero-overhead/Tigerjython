#Ro12e.py

from simrobot import *
#from ev3robot import *
import time

RobotContext.useBackground("sprites/learntrack1.gif")
RobotContext.setStartPosition(385, 490)

def keepOnTrack():
    if vL < 500 and vR < 500:
        gear.forward()
    elif vL < 500 and vR > 500:
        gear.leftArc(0.1)
    elif vL > 500 and vR < 500:
        gear.rightArc(0.1)

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ls1 = LightSensor(SensorPort.S1)#right
ls2 = LightSensor(SensorPort.S2)#left
robot.addPart(ls1)
robot.addPart(ls2)
gear.setSpeed(30)
memory = []
id = 0

# learning
startTime = time.time()

while not robot.isEscapeHit():
    vL = ls2.getValue()
    vR = ls1.getValue()
    keepOnTrack()
    if vL > 500 and vR > 500:  
        if time.time() - startTime > 2:
            gear.backward(100)   
            gear.left(900)
            memory.append(0)     
            gear.forward()           
        elif memory != []:
            memory.pop() 
            memory.append(1)
            gear.right(1800)
        print(memory)
        startTime = time.time()    
gear.stop()

# running
while not robot.isEscapeHit():
    while not robot.isEnterHit():
        pass
    robot.reset()
    id = 0
    while not robot.isEscapeHit():
        vR = ls1.getValue()
        vL = ls2.getValue()  
        keepOnTrack()
        if vL > 500 and vR > 500:  
            gear.stop()
            if len(memory) == id:
                break           
            if memory[id] == 0:
                gear.left(900)
            else:
                gear.right(900)            
            id += 1
    gear.stop()        
robot.exit()