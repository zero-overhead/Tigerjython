# Ro5c.py

from ev3robot import *
# from nxtrobot import *
                                 
robot = LegoRobot()
frequency = [264,297,330,352,396,440,495,528]
for f in frequency:
    robot.playTone(f, 200)  
for f in reversed(frequency):
    robot.playTone(f, 200)  
robot.exit()