# Ro11c.py

from ev3robot import *

robot = LegoRobot()
irs = IRDistanceSensor(SensorPort.S1)
robot.addPart(irs)
isAutonomous = robot.isAutonomous()
while not robot.isEscapeHit():  
    dist = irs.getDistance()
    print "d = ", dist
    robot.drawString("d=" + str(dist), 0, 3)
    robot.playTone(10 * dist + 100, 50)
    if dist == 255:
        robot.playTone(10 * dist + 100, 50)    
    Tools.delay(500)
robot.exit()


