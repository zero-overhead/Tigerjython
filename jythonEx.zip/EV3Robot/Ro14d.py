# Ro14c.py

from ev3robot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
robot.drawString("Start playing", 0, 1)
robot.playSample(1003, 100)
Tools.delay(4000)

while not robot.isEscapeHit():
    gear.forward(2000)
    gear.backward(2000)
    gear.left(600)
    Tools.delay(3000)
robot.exit()