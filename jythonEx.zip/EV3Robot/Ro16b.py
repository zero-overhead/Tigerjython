#Ro16b.py Webserver2

from ev3robot import *
from time import sleep

html = """
<!DOCTYPE html>
<html>
  <head> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <head>
  <body> 
  <h2>WebRobot</h2> 
     <p>Press to change the state:</p>
     <p><a href="forward">forward</a></p>
     <p><a href="stop">stop</a></p>
  </body> 
</html>
"""

def onRequest(clientIP, state, params):
    if state == "/forward":
        gear.forward()
    elif state == "/stop":
        gear.stop()
    return html

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.setSpeed(30)
server = HTTPServer(requestHandler = onRequest, port = 81)

while not robot.isEscapeHit():
    sleep(1)  
server.terminate()
robot.exit()