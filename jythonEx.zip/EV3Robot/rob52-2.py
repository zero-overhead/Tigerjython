from simrobot import *
#from nxtrobot import *
#from ev3robot import *

RobotContext.useObstacle("sprites/bg.gif", 250, 250)
RobotContext.setStartPosition(310, 470)

tMove = 5000
tTurn = 580

def onButtonHit(buttonID):
    global state
    if buttonID == BrickButton.ID_LEFT:
        state = "LEFT"
    if buttonID == BrickButton.ID_RIGHT:
        state = "RIGHT"

state = "FORWARD"

robot = LegoRobot(buttonHit = onButtonHit)
gear = Gear()
gear.setSpeed(50)
robot.addPart(gear)

while robot.isRunning():
    if state == "FORWARD":
        gear.forward(tMove)
        state = "STOPPED"
    elif state == "LEFT":
        gear.left(tTurn)
        gear.forward(tMove)
        state = "STOPPED"
    elif state == "RIGHT":
        gear.right(tTurn)
        gear.forward(tMove)
        state = "STOPPED"
robot.exit()

