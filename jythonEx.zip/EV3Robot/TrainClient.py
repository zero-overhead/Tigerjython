# TrainClient.py

from ev3robot import *
import time

def onStateChanged(state, msg):
    global isWaiting, start
    if state == TCPClient.CONNECTED:
        robot.drawString("Connected", 0, 1)
    if state == TCPClient.DISCONNECTED:
        gear.stop()
        robot.drawString("Disconnected", 0, 1)
    if state == TCPClient.MESSAGE:
        if msg == "go":
            isWaiting = False 
            start = time.time() 
            robot.drawString("Run", 0, 3)
            
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.setSpeed(20)
ls1 = LightSensor(SensorPort.S3)
robot.addPart(ls1)
ls2 = LightSensor(SensorPort.S1)
robot.addPart(ls2)
gear.forward()
host = "192.168.0.17"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
isWaiting = False
robot.drawString("Trying to connect..", 0, 1)
if client.connect():
    start = time.time()
    while not robot.isEscapeHit():
        if isWaiting:
            continue
        v1 = ls1.getValue()
        v2 = ls2.getValue()
        if v1 > 500:  
            gear.rightArc(0.1)
        else: 
            gear.leftArc(0.1) 
        if v2 > 500 and time.time() - start > 5: 
            gear.stop()
            client.sendMessage("go")
            isWaiting = True   
            robot.drawString("Stop", 0, 3)
        Tools.delay(200)            
    client.disconnect()                
robot.exit()

