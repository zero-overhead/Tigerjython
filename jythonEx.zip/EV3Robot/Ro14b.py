# Ro14b.py

from ev3robot import *

print "starting"
EV3Copy.copyFile("10.0.1.1", "c:\\scratch\\test.wav", "/home/root/music/song1.wav")
print "done"
