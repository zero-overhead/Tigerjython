# Ro10b.py

from ev3robot import *
# from nxtrobot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.setSpeed(30)
gear.forward(3000)

while not robot.isEscapeHit():
    if robot.isLeftHit():        
        gear.left(600)
        gear.forward(3000)
    elif robot.isRightHit():         
        gear.right(600)
        gear.forward(3000)
robot.exit()
