# Ro1c.py

from ev3robot import *
#from nxtrobot import *

robot = TurtleRobot()
robot.forward(100)
robot.left(90)
robot.forward(100)
robot.exit()
