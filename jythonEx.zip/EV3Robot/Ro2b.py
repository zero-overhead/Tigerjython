# Ro2b.py

from ev3robot import *
#from nxtrobot import *

robot = TurtleRobot()
i = 0
while i < 3:
   robot.forward(30)
   robot.right(90)
   robot.forward(30)
   robot.left(90)
   i = i + 1
   print i
   robot.drawString(str(i), 0, 2)
robot.exit()
