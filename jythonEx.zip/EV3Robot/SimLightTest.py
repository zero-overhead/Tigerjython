# SimLightTest

from simrobot import *

RobotContext.setStartPosition(250, 490)
RobotContext.useBackground("sprites/lighttest.gif")

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ls = LightSensor(SensorPort.S3)
robot.addPart(ls)
gear.forward()
while not robot.isEscapeHit():
    v = ls.getValue()
    print(v)
    Tools.delay(10)
robot.exit()