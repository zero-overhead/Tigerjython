# Ro15b.py

from ev3robot import *

robot = LegoRobot()
sht = SHTSensor(SensorPort.S1)
robot.addPart(sht)
while not robot.isEscapeHit():
    temp, humi = sht.getValues()
    print("Temp: %6.2f, Humi: %6.2f" % (temp, humi))
    Tools.delay(1000)
robot.exit()