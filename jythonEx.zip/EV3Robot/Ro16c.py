#Ro16c.py 

from ev3robot import *
from time import sleep

html = """
<!DOCTYPE html>
<html>
  <head> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <head>
  <body> 
  <h2>WebRobot</h2> 
    <form method="get">
       <p><input type="submit" style="font-size:18px; height:40px; 
           width:110px" name="btn" value="forward"/>&nbsp;
        <input type="submit" style="font-size:18px; height:40px;
           width:110px" name="btn" value="stop"/></p>         
    </form>
  </body> 
</html>
"""

def onRequest(clientIP, state, params):    
    if "btn" in params:
        state = params["btn"]
        if state == "forward":
            gear.forward()         
        elif state == "stop":
            gear.stop()
    return html

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.setSpeed(30)
state = "stop"
server = HTTPServer(requestHandler = onRequest, port = 81)

while not robot.isEscapeHit():
    sleep(1)  
server.terminate()
robot.exit()