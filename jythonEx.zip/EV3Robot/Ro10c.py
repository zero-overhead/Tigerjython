# Ro10c.py

from ev3robot import *
# from nxtrobot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.setSpeed(30)

while not robot.isEscapeHit():
    if robot.isUpHit():  
        gear.forward()
    elif robot.isDownHit():
        gear.stop()     
    elif robot.isLeftHit():        
        gear.left(600) 
    elif robot.isRightHit():         
        gear.right(600)     
robot.exit()