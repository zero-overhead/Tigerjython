# Sim7b.py

from simrobot import *

RobotContext.useBackground("sprites/colors.png") 
RobotContext.setStartPosition(250, 480)
RobotContext.showStatusBar(30)                           
                                 
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
cs = ColorSensor(SensorPort.S3)
robot.addPart(cs)
cs.colorCubes[1] = [0, 10, 0, 10, 200, 255]
cs.colorCubes[2] = [0, 10, 200, 255, 0, 10]
gear.forward();

while not robot.isEscapeHit():
   c = cs.getColor()
   color = cs.getColorStr()
   print(color)
   robot.drawString(color, 0, 1)
   Tools.delay(300)
robot.exit()



