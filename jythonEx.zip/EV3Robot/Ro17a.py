#Ro17a.py

from ev3robot import *

html = """<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="3">
  </head>
  <body> 
    <h2>WebRobot</H2> 
    Current distance: %s
  </body>
</html>
"""

def onRequest(clientIP, state, params):
   d = us.getDistance()
   return html %(d)   

robot = LegoRobot()
us = UltrasonicSensor(SensorPort.S1)
robot.addPart(us)
server = HTTPServer(requestHandler = onRequest, port = 81)

while not robot.isEscapeHit():
    Tools.delay(100) 
server.terminate()
robot.exit()