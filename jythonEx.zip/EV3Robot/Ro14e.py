# Ro14d.py

from ev3robot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
robot.playSampleWait(1005, 100)
gear.forward(2000)
robot.playSampleWait(1006, 100)
gear.backward(2000)
robot.playSampleWait(1008, 100)
gear.right(550)
gear.forward(2000)
robot.exit()