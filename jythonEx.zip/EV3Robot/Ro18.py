# Ro15.py (for EV3) 

from ev3robot import *
                                
robot = LegoRobot()
arduino = ArduinoLink(SensorPort.S1)
robot.addPart(arduino)
robot.drawString("Arduino Link Test", 0, 0)
print "Arduino Link Test. Press up/down/left/right/enter/escape"
while not robot.isEscapeHit():
    if robot.isDownHit():
        msg = "Blinking stopped"
        print msg
        robot.drawString(msg, 0, 2)
        v = arduino.getReplyInt(0)  # stop blinking
    elif robot.isUpHit():
        msg = "Blinker started"
        print msg
        robot.drawString(msg, 0, 2)
        v = arduino.getReplyInt(1)  # start blinking
    elif robot.isEnterHit():
        msg = arduino.getReplyString(2)  # get version
        print "Version:", msg
        robot.drawString(msg, 0, 1)
    elif robot.isLeftHit():
        msg = arduino.getReplyString(3)  # get switch state
        print "Switch:", msg
        robot.drawString("State: " + msg, 0, 3)
    elif robot.isRightHit():
        msg = arduino.getReplyString(4)  # get temperature
        print "Temperature: ", msg
        robot.drawString("Temp: " + msg, 0, 4)
robot.exit()

