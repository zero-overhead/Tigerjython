# Ro4c.py

from ev3robot import *
#from nxtrobot import *
import time

def pressCallback(port):
   global startTime
   dt = time.clock() - startTime
   print dt
   gear.backward(1300)
   if dt > 2: 
      gear.left(580)      
   else:
      gear.left(1160)  
 
   gear.forward()   
   startTime = time.clock()     
      

robot = LegoRobot()
gear = Gear()
gear.setSpeed(35)
robot.addPart(gear)
ts = TouchSensor(SensorPort.S1, 
     pressed = pressCallback)     
robot.addPart(ts)
gear.forward()
startTime = time.clock()
   
        



