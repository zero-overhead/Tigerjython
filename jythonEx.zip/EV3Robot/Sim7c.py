# Sim7c.py

from simrobot import *

RobotContext.useBackground("sprites/colors2.png") 
RobotContext.setStartPosition(250, 480)
RobotContext.showStatusBar(30)                                 
cyanCube = [0, 10, 220, 255, 220, 255]
yellowCube = [220, 255, 220, 255, 0, 10]
magentaCube = [220, 255, 0, 10, 220, 255]
robot = LegoRobot()
cs = ColorSensor(SensorPort.S3)
robot.addPart(cs)
gear = Gear()
robot.addPart(gear)
gear.setSpeed(20)
gear.forward()
color = "Undefined"
while not robot.isEscapeHit():
   c = cs.getColor()  
   if cs.inColorCube(c, cyanCube):
      color = "Cyan"
   elif cs.inColorCube(c, yellowCube):
      color = "Yellow"
   elif cs.inColorCube(c, magentaCube):
      color = "Magenta"
   else:
      color = "Undefined"
   print(color)  
   Tools.delay(300)
robot.exit()
  

