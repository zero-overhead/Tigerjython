# Ro7b.py

from ev3robot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
cs = ColorSensor(SensorPort.S3)
robot.addPart(cs)
# Redefine blue color cube
cs.colorCubes[1] = [5,15, 10,25, 15,60]
# Redefine green color cube
cs.colorCubes[2] = [5,25, 30,85, 5,25]
gear.setSpeed(10)
gear.forward()

while not robot.isEscapeHit():
   c = cs.getColor()
   s = cs.getColorStr()
   print(c.getRed(),c.getGreen(),c.getBlue(), s)
   robot.drawString(s, 0, 1)
   Tools.delay(300)
robot.exit()
