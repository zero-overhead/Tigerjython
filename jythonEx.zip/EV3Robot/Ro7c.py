# Ro7c.py

from ev3robot import *
                                 
cyanCube = [0,20, 30,60, 30,60]
yellowCube = [50,90, 35,70, 3,20]
magentaCube = [40,60, 5,20, 10,60]
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
cs = ColorSensor(SensorPort.S3)
robot.addPart(cs)
gear.setSpeed(10)
gear.forward()
color = "Undefined"

while not robot.isEscapeHit():
   c = cs.getColor()    
   if cs.inColorCube(c, cyanCube):
      color = "Cyan"
   elif cs.inColorCube(c, yellowCube):
      color = "Yellow"
   elif cs.inColorCube(c, magentaCube):
      color = "Magenta"
   else:
      color = "Undefined"
   print(c.getRed(),c.getGreen(),c.getBlue(), color)
   robot.drawString(color, 0, 1)  
   Tools.delay(300)
robot.exit()