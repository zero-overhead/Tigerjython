# Ro8a.py

from ev3robot import *
#from nxtrobot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ss = NxtSoundSensor(SensorPort.S1)
robot.addPart(ss)
ts = TouchSensor(SensorPort.S4)
robot.addPart(ts)
ls = LightSensor(SensorPort.S3)
robot.addPart(ls)
ls.activate(True)

while not robot.isEscapeHit():
   if ss.getValue() > 30:
      gear.forward()
   if ts.isPressed():
      gear.forward()
   if ls.getValue() < 500:
      gear.backward()
   Tools.delay(100)   
robot.exit()
