# Ro3c.py

from ev3robot import *
#from nxtrobot import *

def onDark(port, level):
   gear.backward(1500)
   gear.left(600)
   gear.forward()

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ls = LightSensor(SensorPort.S3, 
     dark = onDark)
robot.addPart(ls)
ls.activate(True)
gear.forward()
while not robot.isEscapeHit():
   pass
robot.exit()
