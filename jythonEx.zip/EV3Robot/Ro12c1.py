# Ro12c.py

from simrobot import *
#from ev3robot import *
#from nxtrobot import *
import time

RobotContext.useObstacle("sprites/bg.gif", 250, 250)  
RobotContext.setStartPosition(310, 480)
RobotContext.showStatusBar(30)

def pressCallback(port):
    global startTime
    global backTime
    global t
    dt = time.clock() - startTime 
    gear.backward(backTime)
    if dt > 2:
        memory.append(0) 
        gear.left(turnTime)  
    else:
        memory.pop()
        memory.append(1) 
        gear.right(2 * turnTime) 
    robot.drawString("Memory: " + str(memory), 0, 1)
    gear.forward()
    startTime = time.clock()      

def run():
    for k in memory:
        robot.drawString("Moving forward",0, 1)
        gear.forward(moveTime)
        if k == 0:
            robot.drawString("Turning left",0, 1)
            gear.left(turnTime)            
        elif k == 1:
            robot.drawString("Turning right",0, 1)
            gear.right(turnTime)            
    gear.forward(moveTime) 
    robot.drawString("All done", 0, 1)          
    isExecuting = False
    
moveTime = 3200
turnTime = 545
backTime = 600
memory = []      
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ts = TouchSensor(SensorPort.S3, pressed = pressCallback)      
robot.addPart(ts)
startTime = time.clock()
gear.forward()

while not robot.isEscapeHit():
    if robot.isDownHit():  
        gear.stop()
    elif robot.isEnterHit():
        robot.reset()    
        run()      
robot.exit()