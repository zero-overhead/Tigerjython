# Ro5b.py

from ev3robot import *
#from nxtrobot import *

def onLoud(port, level):
   gear.left(600)
   gear.forward() 
   
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ss = NxtSoundSensor(SensorPort.S1, 
     loud = onLoud)
robot.addPart(ss)
gear.forward()
while not robot.isEscapeHit():
   pass
robot.exit()
