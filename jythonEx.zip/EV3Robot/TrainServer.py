#TrainServer.py

from ev3robot import *
import time

def onStateChanged(state, msg):
    global isWaiting, isStoped, start
    if state == TCPServer.LISTENING:
        robot.drawString("Listening", 0, 1);
        gear.stop()
        isWaiting = True
    elif state == TCPServer.CONNECTED:
        robot.drawString("Connected", 0, 1);
        playTone(260, 100) 
    elif state == TCPServer.MESSAGE:
        if msg == "go":
            isWaiting = False
            start = time.time()
            robot.drawString("Run", 0, 3);
    
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.setSpeed(20)
ls1 = LightSensor(SensorPort.S3)
robot.addPart(ls1)
ls2 = LightSensor(SensorPort.S1)
robot.addPart(ls2)
port = 5000
server = TCPServer(port, stateChanged = onStateChanged)
start = time.time()
isWaiting = True

while not robot.isEscapeHit():
    if isWaiting:
        continue
    v1 = ls1.getValue()
    v2 = ls2.getValue()
    if v1 > 500:  
        gear.rightArc(0.1)
    else: 
        gear.leftArc(0.1)
    if v2 > 500 and time.time() - start > 5:     
        server.sendMessage("go")
        gear.stop()
        isWaiting = True           
        robot.drawString("Stop", 0, 3);
    Tools.delay(200)                    
server.terminate()        
robot.exit()

