# Ro12b.py

from ev3robot import *

def onActionPerformed(port, command):
    global state
    if command == 1:
        state = "LEFT"
    elif command == 3:
        state = "RIGHT"
    elif command == 2:
        state = "RUN"

tMove = 5000
tTurn = 580
memory = []       
robot = LegoRobot()
gear = Gear()
gear.setSpeed(50)
robot.addPart(gear)
irs = IRRemoteSensor(SensorPort.S1, actionPerformed = onActionPerformed)
robot.addPart(irs)
state = "FORWARD"

# learning
while not robot.isEscapeHit():
    if state == "FORWARD":
        gear.forward(tMove)
        state = "STOPPED"
    elif state == "LEFT":
        memory.append(0)
        gear.left(tTurn)
        gear.forward(tMove)
        state = "STOPPED"
    elif state == "RIGHT":
        memory.append(1)
        gear.right(tTurn)
        gear.forward(tMove)
        state = "STOPPED"
# running
    elif state == "RUN":
        gear.forward(tMove)
        for k in memory:
            if k == 0:
                gear.left(tTurn)
            else:         
                gear.right(tTurn)
            gear.forward(tMove)
        gear.stop() 
        state = "STOPPED"
robot.exit()

