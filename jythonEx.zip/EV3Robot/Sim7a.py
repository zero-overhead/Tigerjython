# Sim7a.py

from simrobot import *

RobotContext.useBackground("sprites/colors.png") 
RobotContext.setStartPosition(250, 480)
RobotContext.showStatusBar(30)                                
                                 
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
cs = ColorSensor(SensorPort.S3)
robot.addPart(cs)
gear.setSpeed(20)
gear.forward();

while not robot.isEscapeHit():
   c = cs.getColorStr()
   print(c)
   Tools.delay(300)
robot.exit()