# Ro1a.py

from ev3robot import *
#from nxtrobot import *
  
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
gear.forward()
Tools.delay(2000)
gear.left()
Tools.delay(600)
gear.forward();
Tools.delay(2000)
robot.exit()
