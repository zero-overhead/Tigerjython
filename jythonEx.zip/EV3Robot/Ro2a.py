# Ro2a.py

from ev3robot import *
#from nxtrobot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
for i in range(4):
   gear.forward(2000)
   gear.left(600)
robot.exit()
