# Ro15c.py, BME280
from ev3robot import *

robot = LegoRobot()
bme = BMESensor(SensorPort.S1)
robot.addPart(bme)
while not robot.isEscapeHit():
    v = bme.getValues()
    print("t: %5.2f, h: %5.2f, p: %6.2f"  % (v[0], v[1], v[2]))
    robot.clearDisplay()
    robot.drawString("t: %.2f degC" %v[0], 0, 1)                      
    robot.drawString("h: %.2f %%" %v[1], 0, 2)                      
    robot.drawString("p: %.2f hPa" %v[2], 0, 3)                      
    Tools.delay(1000)
robot.exit()



