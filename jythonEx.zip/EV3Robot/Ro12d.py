# Ro12d.py

from simrobot import *
#from ev3robot import *
import time

RobotContext.useObstacle("sprites/bg2.gif", 250, 250)  
RobotContext.setStartPosition(410, 480)
RobotContext.showStatusBar(30)

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ts = TouchSensor(SensorPort.S3)      
robot.addPart(ts)
startTime = time.clock()
moveTime = 0
turnTime = 545
backTime = 600
memory = [] 
gear.forward()

#learning
while not robot.isEscapeHit():
    if ts.isPressed():
        dt = time.clock() - startTime
        if dt > 2:  
            gear.backward(backTime)
            moveTime = int(dt * 1000) - backTime  # save long-track time
            node = [moveTime, 0] 
            memory.append(node) 
            gear.left(turnTime) # turning left   
        else:
            memory.pop() # discard node
            node = [moveTime, 1] 
            memory.append(node) 
            gear.right(2 * turnTime) # turning right
        robot.drawString("Memory: " + str(memory), 0, 1)
        print(memory)
        gear.forward()
        startTime = time.clock()   
gear.stop()

#running
while not robot.isDownHit():
    while not robot.isEnterHit():    
        pass
    robot.reset()
    for node in memory:
        moveTime = node[0]
        k = node[1]
        gear.forward(moveTime)
        if k == 0:  
            gear.left(turnTime)            
        elif k == 1:
            gear.right(turnTime)            
    gear.forward() 
robot.exit()

