# Ro4b.py

from ev3robot import *
#from nxtrobot import *

def onPressed(port):
   gear.backward(800)
   gear.left(240)
   gear.forward()
  
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ts = TouchSensor(SensorPort.S3, 
     pressed = onPressed)
robot.addPart(ts)
gear.forward()
while not robot.isEscapeHit():
   pass
robot.exit()
