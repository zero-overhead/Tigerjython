# Ro14c.py

from ev3robot import *

robot = LegoRobot()
robot.drawString("Start playing", 0, 1)
robot.playSample(1003, 100)

while not robot.isEscapeHit():
    Tools.delay(100)
robot.exit()