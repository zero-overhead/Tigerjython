# Ro7d.py

from ev3robot import *
                                 
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
cs = ColorSensor(SensorPort.S3)
robot.addPart(cs)
gear.setSpeed(10)
oldColor = "UNDEFINED"

while not robot.isEscapeHit():
    color = cs.getColorStr()
    if (color != oldColor):
        oldColor = color
        if color == "BLACK":
            robot.playTone(264, 300)
            gear.forward()
        elif color == "BLUE":
            robot.playTone(297, 300)
        elif color == "GREEN":
            robot.playTone(330, 300) 
        elif color == "YELLOW":
            robot.playTone(352, 300) 
        elif color == "RED":
            robot.playTone(396, 300)
            gear.backward() 
    print(color)
    robot.drawString(color, 0, 1)                        
robot.exit()