# Ro4c.py

from nxtrobot import *
# from ev3robot import *

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
ts1 = TouchSensor(SensorPort.S1)
robot.addPart(ts1)
ts2 = TouchSensor(SensorPort.S2)
robot.addPart(ts2)
gear.forward()

while robot.isRunning(): 
   if ts1.isPressed():
      gear.backward(500)
      gear.left(400)
   elif ts2.isPressed():
      gear.backward(500)
      gear.right(100)
   gear.forward()
robot.exit()
