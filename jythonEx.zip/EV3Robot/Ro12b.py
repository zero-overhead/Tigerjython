#Ro12b.py

from simrobot import *
#from ev3robot import *

RobotContext.useBackground("sprites/bg.gif")
RobotContext.setStartPosition(310, 470)
RobotContext.showStatusBar(30)  

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
tMove = 3200
tTurn = 545
memory = []
gear.forward(tMove)

# learning
while not robot.isEscapeHit():    
    if robot.isLeftHit():        
        gear.left(tTurn)
        memory.append(0)
        gear.forward(tMove)        
    elif robot.isRightHit():         
        gear.right(tTurn)
        memory.append(1)
        gear.forward(tMove)    
    robot.drawString("Memory: " + str(memory), 0, 1)
    print(memory)

# running
while not robot.isDownHit():
    while not robot.isEnterHit():    
        pass
    robot.reset()    
    gear.forward(tMove)
    for i in memory:
        if i == 0:
            gear.left(tTurn)
            gear.forward(tMove)
        elif i == 1:
            gear.right(tTurn)
            gear.forward(tMove)     
robot.exit()