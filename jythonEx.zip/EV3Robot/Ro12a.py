#Ro12.py

from simrobot import *
#from ev3robot import *

RobotContext.useBackground("sprites/bg.gif")
RobotContext.setStartPosition(310, 470)

robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
tMove = 3200
tTurn = 545
memory = [0, 1, 1, 0]
gear.forward(tMove)

for i in memory:
    if i == 0:
        gear.left(tTurn)
        gear.forward(tMove)
    elif i == 1:
        gear.right(tTurn)
        gear.forward(tMove)     
robot.exit()