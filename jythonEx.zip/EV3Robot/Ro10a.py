# Ro10a.py

from ev3robot import *
# from nxtrobot import *
  
robot = LegoRobot()
gear = Gear()
robot.addPart(gear)
isRunning = True
while isRunning:
    if robot.isDownHit():
        gear.backward()
    elif robot.isUpHit():  
        gear.forward()
    elif robot.isLeftHit():        
        gear.left(580)
    elif robot.isRightHit():         
        gear.right(580)
    elif robot.isEnterHit():
        gear.stop()   
    elif robot.isEscapeHit(): 
        isRunning = False
robot.exit()

