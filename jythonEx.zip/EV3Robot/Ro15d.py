#Ro 15d.py

from ev3robot import *
from gpanel import *

makeGPanel(-5, 53, -3, 52)
drawGrid(0, 50, 0, 50, "gray")
setColor("blue")
lineWidth(2)
robot = LegoRobot()
sht = SHTSensor(SensorPort.S1)
robot.addPart(sht)
#bme = BMESensor(SensorPort.S1)
#robot.addPart(bme)
x = 0
while not robot.isEscapeHit():
    v = sht.getValues()
    #v = bme.getValues()
    temp = v[0]
    if x == 0:
        pos(x, temp)
    else:
        draw(x, temp)    
    print(temp)
    x = x + 1 
    if x == 50:
        x = 0  
        clear()
        drawGrid(0, 50, 0, 50, "gray")              
    Tools.delay(1000)
robot.exit()