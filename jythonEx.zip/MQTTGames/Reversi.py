# Reversi.py

from gamegrid import *
from mqttclient import GameClient
import reversilib

player = x # set player = 0 or player = 1
myTopic = "/swissgame/reversi"
      
def onMousePressed(e):
    global isMyMove, location
    if not isMyMove or isOver:
          return
    location = toLocationInGrid(e.getX(), e.getY())
    if getOneActorAt(location) == None and reversilib.hasNeighbours(location):
        stone = Actor("sprites/token.png", 2)
        addActor(stone, location)
        stone.show(player)
        reversilib.checkStones(player, location)
        refresh()
        client.sendMessage(str(location.x) + str(location.y)) # send location
        isMyMove = False
        setStatusText("Wait!")
        if len(getOccupiedLocations()) == 64:    
           reversilib.endOfGame()
           client.sendMessage("end")

def onNotifyExit():
    client.disconnect()
    dispose()
    
def onStateChanged(state):
    global isMyMove
    if state == "CONNECTING":
        setStatusText("Connecting to broker...")    
    elif state == "CONNECTED":
        setStatusText("Connected. Waiting for partner...")    
    elif state == "READY":
        if player == 0:
            setStatusText("Make a move!")
            isMyMove = True    
        else:
           setStatusText("Wait for partner's move!")    
    elif state == "DISCONNECTED":
        setStatusText("Partner disconnected!")    
        isMyMove = False

def onMessageReceived(msg):
    global isMyMove
    if msg == "end":
        reversilib.endOfGame()
    else:
        x = int(msg[0])
        y = int(msg[1])
        location = Location(x, y)            
        stone = Actor("sprites/token.png", 2)
        addActor(stone, location)          
        stone.show(partner)
        reversilib.checkStones(partner, location)
        refresh()        
        isMyMove = True
        setStatusText("Make your move!")
 
isMyMove = False   
isOver = False
partner = (player + 1) % 2
makeGameGrid(8, 8, 60, Color.gray, False, mousePressed = onMousePressed, notifyExit = onNotifyExit)
addStatusBar(30)
reversilib.initGame()
show()
if player == 0:
    setTitle("Player with yellow stones")
else:    
    setTitle("Player with red stones")
host = "m2m.eclipse.org"
client = GameClient(onStateChanged, onMessageReceived, myTopic)
client.connect(host)

