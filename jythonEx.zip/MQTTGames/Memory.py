# Memory.py

from gamegrid import *
from mqttclient import GameClient
import random

player = 0 # set player = 0 or player = 1
myTopic = "/swissgame/memory"

class MemoryCard(Actor):
    def __init__(self, cardNb):
        Actor.__init__(self, ["sprites/cardback.gif", "sprites/card" + str(cardNb) + ".gif"])
        self.cardNb = cardNb
    def getCardNb(self):
        return self.cardNb 

def createCards():
    cardList = []
    for i in range(16):  
        if i < 8:
            card = MemoryCard(i)
        else:
            card = MemoryCard(i - 8)
        cardList.append(card)    
    k = 0
    for i in rndList: 
        x = i % 4
        y = i // 4 
        loc = Location(x, y)             
        addActor(cardList[k], loc)
        cardList[k].show(0)
        k += 1

def onMousePressed(e):
     global card1, card2, isFirst
     if not isMyMove or isGameOver:
          return
     loc = toLocationInGrid(e.getX(), e.getY()) 
     client.sendMessage(str(loc.x) + str(loc.y)) # send location  
     card = getOneActorAt(loc)
     if card.getIdVisible() == 1: # card already visible->ignore
        return 
     card.show(1) # make card visible     
     if isFirst: 
         card1 = card
         setStatusText("Take second card!")
         isFirst = False
     else:  # second card taken
        card2 = card
        isFirst = True
        wakeUp()
           
def onNotifyExit():
    client.disconnect()
    dispose()
    
def onStateChanged(state):
    global isMyMove
    if state == "CONNECTING":
        setStatusText("Connecting to broker...")    
    elif state == "CONNECTED":
        setStatusText("Connected. Waiting for partner...")    
    elif state == "READY":
        if player == 0:
            setStatusText("Make a move!")
            client.sendMessage(str(rndList)) 
            isMyMove = True    
        else:
           setStatusText("Wait for partner's move!")    
    elif state == "DISCONNECTED":
        setStatusText("Partner disconnected!")    
        isMyMove = False
    
def onMessageReceived(msg):
    global isFirstRec, card1, card2, rndList
    if msg[0] == "[":
        s = msg[1:-1]
        config = s.split(",")
        rndList = [int(z) for z in config] 
        createCards()     
    else: 
        x = int(msg[0])
        y = int(msg[1])            
        loc = Location(x, y)
        card = getOneActorAt(loc)
        card.show(1)
        if isFirstRec:
            card1 = card        
            isFirstRec = False
        else:
            card2 = card 
            isFirstRec = True               
            wakeUp()                                  
         
makeGameGrid(4, 4, 115, Color.black, False, mousePressed = onMousePressed, 
             notifyExit = onNotifyExit)
addStatusBar(30)
setTitle("Memory")
rndList = random.sample(range(16), 16)
createCards()
show()
doRun()
PORT = 5000
isGameOver = False
isMyMove = False
isFirst = (player == 0)
isFirstRec = True
myHits = 0 
partnerHits = 0
setTitle("Player #" + str(player))
host = "m2m.eclipse.org"
client = GameClient(onStateChanged, onMessageReceived, myTopic)
client.connect(host)

while True:
    putSleep()
    if isDisposed():
       break
    if card1.getCardNb() == card2.getCardNb(): # test if cards have same image
        if isMyMove:
            myHits += 1
            setStatusText("Pair accepted. Take nextCard")
        else:
            partnerHits += 1
        if myHits + partnerHits == 8:
            isGameOver = True
            if myHits > partnerHits:
                setStatusText("Game over! You won with " + str(myHits) + " hits.") 
            elif myHits < partnerHits:
                setStatusText("Game over! You lost with only " + str(myHits) + " hits.")
            else:
                setStatusText("Game over! The score is even.")                
    else: #  hide the two cards
       delay(1000)
       card1.show(0)
       card2.show(0)
       if isMyMove:
           isMyMove = False
           setStatusText("Wait!")  
       else:
           isMyMove = True
           setStatusText("You play. Take two cards!")        

