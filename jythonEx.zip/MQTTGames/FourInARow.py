# FourInARow.py

from gamegrid import *
from mqttclient import GameClient
import fourlib                                                                    

player = 0 # set player = 0 or player = 1
myTopic = "/swissgame/four_in_a_row"

def onMousePressed(e):
    global isMyMove, location
    if not isMyMove or fourlib.isOver:
          return
    location = toLocationInGrid(e.getX(), e.getY())
    token = fourlib.Token(player)
    addActor(token, location, Location.SOUTH)   
    client.sendMessage(str(location.x)) # send location
    isMyMove = False
    setStatusText("Wait!")    

def onNotifyExit():
    client.disconnect()
    dispose()
    
def onStateChanged(state):
    global isMyMove
    if state == "CONNECTING":
        setStatusText("Connecting to broker...")    
    elif state == "CONNECTED":
        setStatusText("Connected. Waiting for partner...")    
    elif state == "READY":
        if player == 0:
            setStatusText("Make a move!")
            isMyMove = True    
        else:
           setStatusText("Wait for partner's move!")    
    elif state == "DISCONNECTED":
        setStatusText("Partner disconnected!")    
        isMyMove = False

def onMessageReceived(msg):
    global isMyMove, location
    x = int(msg[0])        
    location = Location(x, 0)            
    token = fourlib.Token((player + 1) % 2)
    addActor(token, location, Location.SOUTH)     
    isMyMove = True
    setStatusText("Make your move!")
    
makeGameGrid(7, 7, 70, None, "sprites/connectbg.png", False,
    mousePressed = onMousePressed, notifyExit = onNotifyExit)
setBgColor(makeColor("white"))
addStatusBar(30)
isMyMove = False 
show()
setSimulationPeriod(30)
doRun()
setTitle("Player #" + str(player))
host = "m2m.eclipse.org"
client = GameClient(onStateChanged, onMessageReceived, myTopic)
client.connect(host)

