#Battleship.py

from gamegrid import *
from mqttclient import GameClient

player = 0 # set player = 0 or player = 1
myTopic = "/swissgame/battleship"

class Ship(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/boat.gif")
        
def onMousePressed(e):
     global isMyMove
     if not isMyMove or isOver:
          return
     loc = toLocationInGrid(e.getX(), e.getY())
     addActor(Actor("sprites/checkred.gif"), loc)
     client.sendMessage(str(loc.x) + str(loc.y)) # send location 
     setStatusText("Wait!")
     isMyMove = False
     
def onStateChanged(state):
    global isMyMove
    if state == "CONNECTING":
        setStatusText("Connecting to broker...")    
    elif state == "CONNECTED":
        setStatusText("Connected. Waiting for partner...")    
    elif state == "READY":
        if player == 0:
            setStatusText("Make a move!")
            isMyMove = True    
        else:
           setStatusText("Wait for partner's move!")    
    elif state == "DISCONNECTED":
        setStatusText("Partner disconnected!")    
        isMyMove = False

def onMessageReceived(msg):
    global isMyMove, myHits, partnerHits, isOver      
    if msg == "DISCONNECT":
        setStatusText("Partner disconnected")
        isMyMove = False
        return
    if msg == "hit":
        myHits += 1
        setStatusText("Hit! Partner's fleet size " + str(nbShip - myHits) 
            + ". Wait!")            
        if myHits == nbShip:
            setStatusText("Game over, You won!")
            isOver = True 
    elif msg == "miss":
        setStatusText("Miss! Partner's fleet size " + str(nbShip - myHits)) 
    else:
        x = int(msg[0])
        y = int(msg[1])
        loc = Location(x, y)
        actor = getOneActorAt(loc, Ship)         
        if actor != None:
            actor.removeSelf()     
            refresh()
            client.sendMessage("hit")
            partnerHits += 1             
            if partnerHits == nbShip:
                setStatusText("Game over! Partner won")
                isOver = True 
                return  
        else:
            client.sendMessage("miss")
        setStatusText("You play! Partner's fleet size " + str(nbShip - myHits))            
        isMyMove = True

def onNotifyExit():
    client.disconnect()
    dispose()

makeGameGrid(5, 5, 50, Color.red, False, mousePressed = onMousePressed, 
             notifyExit = onNotifyExit)
addStatusBar(30)
nbShip = 8
for i in range(nbShip):
    addActor(Ship(), getRandomEmptyLocation())
show()
isMyMove = False
isOver = False
myHits = 0
partnerHits = 0
setTitle("Player #" + str(player))
host = "m2m.eclipse.org"
client = GameClient(onStateChanged, onMessageReceived, myTopic)
client.connect(host)

