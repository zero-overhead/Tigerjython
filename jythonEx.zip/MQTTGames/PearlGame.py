# PearlGame.py

from gamegrid import *
from mqttclient import GameClient

player = x # set player = 0 or player = 1
myTopic = "/swissgame/pearlgame"
    
def initGame():
    nbRows = 4
    nb = 6
    for k in range(nbRows):
        for i in range(nb):
            pearl = Actor("sprites/token_1.png")
            addActor(pearl, Location(i + 1, k + 1))
        nb -= 1    
    btn = Actor("sprites/btn_ok_0.gif")
    addActor(btn, Location(6, 5))
                
def onMousePressed(e):
    global isMyMove, nbPearl, isOver, activeRow, nbRemoved
    if not isMyMove or isOver:
         return
    btnLoc = Location(6,5)    
    loc = toLocationInGrid(e.getX(), e.getY())
    if loc != btnLoc:
        x = loc.x
        y = loc.y  
        if activeRow != -1 and activeRow != y:
            setStatusText("You must remove pearls from the same row.")
        else:
            actor = getOneActorAt(loc)
            if actor != None:      
                actor.removeSelf()
                client.sendMessage(str(x) + str(y))
                activeRow = y 
                nbPearl -= 1
                nbRemoved += 1
                refresh()        
                if nbPearl == 0:    
                    isOver = True                    
                    setStatusText("End of game. You lost!")
    elif nbRemoved == 0: # ok btn pressed
        setStatusText("You have to remove at least 1 pearl!")
    else:
        client.sendMessage("ok")          
        setStatusText("Wait!")
        nbRemoved = 0
        activeRow = -1
        isMyMove = False          

def onNotifyExit():
    client.disconnect()
    dispose()
    
def onStateChanged(state):
    global isMyMove
    if state == "CONNECTING":
        setStatusText("Connecting to broker...")    
    elif state == "CONNECTED":
        setStatusText("Connected. Waiting for partner...")    
    elif state == "READY":
        if player == 0:
            setStatusText("Remove any number of pearls from same row and click OK!")
            isMyMove = True    
        else:
           setStatusText("Wait for partner's move!")    
    elif state == "DISCONNECTED":
        setStatusText("Partner disconnected!")    
        isMyMove = False

def onMessageReceived(msg):
    global isMyMove, nbPearl, isOver    
    if msg == "DISCONNECT":
        setStatusText("Partner disconnected")
        isMyMove = False
        return
    if msg == "ok":
        isMyMove = True
        setStatusText("Remove any number of pearls from same row and click OK!")
    else:
         x = int(msg[0])
         y = int(msg[1])
         loc = Location(x, y)            
         getOneActorAt(loc).removeSelf()
         refresh()
         nbPearl -=1
         if nbPearl == 0:
             isOver = True                    
             setStatusText("End of game. You win!")                     
 
makeGameGrid(8, 6, 70, False, mousePressed = onMousePressed, notifyExit = onNotifyExit)
addStatusBar(30)
initGame()
show()
activeRow = -1
nbPearl = 18
nbRemoved = 0
isMyMove = False
isOver = False     
setTitle("Player #" + str(player))
host = "m2m.eclipse.org"
client = GameClient(onStateChanged, onMessageReceived, myTopic)
client.connect(host)
