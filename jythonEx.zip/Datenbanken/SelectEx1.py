# SelectEx1a.py

from sqlite3 import *
from prettytable import *

with connect("demo.db") as con:
    cursor = con.cursor()
    #sql = "SELECT * FROM person"
    #sql = "SELECT * FROM person ORDER BY name"
    #sql = "SELECT name, forename FROM person ORDER BY name"
    #sql = "SELECT * FROM person WHERE name = 'Bauer'"
    #sql = "SELECT * FROM person WHERE geschlecht = 'm'"
    sql = "SELECT * FROM person WHERE 2017 - jahrgang < 15"
    resultset = cursor.execute(sql)
    showTable(resultset)  
