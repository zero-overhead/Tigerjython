# TweetsInput.py

from sqlite3 import *
from entrydialog import *
from prettytable import *

database = "demo.db"
        
def search():
    global vId
    vName = nText.getValue()
    vVorname = vText.getValue()
    print vName, vVorname
    with connect(database) as con:
        cursor = con.cursor()
        sql = """SELECT id, tweet FROM person, tweets WHERE name LIKE '%s' AND vorname LIKE '%s' 
              AND person.id = tweets.userID""" %(vName, vVorname) 
#        sql = """SELECT * FROM person WHERE name LIKE '%s' AND vorname LIKE '%s'""" %(vName, vVorname)                  
        cursor.execute(sql)
        rs = cursor.fetchall()
        if rs == None:
            print "Nicht gefunden"
        else: 
            if rs != []:    
                print rs        
                vId = rs[0][0]            
                t0Text.setValue(rs[0][1])    
                t1Text.setValue(rs[1][1])
                t2Text.setValue(rs[2][1])
            else:
                print "keine Tweets"
            
def insert():
#    global vId
#    print vId
    t0Value = t0Text.getValue()
    if t0Value == None:
        t0Value = 'NULL'
    t1Value = t1Text.getValue()
    if t1Value == None:
        t1Value = 'NULL'
    t2Value = t2Text.getValue()
    if t2Value == None:
        t2Value = 'NULL' 
    with connect(database) as con:
       cursor = con.cursor()
#       sql = "DELETE FROM tweets WHERE userId = " + str(vId)
#       cursor.execute(sql)
       sql = "INSERT INTO tweets VALUES (%s, %s, %s, %s)" %(vId, t0Value, t1Value, t2Value)
       cursor.execute(sql)
       printTable(cursor)
 

    
# --------------- Dialog  -------------
nText = StringEntry("name: ") 
vText = StringEntry("Vorname: ") 
pane1 = EntryPane("User", nText, vText)
searchBtn = ButtonEntry("Search") 
pane2 = EntryPane(searchBtn)
t0Text = StringEntry("Tweet1: ") 
t1Text = StringEntry("Tweet2: ")
t2Text = StringEntry("Tweet3: ") 
pane3 = EntryPane("Tweets", t0Text, t1Text, t2Text)
saveBtn = ButtonEntry("Save") 
pane4 = EntryPane(saveBtn)
dlg = EntryDialog(pane1, pane2, pane3, pane4)
userId = 0
t0Text.setValue(None)
t1Text.setValue(None)
t2Text.setValue(None)

while not dlg.isDisposed():
    if searchBtn.isTouched():
       search()
    elif saveBtn.isTouched():
       insert()
     
   

