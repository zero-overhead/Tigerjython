# CreateTableFollower.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    #cursor.execute("DROP TABLE follower")
    cursor.execute("""CREATE TABLE follower 
                  (userId INTEGER NOT NULL, 
                  followerId INTEGER NOT NULL)""")  
    cursor.execute("""INSERT INTO follower VALUES 
                  (1, 2), (1, 4), (1, 5),(2, 4), (2, 6),(3, 1),
                  (4, 3), (4, 1), (4, 2), (5, 6), (6, 2)""")       
    cursor.execute("SELECT * FROM follower")
    printTable(cursor) 