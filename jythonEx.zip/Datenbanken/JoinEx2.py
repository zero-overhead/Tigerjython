# JoinEx2.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    sql = """SELECT name, vorname, lauf, weitsprung, hochsprung
             FROM person INNER JOIN sport ON person.id = sport.id"""
    cursor.execute(sql) 
    printTable(cursor, align =["l", "l", "r", "r", "r"], sortby = "name")


