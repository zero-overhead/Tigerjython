# ImportEx2.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    sql = """SELECT name,vorname,rang FROM person 
             JOIN babynames ON person.vorname = babynames.vname ORDER BY rang"""
    cursor.execute(sql)
    printTable(cursor)