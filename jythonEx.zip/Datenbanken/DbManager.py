# global variables: currentIndex, resultSet, isInsertMode

from sqlite3 import *
from entrydialog import *

database = "schule.db"

def doFirst():
    global currentIndex
    currentIndex = 0
    showPerson(resultSet[currentIndex])
    status.setValue("Person " + str(currentIndex + 1) + " von " + str(len(resultSet)))

def doLast():
    global currentIndex
    currentIndex = len(resultSet) - 1
    showPerson(resultSet[currentIndex])
    status.setValue("Person " + str(currentIndex + 1) + " von " + str(len(resultSet)))

def doNext():
    global currentIndex
    if currentIndex == len(resultSet) - 1:
        status.setValue("Ende der Datenbank erreicht.")        
        return
    currentIndex += 1
    showPerson(resultSet[currentIndex])
    status.setValue("Person " + str(currentIndex + 1) + " von " + str(len(resultSet)))

def doPrevious():
    global currentIndex
    if currentIndex == 0:
        status.setValue("Beginn der Datenbank erreicht.")        
        return
    currentIndex -= 1
    showPerson(resultSet[currentIndex])
    status.setValue("Person " + str(currentIndex + 1) + " von " + str(len(resultSet)))

def setInsertMode(enable):
    global isInsertMode
    if enable:
        isInsertMode = True
        firstBtn.setEnabled(False)
        lastBtn.setEnabled(False)
        prevBtn.setEnabled(False)
        nextBtn.setEnabled(False)
        insertBtn.setEnabled(False)
        searchBtn.setEnabled(False)
        deleteBtn.setEnabled(False)
        saveBtn.setEnabled(True)
        cancelBtn.setEnabled(True)
        initDialog()
    else:
        isInsertMode = False
        firstBtn.setEnabled(True)
        lastBtn.setEnabled(True)
        prevBtn.setEnabled(True)
        nextBtn.setEnabled(True)
        insertBtn.setEnabled(True)
        searchBtn.setEnabled(True)
        deleteBtn.setEnabled(True)
        saveBtn.setEnabled(True)
        cancelBtn.setEnabled(False)

def initDialog():
    vText.setValue("")
    fText.setValue("")
    jText.setValue(None)
    wText.setValue("")
    gText.setValue("")
    jText.setValue(None)

def initSearchDialog():
    fSearch.setValue("")
    vSearch.setValue("")
    
def showPerson(person):
    fText.setValue(person[1])
    vText.setValue(person[2])
    wText.setValue(person[3])
    gText.setValue(person[4])
    jText.setValue(person[5])

# -------------- Validierung der Eingaben ----------------
def validate(familienname, vorname, wohnort, geschlecht, jahrgang):
    illegal = "Illegale Eingabe. "
    if not isLegal(familienname):
        status.setValue(illegal + "Familienname illegal.")
        return False
    if not isLegal(vorname):
        status.setValue(illegal + "Vorname illegal.")
        return False
    if not isLegal(wohnort):
        status.setValue(illegal + "Wohnort illegal.")
        return False
    if geschlecht not in ['m', 'w']:
        status.setValue(illegal + "Geschlecht muss 'm' oder 'w' sein.")
        return False
    if jahrgang == None:
        status.setValue(illegal + "Jahrgang muss eine Zahl sein.")
        return False
    return True

def isLegal(text):
    if text == "":
        return False    
    forbidden = []
    for i in range(65):
        if i != 32 and i != 46 and i != 45: # space, dot, hyphen
            forbidden.append(chr(i))
    for c in text:
        if c in forbidden:
            return False
    return True
        
def setCurrentIndex():
    global currentIndex
    familienname = fText.getValue().strip()
    vorname = vText.getValue().strip()
    person = find(familienname, vorname)
    if person == None:    
        return False
    personid = person[0]
    indexList = [item[0] for item in resultSet]
    currentIndex = indexList.index(personid)
    return True

def search():
    global currentIndex
    familienname = fSearch.getValue().strip()
    vorname = vSearch.getValue().strip()
    person = find(familienname, vorname)
    if person == None:    
        status.setValue("Suche misslungen. Person nicht in Datenbank gefunden.")
        return
    personid = person[0]
    indexList = [item[0] for item in resultSet]
    currentIndex = indexList.index(personid)
    showPerson(resultSet[currentIndex])
    status.setValue("Suche erfolgreich. Person in Datenbank gefunden.")
    initSearchDialog()      

# ---------------- Datenbank-Operationen ----------------
def getAllRecords():
    global resultSet
    with connect(database)as con:
        cursor = con.cursor()
        sql = "SELECT * FROM person ORDER BY familienname, vorname"
        cursor.execute(sql)
        resultSet = cursor.fetchall()

def find(familienname, vorname):
    with connect(database)as con:
        cursor = con.cursor()
        sql = "SELECT * FROM person WHERE familienname LIKE '%s' AND vorname LIKE '%s'" %(familienname, vorname)
        cursor.execute(sql)
        person = cursor.fetchone()
    return person # None, if not found    
        
def insert():
    a = fText.getValue().strip()
    b = vText.getValue().strip()
    c = wText.getValue().strip()
    d = gText.getValue().strip().lower()
    e = jText.getValue()
    if not validate(a, b, c, d, e):
        return
    if find(a, b) != None:
       status.setValue("Person bereits in Datenbank enthalten.")
       return
    with connect(database)as con:
        cursor = con.cursor()
        sql = """INSERT INTO person 
                 (familienname, vorname, wohnort, geschlecht, jahrgang) 
                 VALUES 
                 ('%s', '%s', '%s', '%s',  %d)""" %(a, b, c, d, e)
        cursor.execute(sql)
    status.setValue("Person erfolgreich in Datenbank aufgenommen.") 
    setInsertMode(False)
    getAllRecords()       
    setCurrentIndex()
    showPerson(resultSet[currentIndex])
 
def update():
    familienname = fText.getValue().strip()
    vorname = vText.getValue().strip()
    wohnort = wText.getValue().strip()
    geschlecht = gText.getValue().strip()
    jahrgang = jText.getValue()
    familiennameOld = resultSet[currentIndex][1]
    vornameOld = resultSet[currentIndex][2]
    if not validate(familienname, vorname, wohnort, geschlecht, jahrgang):
        return
    with connect(database)as con:
        cursor = con.cursor()
        sql = """UPDATE person SET 
               familienname = '%s', 
               vorname = '%s', 
               wohnort = '%s', 
               geschlecht = '%s', 
               jahrgang = '%s' 
               WHERE familienname = '%s' AND vorname = '%s'""" \
               %(familienname, vorname, wohnort, geschlecht, jahrgang, familiennameOld, vornameOld)
        # use global familienname, vorname
        cursor.execute(sql)
    status.setValue("Person erfolgreich mutiert.")
    getAllRecords()       
    setCurrentIndex()

def delete():
    familienname = fText.getValue()
    vorname = vText.getValue()
    if not find(familienname, vorname):
       status.setValue("Löschen misslungen. Person nicht in Datenbank")
       return
    with connect(database)as con:
        cursor = con.cursor()
        sql = "DELETE FROM person WHERE familienname = '%s' AND vorname = '%s'" %(familienname, vorname)
        cursor.execute(sql)
    getAllRecords()       
    if resultSet == []:  # Datenbank leer
        setInsertMode(True)
        status.setValue("Person erfolgreich aus Datenbank entfernt. Datenbank leer.")
    else:
       doFirst()
       status.setValue("Person erfolgreich aus Datenbank entfernt. Zeige ersten Datensatz an.")

# ================== Hauptprogramm ===================
# --------------- Dialog aufbauen -------------
fText = StringEntry("Familienname: ") 
vText = StringEntry("Vorname: ") 
wText = StringEntry("Wohnort: ") 
gText = StringEntry("Geschlecht: (m/w)): ")
jText = IntEntry("Jahrgang (Zahl): ") 
pane1 = EntryPane("Information", fText, vText, wText, gText, jText)
firstBtn = ButtonEntry("First") 
lastBtn = ButtonEntry("Last") 
nextBtn = ButtonEntry("Next") 
prevBtn = ButtonEntry("Prev") 
pane2 = EntryPane("Navigation", firstBtn, prevBtn, nextBtn, lastBtn)
deleteBtn = ButtonEntry("Delete") 
insertBtn = ButtonEntry("Insert") 
saveBtn = ButtonEntry("Save") 
cancelBtn = ButtonEntry("Cancel") 
pane3 = EntryPane("Mutation", deleteBtn, insertBtn, saveBtn, cancelBtn)
fSearch = StringEntry("Familienname: ") 
vSearch = StringEntry("Vorname: ") 
pane4 = EntryPane("Suche", fSearch, vSearch)
searchBtn = ButtonEntry("Search") 
pane5 = EntryPane(searchBtn)
status = StringEntry("")
status.setEditable(False)
pane6 = EntryPane("Status", status)
dlg = EntryDialog(pane1, pane2, pane3, pane4, pane5, pane6)
dlg.setTitle("Databank-Manager")

# --------------- ResultSet für ganze Datenbank holen -------------
resultSet = []
getAllRecords()
if resultSet == []:  # database empty
    setInsertMode(True)
    status.setValue("Datenbank leer.")
else:
    doFirst()
    setInsertMode(False)

# --------------- Ereignisschleife -------------
while not dlg.isDisposed():
    if firstBtn.isTouched():
         doFirst()
         setInsertMode(False)  
    if lastBtn.isTouched():
         doLast()
         setInsertMode(False)  
    if nextBtn.isTouched():
         doNext()  
    if prevBtn.isTouched():
         doPrevious()  
    elif searchBtn.isTouched():
        search()
    elif saveBtn.isTouched():
        if isInsertMode:
            insert()
        else:
            update()
    elif cancelBtn.isTouched():
        if resultSet != []: # not empty database
            setInsertMode(False)
            doFirst()
        else:
            status.setValue("Bitte Personendaten eintragen und Save klicken oder Fenster schliessen.")
    elif deleteBtn.isTouched():
        delete()
    elif insertBtn.isTouched():
        if not isInsertMode:
            setInsertMode(True)
            initDialog()
            status.setValue("Bitte Personendaten eintragen und Save oder Cancel klicken.")
        else:
            insert()
            finishBtn.setEnabled(True)
