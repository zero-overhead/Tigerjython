# InsertPersonEx1.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("""INSERT INTO person VALUES
                  (1,'Huber','Lia','Bern','w', 2002),
                  (2,'Meier','Luca','Basel','m', 2003),
                  (3,'Frech','Marc','Bern','m', 2000),
                  (4,'Bauer','Paul','Luzern','m', 2003),
                  (5,'Zwahlen','Noe','Thun','m', 2002),
                  (6,'Meier','Nina','Biel','w', 2001)""")   
    cursor.execute("SELECT * FROM person")
    printTable(cursor)





