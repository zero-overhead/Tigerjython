# ShowTableSport.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()    
    cursor.execute("SELECT * FROM sport")
    printTable(cursor)
