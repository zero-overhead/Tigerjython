# JoinEx3b.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    sql = """SELECT name, vorname,weitsprung FROM person, sport
          WHERE person.id = sport.id ORDER BY weitsprung DESC"""   
    cursor.execute(sql) 
    printTable(cursor, align =["l", "l", "r"])  