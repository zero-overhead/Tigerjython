# TwitterJoinEx1.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    sql = """SELECT name, vorname, tweet 
             FROM person, tweets 
             WHERE name = 'Huber' AND vorname = 'Lia' AND person.id = tweets.userId"""
    cursor.execute(sql)
    printTable(cursor)
