# CreateTableUsers.py

from sqlite3 import *
from prettytable import printTable

con = connect("demo.db")
with con:
    cursor = con.cursor()
    cursor.execute("DROP TABLE person")
    cursor.execute("""CREATE TABLE person
                  (id INTEGER PRIMARY KEY, 
                  name VARCHAR(30), 
                  vorname VARCHAR(30), 
                  wohnort VARCHAR(30),
                  geschlecht CHAR(1),  
                  jahrgang INTEGER(4))""")
    cursor.execute("""INSERT INTO person VALUES
                  (1,'Huber','Lia','Bern','w', 2002),
                  (2,'Meier','Luca','Basel','m', 2003),
                  (3,'Frech','Marc','Bern','m', 2000),
                  (4,'Bauer','Paul','Luzern','m', 2003),
                  (5,'Zwahlen','Noe','Thun','m', 2002),
                  (6,'Meier','Nina','Biel','w', 2001)""")      
    cursor.execute("SELECT * FROM person")
    printTable(cursor)