# SelectEx2.py

from sqlite3 import *
from prettytable import *

with connect("demo.db") as con:
    cursor = con.cursor()
    sql = "SELECT * FROM person WHERE name = 'Meier' AND vorname = 'Nina'"
    #sql = "SELECT * FROM person WHERE wohnort = 'Thun' OR wohnort = 'Biel'"
    #sql = "SELECT * FROM person WHERE NOT wohnort = 'Bern'"   
    #sql = "SELECT * FROM person WHERE name = 'Meier' AND NOT wohnort = 'Biel'"
    #sql = "SELECT * FROM person WHERE wohnort = 'Bern' AND vorname LIKE 'L%'"
    resultset = cursor.execute(sql)
    printTable(resultset) 
