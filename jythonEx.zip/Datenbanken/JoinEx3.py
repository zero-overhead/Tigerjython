# JoinEx3.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    sql = """SELECT name, vorname, lauf, weitsprung, hochsprung
             FROM person JOIN sport ON person.id = sport.id 
             WHERE lauf <= 13.0 AND weitsprung >= 4.0 AND hochsprung >= 1.2
             ORDER BY name"""   
    cursor.execute(sql) 
    printTable(cursor, align =["l", "l", "r", "r", "r"])  