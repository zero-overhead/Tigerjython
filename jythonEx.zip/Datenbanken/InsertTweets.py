# CreateTableTweets.py

from sqlite3 import *
from prettytable import printTable

def insert(a, b, c, d):
    con = connect("demo.db")
    with con:
        cursor = con.cursor()
        sql = """INSERT INTO tweets 
                 (userId, tweet1, tweet2, tweet3) 
                 VALUES 
                 ('%d', '%s', '%s', '%s')""" %(a, b, c, d)
        cursor.execute(sql)    

insert(2,'Heute gehe ich skifahren',
       'Party bei Marc war mega cool',
       'Der neue Lehrer gefällt mir nicht'),
insert(3,'Ich lerne jetzt programmieren',
       'Nina hat heute coole Jacke an',
       'Wer kommt heute ins Kino?'),
insert (1,'Mein neues Smartphone ist mega gut.',
       'Ich gehe mit Laura ins Kino', NULL)
     
cursor.execute("SELECT * FROM tweets")
printTable(cursor)      

