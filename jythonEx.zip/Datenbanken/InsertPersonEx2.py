# InsertPersonEx2.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("""INSERT INTO person (name,vorname,wohnort,geschlecht,jahrgang)
                   VALUES ('Neuhaus','Lucia','Aarau','w', 2004),
                          ('Hubacher','Julia','Zug','w', 2002)""")
    cursor.execute("SELECT * FROM person")
    printTable(cursor)





