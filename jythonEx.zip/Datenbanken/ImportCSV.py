# ImportCSV.py

from dbtable import *

tabelle = DbTable("vname", "rang")
tabelle.importFromCSV("babynames.csv", ";")
print tabelle
tabelle.save("demo.db", "babynames")
print "done"
