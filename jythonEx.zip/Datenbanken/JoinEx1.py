# JoinEx1.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    sql = """SELECT name,vorname,lauf, weitsprung, hochsprung FROM person 
             JOIN sport ON person.id = sport.id ORDER BY name, vorname"""
    cursor.execute(sql)
    printTable(cursor)
