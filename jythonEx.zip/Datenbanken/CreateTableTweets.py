# CreateTableTweets.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    #cursor.execute("DROP TABLE tweets")
    cursor.execute("""CREATE TABLE tweets
                  (userId NOT NULL, tweet TEXT)""")      
    cursor.execute("""INSERT INTO tweets VALUES
                  (4, 'Nina hat heute coole Jacke an'),
                  (2,'Heute gehe ich skifahren'),
                  (5,'Party bei Marc war mega cool'),
                  (3,'Ich lerne jetzt programmieren'),
                  (1,'Nina hat heute coole Jacke an'),
                  (6,'Wer kommt heute ins Kino?'),
                  (1,'Mein neues Smartphone ist mega gut.')""")          
    cursor.execute("SELECT * FROM tweets")
    printTable(cursor)      

