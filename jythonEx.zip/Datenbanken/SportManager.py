# SportManager.py

from sqlite3 import *
from entrydialog import *
from prettytable import *

database = "demo.db"

def doFirst():
    global currentIndex
    currentIndex = 0
    showPerson(resultSet[currentIndex])
    status.setValue("Person " + str(currentIndex + 1) + " von " + str(len(resultSet)))

def doLast():
    global currentIndex
    currentIndex = len(resultSet) - 1
    showPerson(resultSet[currentIndex])
    status.setValue("Person " + str(currentIndex + 1) + " von " + str(len(resultSet)))

def doNext():
    global currentIndex
    if currentIndex == len(resultSet) - 1:
        status.setValue("Ende der Datenbank erreicht.")        
        return
    currentIndex += 1
    showPerson(resultSet[currentIndex])
    status.setValue("Person " + str(currentIndex + 1) + " von " + str(len(resultSet)))

def doPrevious():
    global currentIndex
    if currentIndex == 0:
        status.setValue("Beginn der Datenbank erreicht.")        
        return
    currentIndex -= 1
    showPerson(resultSet[currentIndex])
    status.setValue("Person " + str(currentIndex + 1) + " von " + str(len(resultSet)))

def validate(lValue, hValue, wValue):
    return True
           
def showPerson(person):
    fText.setValue(person[1])
    vText.setValue(person[2])
    personid = person[0]
    with connect(database) as con:
        cursor = con.cursor()
        sql = "SELECT * FROM sport where id = " + str(personid)
        cursor.execute(sql)
        leistungen = cursor.fetchone()
    if leistungen == None: # Person not yet in table; should not happen
        lEntry.setValue(None)
        wEntry.setValue(None)
        hEntry.setValue(None)
    else:
        # if NULL in table, leistungen[i] = None -> empty entry
        lEntry.setValue(leistungen[1])
        wEntry.setValue(leistungen[2])
        hEntry.setValue(leistungen[3])
      
def setCurrentIndex():
    global currentIndex
    name = fText.getValue().strip()
    vorname = vText.getValue().strip()
    person = find(name, vorname)
    if person == None:    
        return False
    personid = person[0]
    indexList = [item[0] for item in resultSet]
    currentIndex = indexList.index(personid)
    return True

def search():
    global currentIndex
    name = fText.getValue().strip()
    vorname = vText.getValue().strip()
    person = find(name, vorname)
    if person == None:    
        status.setValue("Suche misslungen. Person nicht in Datenbank gefunden.")
        return
    personid = person[0]
    indexList = [item[0] for item in resultSet]
    currentIndex = indexList.index(personid)
    showPerson(resultSet[currentIndex])
    status.setValue("Suche erfolgreich. Person in Datenbank gefunden.")

# ---------------- Datenbank-Operationen ----------------
def getAllRecords():
    global resultSet
    with connect(database) as con:
        cursor = con.cursor()
        sql = "SELECT * FROM person ORDER BY name, vorname"
        cursor.execute(sql)
        resultSet = cursor.fetchall()

def find(name, vorname):
    with connect(database) as con:
        cursor = con.cursor()
        sql = "SELECT * FROM person WHERE name LIKE '%s' AND vorname LIKE '%s'" %(name, vorname)
        cursor.execute(sql)
        person = cursor.fetchone()
    return person # None, if not found    

def insert():
    lValue = lEntry.getValue()
    if lValue == None:
        lValue = 'NULL'
    hValue = hEntry.getValue()
    if hValue == None:
        hValue = 'NULL'
    wValue = wEntry.getValue()
    if wValue == None:
        wValue = 'NULL'
    if not validate(lValue, hValue, wValue):
        return
    personid = resultSet[currentIndex][0]
    with connect(database) as con:
        cursor = con.cursor()
        sql = "DELETE FROM sport WHERE personid = " + str(personid)
        cursor.execute(sql)
        sql = "INSERT INTO sport VALUES (%s, %s, %s, %s)" %(personid, lValue, hValue, wValue)
        cursor.execute(sql)
    status.setValue("Leistungen erfolgreich in Datenbank übernommen.") 

def report(discipline):
    with connect(database) as con:
        cursor = con.cursor()
        if discipline == "all":
            sql = """SELECT name, vorname, lauf, hochsprung, weitsprung 
                  FROM person JOIN sport 
                  ON person.id == sport.id 
                  ORDER BY name, vorname"""
        elif discipline == "lauf":
            sql = """SELECT name, vorname, lauf 
                  FROM person JOIN sport 
                  ON person.id == sport.id 
                  ORDER BY lauf ASC"""
        elif discipline == "hoch":
            sql = """SELECT name, vorname, hochsprung
                  FROM person JOIN sport 
                  ON person.id == sport.id 
                  ORDER BY hochsprung DESC"""
        elif discipline == "weit":
            sql = """SELECT name, vorname, weitsprung
                  FROM person JOIN sport 
                  ON person.id == sport.id 
                  ORDER BY weitsprung DESC"""
        cursor.execute(sql)
        printTable(cursor)
        status.setValue("Report ausgeschrieben.")
    
# ================== Hauptprogramm ===================
# --------------- Dialog aufbauen -------------
fText = StringEntry("name: ") 
vText = StringEntry("Vorname: ") 
pane1 = EntryPane("Sportler/Sportlerin", fText, vText)
firstBtn = ButtonEntry("First") 
lastBtn = ButtonEntry("Last") 
nextBtn = ButtonEntry("Next") 
prevBtn = ButtonEntry("Prev") 
searchBtn = ButtonEntry("Search") 
pane2 = EntryPane(firstBtn, prevBtn, nextBtn, lastBtn, searchBtn)
lEntry = FloatEntry("Laufzeit: ") 
wEntry = FloatEntry("Weitsprung: ")
hEntry = FloatEntry("Hochsprung: ") 
pane3 = EntryPane("Leistungen", lEntry, wEntry, hEntry)
deleteBtn = ButtonEntry("Delete") 
insertBtn = ButtonEntry("Insert") 
saveBtn = ButtonEntry("Save") 
pane4 = EntryPane(saveBtn)
allBtn = ButtonEntry("Alle") 
laufBtn = ButtonEntry("Lauf") 
hochBtn = ButtonEntry("Hoch") 
weitBtn = ButtonEntry("Weit") 
pane5 = EntryPane("Reports/Ranglisten", allBtn, laufBtn, weitBtn, hochBtn)
status = StringEntry("")
status.setEditable(False)
pane6 = EntryPane("Status", status)
dlg = EntryDialog(pane1, pane2, pane3, pane4, pane5, pane6)
dlg.setTitle("Sport-Manager")

# --------------- ResultSet für ganze Datenbank holen -------------
resultSet = []
getAllRecords()
if resultSet == []:  # database empty
    status.setValue("Datenbank leer. Zuerst Persondaten eingeben.")
else:
    doFirst()
    # --------------- Ereignisschleife -------------
    while not dlg.isDisposed():
        if firstBtn.isTouched():
             doFirst()
        if lastBtn.isTouched():
             doLast()
        if nextBtn.isTouched():
             doNext()  
        if prevBtn.isTouched():
             doPrevious()  
        elif searchBtn.isTouched():
            search()
        elif saveBtn.isTouched():
            insert()
        elif allBtn.isTouched():
            report("all")
        elif laufBtn.isTouched():
            report("lauf")
        elif hochBtn.isTouched():
            report("weit")
        elif weitBtn.isTouched():
            report("hoch")
