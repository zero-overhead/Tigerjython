# InsertSport.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("INSERT INTO sport VALUES (5, 12.2, 3.8, 1.15)")
    cursor.execute("INSERT INTO sport VALUES (4, 11.5, 4.2, 1.20)")
    cursor.execute("INSERT INTO sport VALUES (1, 13.1, 3.7, NULL)")
    cursor.execute("INSERT INTO sport VALUES (6, 12.8, 4.5, 1.30)")
    cursor.execute("INSERT INTO sport VALUES (3, 11.9, NULL , 1.25)")
    cursor.execute("INSERT INTO sport VALUES (2, 12.5, 4.1, 1.30)")
    cursor.execute("SELECT * FROM sport")
    printTable(cursor)
    
idEntry = IntEntry("Startnummer:", )
laufEntry = FloatEntry("Laufzeit:", )
weitsprungEntry = FloatEntry("Weitsprung:", )
HochsprungEntry = FloatEntry("Hochspring:", )
pane1 = EntryPane("Select values and press OK", stepEntry, 
        angleEntry, repeatEntry)
pane2 = EntryPane("Select values and press OK", stepEntry, 
        angleEntry, repeatEntry)
okBtn = ButtonEntry("OK") 
pane3 = EntryPane(okBtn)
statusEntry = StringEntry("", "")
pane4 = EntryPane("Status", statusEntry)
dlg = EntryDialog(700, 10, pane1, pane2, pane3)
dlg.setAlwaysOnTop(True)
 
while not dlg.isDisposed():
    if okBtn.isTouched():
        step = stepEntry.getValue()
        angle = angleEntry.getValue()
        n = repeatEntry.getValue()
        if step == None or angle == None or n == None:
            statusEntry.setValue("Illegal input")
            continue        
        clean()    
        for i in range(n):
            forward(step)
            right(angle)
        statusEntry.setValue("") 
dispose()
