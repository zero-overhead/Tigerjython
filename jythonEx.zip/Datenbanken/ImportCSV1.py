# ImportCSV1.py

from dbtable import *

tabelle = DbTable("forename", "rank")
tabelle.importFromCSV("boynames.csv", ";")
print tabelle
tabelle.save("demo.db", "boynames")
print "done"
