# Update.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("""UPDATE person SET wohnort = 'Aarau' 
                   WHERE name = 'Bauer' and  vorname = 'Paul'""")
    cursor.execute("SELECT * FROM person")
    printTable(cursor)

