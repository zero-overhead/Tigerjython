# TweetInput.py

from sqlite3 import *
from entrydialog import *
from prettytable import *

database = "demo.db"

def doFirst():
    global currentIndex
    currentIndex = 0
    showPerson(resultSet[currentIndex])
    status.setValue("Person " + str(currentIndex + 1) + " von " + str(len(resultSet)))

         
def showPerson(person):
    fText.setValue(person[1])
    vText.setValue(person[2])
    personid = person[0]
    with connect(database) as con:
        cursor = con.cursor()
        sql = "SELECT * FROM tweets where userId = " + str(personid)
        cursor.execute(sql)
        tw = cursor.fetchall()
        print tw
    if tw == None: # Person not yet in table; should not happen
        t1Entry.setValue(None)
        t2Entry.setValue(None)
        t3Entry.setValue(None)
#    else:
#        # if NULL in table, tw[i] = None -> empty entry
#        t1Entry.setValue(tw[1])
#        t2Entry.setValue(tw[2])
#        t3Entry.setValue(tw[3])
      
def setCurrentIndex():
    global currentIndex
    name = fText.getValue().strip()
    vorname = vText.getValue().strip()
    person = find(name, vorname)
    if person == None:    
        return False
    personid = person[0]
    indexList = [item[0] for item in resultSet]
    currentIndex = indexList.index(personid)
    return True

def search():
    global currentIndex
    name = fText.getValue().strip()
    vorname = vText.getValue().strip()
    person = find(name, vorname)
    if person == None:    
        status.setValue("Suche misslungen. Person nicht in Datenbank gefunden.")
        return
    personid = person[0]
    indexList = [item[0] for item in resultSet]
    currentIndex = indexList.index(personid)
    showPerson(resultSet[currentIndex])
    status.setValue("Suche erfolgreich. Person in Datenbank gefunden.")

# ---------------- Datenbank-Operationen ----------------
def getAllRecords():
    global resultSet
    with connect(database) as con:
        cursor = con.cursor()
        sql = "SELECT * FROM person ORDER BY name, vorname"
        cursor.execute(sql)
        resultSet = cursor.fetchall()

def find(name, vorname):
    con = connect(database)
    with con:
        cursor = con.cursor()
        sql = "SELECT * FROM person WHERE name LIKE '%s' AND vorname LIKE '%s'" %(name, vorname)
        cursor.execute(sql)
        person = cursor.fetchone()
    return person # None, if not found    

def insert():
    t1Text = "'" + t1Entry.getValue() + "'"
    if t1Text == None:
        t1Text = 'NULL'
    t2Text = "'" + t2Entry.getValue() + "'"
    if t2Text == None:
        t2Text = 'NULL'
    t3Text = "'" + t3Entry.getValue() + "'"
    if t3Text == None:
        t3Text = 'NULL'
    if not validate(t1Text, t2Text, t3Text):
        return
    personid = resultSet[currentIndex][0]
    con = connect(database)
    with con:
        cursor = con.cursor()
        sql = "DELETE FROM tweets WHERE userId = " + str(personid)
        cursor.execute(sql)
        sql = "INSERT INTO tweets VALUES (%d, %s, %s, %s)" %(personid, t1Text, t2Text, t3Text)
        cursor.execute(sql)
    status.setValue("Tweets erfolgreich in Datenbank übernommen.") 

def report(discipline):
    con = connect(database)
    with con:
        cursor = con.cursor()
        if discipline == "all":
            sql = """SELECT name, vorname, tweet1, tweet2, tweet3 
                  FROM person JOIN tweets 
                  ON person.id == tweets.userId 
                  ORDER BY name, vorname"""        
        cursor.execute(sql)
        printTable(cursor)
        status.setValue("Report ausgeschrieben.")
    
# ================== Hauptprogramm ===================
# --------------- Dialog aufbauen -------------
fText = StringEntry("name: ") 
vText = StringEntry("Vorname: ") 
pane1 = EntryPane("User", fText, vText)
firstBtn = ButtonEntry("First") 
lastBtn = ButtonEntry("Last") 
nextBtn = ButtonEntry("Next") 
prevBtn = ButtonEntry("Prev") 
searchBtn = ButtonEntry("Search") 
pane2 = EntryPane(firstBtn, prevBtn, nextBtn, lastBtn, searchBtn)
t1Entry = StringEntry("Tweet1: ") 
t2Entry = StringEntry("Tweet2: ")
t3Entry = StringEntry("Tweet3: ") 
pane3 = EntryPane("Tweets", t1Entry, t2Entry, t3Entry)
deleteBtn = ButtonEntry("Delete") 
insertBtn = ButtonEntry("Insert") 
saveBtn = ButtonEntry("Save") 
pane4 = EntryPane(saveBtn)
allBtn = ButtonEntry("Alle")
pane5 = EntryPane("Report", allBtn)
status = StringEntry("")
status.setEditable(False)
pane6 = EntryPane("Status", status)
dlg = EntryDialog(pane1, pane2, pane3, pane4, pane5, pane6)
dlg.setTitle("Tweet-Manager")

# --------------- ResultSet für ganze Datenbank holen -------------
resultSet = []
getAllRecords()
if resultSet == []:  # database empty
    status.setValue("Datenbank leer. Zuerst Persondaten eingeben.")
else:
    doFirst()
    # --------------- Ereignisschleife -------------
    while not dlg.isDisposed():
        if firstBtn.isTouched():
             doFirst()
        if lastBtn.isTouched():
             doLast()
        if nextBtn.isTouched():
             doNext()  
        if prevBtn.isTouched():
             doPrevious()  
        elif searchBtn.isTouched():
            search()
        elif saveBtn.isTouched():
            insert()
        elif allBtn.isTouched():
            report("all")       
