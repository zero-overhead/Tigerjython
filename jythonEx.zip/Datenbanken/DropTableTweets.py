# DropTableTweets.py

from sqlite3 import *

with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("""DROP TABLE tweets""")    
print "Done"

