# TwitterJoinEx2.py

from sqlite3 import *
from prettytable import printTable

print("Follower of Lia")
with connect("demo.db") as con:
    cursor = con.cursor()
    sql = """SELECT name, vorname, wohnort FROM person, follower 
             WHERE follower.userId = 1 and person.id = follower.followerId"""
    cursor.execute(sql)
    printTable(cursor)
