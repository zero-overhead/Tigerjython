# InsertSport.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("INSERT INTO sport VALUES (5, 12.2, 3.8, 1.15)")
    cursor.execute("INSERT INTO sport VALUES (4, 11.5, 4.2, 1.20)")
    cursor.execute("INSERT INTO sport VALUES (1, 13.1, 3.7, NULL)")
    cursor.execute("INSERT INTO sport VALUES (6, 12.8, 4.5, 1.30)")
    cursor.execute("INSERT INTO sport VALUES (3, 11.9, NULL , 1.25)")
    cursor.execute("INSERT INTO sport VALUES (2, 12.5, 4.1, 1.30)")
    cursor.execute("SELECT * FROM sport")
    printTable(cursor)
