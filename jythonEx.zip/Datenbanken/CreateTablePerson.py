# CreateTablePerson.py

from sqlite3 import *

with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("""CREATE TABLE person
                  (id INTEGER PRIMARY KEY, 
                  name VARCHAR(30), 
                  vorname VARCHAR(30), 
                  wohnort VARCHAR(30),
                  geschlecht CHAR(1),  
                  jahrgang INTEGER)""")       
print("Done")

