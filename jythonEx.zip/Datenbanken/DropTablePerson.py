# DropTablePerson.py

from sqlite3 import *

print "Drop table"
with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("DROP TABLE person")    
print("Done")

