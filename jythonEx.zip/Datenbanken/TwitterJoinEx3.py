# TwitterJoinEx3.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    sql = """SELECT name, vorname, wohnort, geschlecht, jahrgang
             FROM person, follower
             WHERE userId = 4 and person.id = follower.followerId AND geschlecht = 'm'"""
    cursor.execute(sql) 
    printTable(cursor, align =["l", "l", "l", "c", "r"])

