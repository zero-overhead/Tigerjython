# DropTableSport.py

from sqlite3 import *

with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("DROP TABLE sport")    
print("Done")

