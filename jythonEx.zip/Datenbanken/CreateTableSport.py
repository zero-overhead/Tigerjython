# CreateTableSport.py

from sqlite3 import *
from prettytable import printTable

con = connect("demo.db")
with con:
    cursor = con.cursor()
    cursor.execute("""CREATE TABLE sport
                  (id INTEGER, 
                  lauf FLOAT, 
                  weitsprung FLOAT, 
                  hochsprung FLOAT)""")  
    cursor.execute("""INSERT INTO sport VALUES 
                  (5, 12.2, 3.8, 1.15),
                  (4, 11.5, 4.2, 1.20),
                  (1, 13.1, 3.7, NULL),
                  (6, 12.8, 4.5, 1.30),
                  (3, 11.9, NULL , 1.25),
                  (2, 12.5, 4.1, 1.30)""")
    cursor.execute("SELECT * FROM sport")
    printTable(cursor)       

