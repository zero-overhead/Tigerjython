# ImportCSV2.py

from dbtable import *

tabelle = DbTable("forename", "rank")
tabelle.importFromCSV("girlnames.csv", ";")
print tabelle
tabelle.save("demo.db", "girlnames")
print "done"
