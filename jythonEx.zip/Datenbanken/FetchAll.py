# FetchAll.py

from sqlite3 import *

con = connect("dbex1.db")
with con:
    cursor = con.cursor()
    cursor.execute("SELECT * FROM person")
    result = cursor.fetchall()
print result

