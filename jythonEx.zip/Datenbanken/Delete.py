# Delete.py

from sqlite3 import *
from prettytable import printTable

with connect("demo.db") as con:
    cursor = con.cursor()
    cursor.execute("DELETE FROM person WHERE name = 'Meier'")
    cursor.execute("SELECT * FROM person")
    printTable(cursor)

