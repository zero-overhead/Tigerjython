# SelectEx3.py

from sqlite3 import *
from prettytable import *

with connect("demo.db") as con:
    cursor = con.cursor()    
    sql = "SELECT * FROM person WHERE gender = 'm'"    
    resultset = cursor.fetchall
    printTable(resultset)  
