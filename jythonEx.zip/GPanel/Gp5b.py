# Gp5b.py
from gpanel import *

makeGPanel(-30, 30, -30, 30)
g = 255
size = 50

repeat 25:
    setColor(0, g, 0)
    fillRectangle(size,size)
    g = g - 10
    size = size - 2
