# Gp1c.py
from gpanel import *

makeGPanel(0, 20, 0, 20)
line(5, 5, 15, 5)
line(15, 5, 10, 15)
line(5, 5, 10, 15)



  


