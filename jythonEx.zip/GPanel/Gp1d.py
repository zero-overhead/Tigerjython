# Gp1d.py
from gpanel import *

makeGPanel(Size(600, 200))
window(-30, 30, -10, 10)
line(-28, 0, 28, 0)
line(0, -9, 0, 9)



  


