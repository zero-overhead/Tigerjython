# Gp7a.py
from gpanel import *

makeGPanel(-30, 30, 0, 60)

x = -30
while x <= 30:
    if x <= 0:
        setColor("magenta")
    else:    
        setColor("cyan")
    line(0, 50, x, 0)
    x = x + 1
