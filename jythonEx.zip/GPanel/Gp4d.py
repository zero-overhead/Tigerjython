# Gp4d.py
from gpanel import *
from random import randint

def bloom():
    setColor("magenta")
    fillCircle(2)
    setColor("yellow")
    fillCircle(1)

def flower(x):
    pos(x, 0)
    lineWidth(3)
    setColor("green")
    line(x, 0, x, 4)
    pos(x, 6)
    bloom()
    
def garden(n):
    repeat n:
        x = randint(0, 30)
        flower(x)    

makeGPanel(-3, 32, -10, 25)
garden(10)

     