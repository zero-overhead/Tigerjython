# Gp10c.py
from gpanel import *

def onMousePressed(x, y):
    if isLeftMouseButton():
        pos(x, y)
        circle(0.1)
        corners.append((x, y))
    if isRightMouseButton():    
        fillPolygon(corners)

makeGPanel(0, 20, 0, 20, mousePressed = onMousePressed)
corners = []
setColor("magenta")


