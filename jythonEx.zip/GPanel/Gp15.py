import weather
from time import sleep

city = "Bern, CH"
#city = "Zuerich, CH"
#city = "Lugano, CH"
#city = "Geneve, CH"
#city = "Paris, FR"
#city = "London, GB"
#city = "Rome, IT"
#city = "Athens, GR"

while True:
     info = weather.request(city)
     print("temp =", info["temp"], "   humidity =", info["humidity"], "%")
     sleep(5)
