from gpanel import *
import time

dt = 0.01     # Zeitschritt (s)
m = 0.5       # Masse (kg)
k = 4         # Federkonstante (N/kg)
r = 0.1       # Reibungskoeffizient in N/m/s
t = 0; y = 0.8; v = 0 # Anfangsbedingungen

p = GPanel(-1, 11, -1.2, 1.2)
drawPanelGrid(p, 0, 10.0, -1.0, 1.0, "gray")
# p.drawGrid(0, 10.0, -1.0, 1.0, "gray") # python
pSim = GPanel(-1, 1, -1, 1)
pSim.enableRepaint(False)
img = pSim.getImage("sprites/marble.png") 
s = pSim.toWindowWidth(31) # Pixel radius of ball
p.pos(t, y) 
p.lineWidth(2)
while True:
    p.draw(t, y) 
    pSim.clear()
    F = -k*y - r*v   
    a = F/m          
    v = v + a*dt     
    y = y + v*dt     
    pSim.bgColor("yellow") # tigerjython
    # pSim.setBgColor("yellow") # python
    pSim.line(0, 1, 0, y)
    pSim.image(img, - s, y-s) # tigerjython
    # pSim.showImage(img, - s, y-s) # python
    pSim.repaint()
    t = t + dt
    time.sleep(dt)    