# Gp7b.py
from gpanel import *
from random import randint

def randomDot():
    x = randint(-100, 100)
    y = randint(-100, 100)
    if x * x + y * y < 10000:
        setColor("red")
    else:
        setColor("green")
    pos(x, y)            
    fillCircle(0.5)
    
makeGPanel(-100, 100, -100, 100)

i = 0
while i < 50000:
    randomDot()
    i = i + 1
