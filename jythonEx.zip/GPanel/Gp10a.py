# Gp10a.py
from gpanel import *

makeGPanel(-10, 10, -10, 10)
colors = ["red", "blue", "yellow", "magenta", "green", "cyan"]

for c in colors:
    setColor(c) 
    fillCircle(4)
    delay(600)
    
setColor(colors[3])
fillCircle(6)
      

    


