# Gp2b.py
from gpanel import *

makeGPanel(0, 10, 0, 10)

setColor("yellow")
fillRectangle(2, 2, 8, 5)
setColor("red")
fillTriangle(2, 5, 8, 5, 5, 8)
setColor("darkblue")
lineWidth(3)
rectangle(3, 3, 4, 4) 
rectangle(6, 3, 7, 4) 
