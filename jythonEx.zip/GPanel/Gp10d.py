# Gp10d.py
from gpanel import *

def onMousePressed(x, y):
    p = (x, y)
    pos(p)
    fillCircle(0.2)
    for q in corners:
        line(p, q)
    corners.append(p)
  
corners = []
makeGPanel(0, 20, 0, 20, mousePressed = onMousePressed)

