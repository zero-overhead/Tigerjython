# Gp12b.py

from gpanel import *
    
makeGPanel(-1, 11, -10, 110)
drawGrid(0, 10, 0,  100,  "gray")

values = [35, 40, 25, 46, 72, 65, 80, 60, 36]
setColor("red")

x = 1
for y in values:
    fillRectangle(x - 0.3 , 0, x + 0.3 , y)
    x = x + 1 