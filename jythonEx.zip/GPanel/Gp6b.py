# Gp6b.py
from gpanel import *

makeGPanel(0, 40, 0, 40)

i = 0
while i <= 40:
    line(i, 0, 40, i)
    delay(100)
    i = i + 1
