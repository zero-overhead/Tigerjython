# Gp1b.py
from gpanel import *

makeGPanel(0, 10, 0, 10)
line(0, 0, 10, 10)

