# Gp12c.py

from gpanel import *
from math import exp, sin, pi

makeGPanel(-10, 110, -7, 7)
drawGrid(0, 100, -6, 6, "gray")

setColor("blue")
lineWidth(3)
x  = 0
a = 5
k = 0.04
omega = 0.6

while x < 100:
    y = a * exp(-k * x) * sin(omega * x + pi/2) 
    pos(x, y) if x == 0 else draw(x, y)
    x = x + 0.1 