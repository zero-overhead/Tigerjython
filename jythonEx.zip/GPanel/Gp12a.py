# Gp12a.py

from gpanel import *
    
makeGPanel(-6, 6, -30, 30)
drawGrid(-5, 5, -25, 25, "gray")

setColor("blue")
lineWidth(2)
x  = -5
while x < 5:
    y = x ** 3 - 9 * x
    pos(x, y) if x == -5 else draw(x, y)
    x = x + 0.01 