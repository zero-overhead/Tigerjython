# Gp4a.py
from gpanel import *

def flash(c):
    setColor(c)
    fillCircle(3)
    delay(500)
    setColor("white")
    fillCircle(3)
    delay(500)

makeGPanel(-10, 10, -10, 10)

repeat 10:
    flash("red")
    flash("yellow")
    flash("green")

