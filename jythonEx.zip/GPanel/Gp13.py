from gpanel import *
from random import randint

n = 1000
p = [0] * 7
repeat n:
    a = randint(1, 6)
    if a == 1:
        p[1] += 1
    elif a == 2:
        p[2] += 1
    elif a == 3:
        p[3] += 1
    elif a == 4:
        p[4] += 1
    elif a == 5:
        p[5] += 1
    elif a == 6:
        p[6] += 1
print(p)

makeGPanel(-1, 8, -2*n/100, n/4 + n/100)
drawGrid(0, 7, 0, n/4, 7, 10)
title("Anzahl Würfe = " + str(n))
setColor("blue")
for i in range(1, 7):
    fillRectangle(i-0.3 , 0, i + 0.3, p[i])