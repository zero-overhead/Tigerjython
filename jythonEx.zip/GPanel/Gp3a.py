# Gp3a.py
from gpanel import *

makeGPanel(-10, 10, -10, 10)

repeat 10:
    setColor("red")
    fillCircle(3)
    delay(400)
    setColor("white")
    fillCircle(3)
    delay(400)


