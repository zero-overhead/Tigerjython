# Gp1a.py
from gpanel import *

makeGPanel()
line(0, 0, 1, 1)
