# Gp8a.py
from gpanel import *

makeGPanel(0, 20, 0, 20)

for i in range(21):
    line(0, 10, 20, i)
    line(20, 10, 0, i)
    delay(100)
 