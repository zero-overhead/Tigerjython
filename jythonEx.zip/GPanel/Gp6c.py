# Gp6c.py
from gpanel import *

def blueCircle(r):
    setColor("cyan")
    fillCircle(i)
    setColor("black")
    circle(r)
     
makeGPanel(-20, 20, 0, 40)

i = 20
while i > 0:
    pos(0, i)
    blueCircle(i)
    i = i - 1

