# Gp7d.py
from gpanel import *

makeGPanel(0, 20, 0, 20)

x = 1
while x < 20:
    y = 1
    while y < 20:
        pos(x, y)
        if x > 5 and x < 15:
            setColor("red")       
        else:
            setColor("yellow")           
        fillCircle(0.5)
        y = y + 1
    x = x + 1
