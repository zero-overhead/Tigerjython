# Gp7c.py
from gpanel import *

makeGPanel(0, 20, 0, 20)

x = 1
while x < 20:
    y = 1
    while y < 20:
        pos(x, y)
        if x < 5:
            setColor("red")
        elif x < 10:
            setColor("yellow")
        elif x < 15:
            setColor("green") 
        else:
            setColor("magenta")           
        fillCircle(0.5)
        y = y + 1
    x = x + 1
