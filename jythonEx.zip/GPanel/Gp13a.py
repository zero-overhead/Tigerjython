# Gp13a.py
from gpanel import *
from random import randint
n = 10000

def sim():
    k = 1
    r = randint(1, 6)
    while r != 6:
        r = randint(1, 6)
        k += 1
    return k

makeGPanel(-5, 55, -200, 2200)
drawGrid(0, 50, 0, 2000)
title("Waiting on a 6")
setColor("blue")
h = [0] * 51
lineWidth(5)
count = 0
repeat n:
    k = sim()
    print(k)
    count += k
    if k <= 50:
        h[k] += 1
        line(k, 0, k, h[k])
mean = count / n
title("Mean waiting time = " + str(mean))
