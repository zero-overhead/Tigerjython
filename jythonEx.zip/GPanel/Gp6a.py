# Gp6a.py
from gpanel import *

makeGPanel(0, 20, 0, 20)

setColor("red")
i = 1
while i < 20:
    pos(i, i)
    fillCircle(0.5)
    i = i + 1

