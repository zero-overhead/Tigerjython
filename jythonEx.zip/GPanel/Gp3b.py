# Gp3b.py
from gpanel import *
from random import randint

makeGPanel(0, 100, 0, 100)

setColor("red")
repeat 100:
    pos(randint(0, 100), randint(0, 100))
    fillCircle(2)
