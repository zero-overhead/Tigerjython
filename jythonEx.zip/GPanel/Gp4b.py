# Gp4b.py
from gpanel import *

def star(x, y):
    fillTriangle(x - 0.86, y - 0.5, 
                 x + 0.86, y - 0.5, x, y + 1)
    fillTriangle(x - 0.86, y + 0.5, 
                 x + 0.86, y + 0.5, x, y - 1)
    
makeGPanel(0, 10, 0, 10)
setColor("red")
star(2, 2)
star(5, 7) 
star(7, 4)      
     