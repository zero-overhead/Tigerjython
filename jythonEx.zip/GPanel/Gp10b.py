# Gp10b.py
from gpanel import *

makeGPanel(0, 10, 0, 10)
corners = [(4, 2), (1, 4), (3, 7), (6, 8), (7, 5), (5, 3)]
setColor("blue")

for pt in corners:
    fillPolygon(corners)
    
