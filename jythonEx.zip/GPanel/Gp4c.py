# Gp4c.py
from gpanel import *
from random import randint

def star(x, y):
    fillTriangle(x - 0.86, y - 0.5, 
                 x + 0.86, y - 0.5, x, y + 1)
    fillTriangle(x - 0.86, y + 0.5, 
                 x + 0.86, y + 0.5, x, y - 1)
    
makeGPanel(0, 25, 0, 25)
bgColor("darkblue")
setColor("yellow")
repeat 30:
    x = randint(3, 22)
    y = randint(3, 22) 
    star(x, y)
   
     