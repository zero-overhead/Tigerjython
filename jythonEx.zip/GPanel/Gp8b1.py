# Gp8c2.py
from gpanel import *

makeGPanel(-30, 30, -30, 30)

for i in range(60): 
    rectangle(i, i)
    delay(100)

