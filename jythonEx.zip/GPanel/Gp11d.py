#Gp11d.py
from gpanel import *
from time import sleep

dt = 0.01     # Zeitschritt (s)
m = 0.5       # Masse (kg)
k = 4         # Federkonstante (N/kg)
r = 0.1       # Reibungskoeffizient in N/m/s
t = 0; y = 0.8; v = 0 # Anfangsbedingungen

makeGPanel(-1, 1, -1, 1)
enableRepaint(False)
img = getImage("sprites/marble.png") 
s = toWindowWidth(31) # Pixel radius of ball

while True:
    clear()
    F = -k*y - r*v   
    a = F/m          
    v = v + a*dt     
    y = y + v*dt 
    line(0, 1, 0, y)
    image(img, - s, y-s)
    repaint()
    t = t + dt
    sleep(dt)    