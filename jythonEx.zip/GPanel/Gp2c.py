# Gp2c.py
from gpanel import *

makeGPanel(-10, 10, -10, 10)

line(-6, -3, 4, 6)
line(-1, 7, 6, -5)
line(-8, 1, 7, -4)
fill(0, 0, "white", "magenta")
