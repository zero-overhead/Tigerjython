# Gp5c.py
from gpanel import *
from random import randint

n = inputInt("Anzahl Zufallspunkte?")
makeGPanel(0, 100, 0, 100)

setColor("blue")

repeat n:
    pos(randint(0, 100), randint(0, 100))
    fillCircle(2)
