import weather
from gpanel import *

makeGPanel(-5, 53, -3, 52)
drawGrid(0, 50, 0, 50, "gray")
setColor("blue")
lineWidth(2)

x = 0
while True:
     info = weather.request("Bern, CH")
     #info = weather.request("Paris, FR")
     temp = info["temp"]
     if x == 0:
         pos(x, temp)
     else:
         draw(x, temp)          
     print(temp)
     x = x + 1 
     if x == 50:
         x = 0  
         clear()
         drawGrid(0, 50, 0, 50, "gray")              
     delay(1000)
