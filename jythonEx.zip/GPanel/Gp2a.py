# Gp2a.py
from gpanel import *

makeGPanel(-10, 10, -10, 10)
circle(10)
setColor("darkblue")
fillRectangle(19, 6)
setColor("yellow")
fillRectangle(14,14)
setColor("red")
fillCircle(4)
setColor("green")
pos(5, 5)
fillCircle(2)

