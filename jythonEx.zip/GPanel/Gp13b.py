# Gp13b.py
from gpanel import *
from random import random

makeGPanel(-0.3, 1.3, -0.3, 1.3)
rectangle(0, 0, 1, 1)
arc(1, 0, 90)
hits = 0
n = input("Number of rain drops")
i = 0
while i < n:
   x = random()
   y = random()
   if x*x + y*y < 1:
     hits = hits + 1
     setColor("red")
   else:
     setColor("green")  
   i = i + 1
   point(x, y)
pi = 4 * hits / n
title("Result: pi = " + str(pi))
