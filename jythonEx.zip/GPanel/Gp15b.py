import weather
    
city = "Paris, FR"
info = weather.request(city)
print("Aktuelle Wetterdaten:", city, "\n"
      "---------------------------------------", "\n"
      "Temperatur =      ", info["temp"], "°C" "\n"
      "Luftdruck =       ", info["pressure"], "hPa", "\n"
      "Feuchtigkeit =    ", info["humidity"], "%", "\n"
      "Temeratur min =   ", info["temp_min"], "°C", "\n"
      "Temeratur max =   ", info["temp_max"], "°C", "\n"
      "Wetterlage =      ", info["description"], "\n"
      "Sonnenaufgang =   ", info["sunrise"], "\n"
      "Sonnenuntergang = ", info["sunset"], "\n"
      "-----------------------------------------")    

