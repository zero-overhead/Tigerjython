# Gp5a.py
from gpanel import *

makeGPanel(-20, 20, -20, 20)

setColor("blue")
w = 40
y = 0
repeat 20:
    pos(0, y)
    fillRectangle(w, 2)
    w = w - 4
    y = y + 2