#Gp11b.py
from gpanel import *

makeGPanel(0, 100, 0, 100)
y = 50
dx = 0.5
img1 = getImage("sprites/car0.gif") 
img2 = getImage("sprites/car1.gif") 
img3 = getImage("sprites/car3.gif")
images = [img1, img2, img3] 
enableRepaint(False)

while True:
    for img in images:
        x = 0
        while x < 100:
            clear()
            line(0, 50, 100, 50)
            image(img, x, y)
            repaint()
            x = x + dx
            delay(20)  