# Gg6.py

from gamegrid import *

# --------------------- class Pacman ---------------------
class Pacman(Actor):
    def __init__(self):
        Actor.__init__(self, True, "sprites/pacman.gif", 2);

    def tryToEat(self):
        self.show(0)
        actor = getOneActorAt(self.getLocation(), Pill);
        if (actor != None):
            actor.hide()
            self.show(1)

# --------------------- class Pill ---------------------
class Pill(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/pill_0.gif");

def keyCallback(e):
      keyCode = e.getKeyCode()
      if keyCode == 37: # left
          paki.setDirection(180)
      elif keyCode == 38: # up
          paki.setDirection(270)
      elif keyCode == 39: # right
          paki.setDirection(0)
      elif keyCode == 40: # down
          paki.setDirection(90) 
      paki.move()
      paki.tryToEat() 
 
makeGameGrid(10, 10, 60, Color.red, False, keyPressed = keyCallback)
paki = Pacman()
addActor(paki, Location(0,0))
for i in range(10):
    addActor(Pill(), getRandomEmptyLocation())
show()
doRun()
