# Gg9b.py

from gamegrid import *
from soundsystem import *
import random
import math

# --------------------- class Dart --------------------------
class Dart(Actor, GGMouseListener):
    def __init__(self):
        Actor.__init__(self, True, "sprites/dart.gif") 
        self.oldLocation = Location()
    
    def mouseEvent(self, mouse):
        location = toLocationInGrid(mouse.getX(), mouse.getY())
        self.setLocation(location)
        dx = location.x - self.oldLocation.x
        dy = location.y - self.oldLocation.y
        if (dx * dx + dy * dy < 25):
            return True
        phi = math.atan2(dy, dx)
        self.setDirection(math.degrees(phi))
        self.oldLocation.x = location.x
        self.oldLocation.y = location.y
        return True

    def collide(self, actor1, actor2):
        play()
        actor2.removeSelf()
        return 0


# --------------------- main -----------------------------------------
makeGameGrid(600, 600, 1, None, "sprites/town.jpg", False)
setTitle("Move dart with mouse to pick the balloon")
setSimulationPeriod(50)
dart = Dart()
addActor(dart, Location(100, 300))
addMouseListener(dart, GGMouse.lDrag)
dart.setCollisionSpot(Point(30, 0)) # End point of dart needle
for i in range(15):
    balloon = Actor("_sprites/balloon.gif")
    addActor(balloon, Location(int(500 * random.random() + 50 ), 
                                            int(500 * random.random() + 50)))
    dart.addCollisionActor(balloon)
show()
doRun()
openSoundPlayer("wav/explode.wav")
