# Gg3a.py

from gamegrid import *

# --------------- class Fish ----------------------------
class Fish(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/nemo.gif")
    def act(self):
        self.move()
        if self.getX()== 9: 
            self.turn(180)
            self.setHorzMirror(True)
        if self.getX()== 0:
            self.turn(180) 
            self.setHorzMirror(False)

# ------------------- main ---------------------------------
makeGameGrid(10, 10, 60, Color.red, "sprites/reef.gif")
nemo = Fish()
addActor(nemo, Location(1, 3))
show()
