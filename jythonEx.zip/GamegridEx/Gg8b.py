# Gg8b.py

from gamegrid import *

def pressCallback(e):
    global actor, startLoc
    startLoc = toLocationInGrid(e.getX(), e.getY())
    actor = getOneActorAt(startLoc)
 
def dragCallback(e):
    if actor == None:
        return
    startPoint = toPoint(startLoc)
    actor.setLocationOffset(e.getX() - startPoint.x, e.getY() - startPoint.y) 

def releaseCallback(e):
    if actor == None:
        return
    destLoc = toLocationInGrid(e.getX(), e.getY())
    actor.setLocationOffset(0, 0)
    actor.setLocation(destLoc)    

actor = None
startLoc = None

makeGameGrid(8, 8, 70, Color.red, False,  mousePressed = pressCallback, 
             mouseDragged = dragCallback, mouseReleased = releaseCallback)
setTitle("Sort Balls")
for i in range(4):
    ball = Actor("sprites/marble.png")
    addActor(ball, getRandomEmptyLocation())
show()
setSimulationPeriod(20)
doRun()
