# Gg9a.py

from gamegrid import *
from soundsystem import *
import random

# --------------------- class Ball ----------------------------------
class Ball(Actor):

   def __init__(self):
      Actor.__init__(self, True, "sprites/peg.png", 5)  
      
   def act(self):
      step = 1
      loc = self.getLocation()
      dir = (self.getDirection() + step) % 360;

      if loc.x < 20:
         dir = 180 - dir
         self.setLocation(Location(20, loc.y))
      if loc.x > 480:
         dir = 180 - dir
         self.setLocation(Location(478, loc.y))
      if loc.y < 20:
         dir = 360 - dir
         self.setLocation(Location(loc.x, 22))
      if loc.y > 480:
         dir = 360 - dir
         self.setLocation(Location(loc.x, 478))
      self.setDirection(dir)
      self.move()

# --------------------- class MyActorCollisionListener ---------------
class MyActorCollisionListener(GGActorCollisionListener):
   def collide(self, actor1, actor2):
      actor1.setDirection(actor1.getDirection() + 180)
      actor2.setDirection(actor2.getDirection() + 180)
      play()
      return 10

# --------------------- main -----------------------------------------
makeGameGrid(500, 500, 1, False)
setSimulationPeriod(10)
myActorCollisionListener = MyActorCollisionListener()
balls = []
for i in range(5):
   ball = Ball()
   ball.show(i)
   addActor(ball, Location(100 + 50 * i, 100 + 50 * i), random.randint(0, 360))
   ball.addActorCollisionListener(myActorCollisionListener)
   balls.append(ball)

for i in range(5):
   for k in range(i + 1, 5):
      balls[i].addCollisionActor(balls[k])

openSoundPlayer("wav/ping.wav")  
show()
doRun()   
