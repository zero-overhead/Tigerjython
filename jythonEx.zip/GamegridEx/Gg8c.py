# Gg8c.py

from gamegrid import *
import math

# --------------------- class car --------------------------
class Car(Actor, GGMouseListener):
    def __init__(self):
        Actor.__init__(self, True, "sprites/redcar.gif") 
        self.oldLocation = Location()
    
    def mouseEvent(self, e):
        location = toLocationInGrid(e.getX(), e.getY())
        self.setLocation(location)
        dx = location.x - self.oldLocation.x;
        dy = location.y - self.oldLocation.y;
        if dx * dx + dy * dy < 25:
            return True
        phi = math.atan2(dy, dx)
        self.setDirection(math.degrees(phi))
        self.oldLocation = location
 
# --------------------- main ---------------------------------
makeGameGrid(600, 600, 1, False)
setTitle("Move car using mouse drag")
setSimulationPeriod(50)
setBgColor(Color.gray)
car = Car()
addActor(car, Location(50, 50))
addMouseListener(car, GGMouse.lDrag)
show()
doRun()
