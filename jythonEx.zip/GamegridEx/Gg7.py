# Gg7.py

from gamegrid import *

# --------------------- class Fish ---------------------
class Fish(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/snemo.gif")
 
    def act(self):
        self.move()
        if self.getX() == 9:
            self.turn(180)
            self.setHorzMirror(True)
        if self.getX() == 0:
            self.turn(180)
            self.setHorzMirror(False)

# --------------------- class Shark ---------------------
class Shark(Actor):
    def __init__(self):
        Actor.__init__(self, True, "sprites/shark.gif")
 
    def act(self):
        if self.nbCycles % 5 == 0 and not nemo.isRemoved():
            self.setDirection(self.getLocation().
                  getCompassDirectionTo(nemo.getLocation()))
            self.move()
        aNemo = getOneActorAt(self.getLocation(), Fish)
        if aNemo != None:
            aNemo.removeSelf()


makeGameGrid(10, 10, 60, Color.red, "sprites/reef.gif")
nemo = Fish()
addActor(nemo, Location(0, 1))
shark = Shark()
addActor(shark, Location(7, 9))
show()
