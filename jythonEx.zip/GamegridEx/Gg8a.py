# Gg8a.py

from gamegrid import *

# ---------------- class Ghost ----------------
class Ghost(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/ghost.png")
            
# ---------------- main ----------------------
def pressCallback(e):
    global actor 
    location = toLocationInGrid(e.getX(), e.getY())    
    actor = getOneActorAt(location)
    
def dragCallback(e):
    if actor == None:
        return
    location = toLocationInGrid(e.getX(), e.getY())
    actor.setLocation(location)
  

makeGameGrid(10, 10, 60, Color.red, False, 
     mousePressed = pressCallback,
     mouseDragged = dragCallback)
     
ghost1 = Ghost()
ghost2 = Ghost()

addActor(ghost1, Location(5, 5))
addActor(ghost2, Location(2, 3))

show()
doRun()
