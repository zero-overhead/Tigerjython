# Gg4.py

from gamegrid import *

# ------------- class Pacman ---------------------------
class Pacman(Actor):
     def __init__(self):
         Actor.__init__(self, "sprites/pacman.gif", 2)
     def act(self):
          self.move()
          self.showNextSprite()
          if self.getX() == 9:
              self.turn(90)
              self.setHorzMirror(True)
          if self.getX() == 0:
              self.turn(270)
              self.setHorzMirror(False)             
                  
# ---------- main ---------------------------------  
makeGameGrid(10, 10, 60, Color.red)
paki = Pacman()
addActor(paki, Location(0, 0))
show()
doRun()
