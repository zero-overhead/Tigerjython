# Labyrinth.py

from gamegrid import *

def keyCallback(e):
    global isGameOver
    if isGameOver:
        return
    next = None
    keyCode = e.getKeyCode()
    if keyCode == KeyEvent.VK_LEFT:
        if bug.getLocation() == startLocation:
            return True
        next = bug.getLocation().getNeighbourLocation(180)
        bug.setDirection(180)
    if keyCode == KeyEvent.VK_UP:
        next = bug.getLocation().getNeighbourLocation(270)
        bug.setDirection(270)
    if keyCode == KeyEvent.VK_RIGHT:
        next = bug.getLocation().getNeighbourLocation(0)
        bug.setDirection(0)
    if keyCode == KeyEvent.VK_DOWN:
        next = bug.getLocation().getNeighbourLocation(90)
        bug.setDirection(90)

    if next != None and canMove(next):
        bug.setLocation(next)
        refresh()
    if next != None and next == exitLocation:
        isGameOver = True
        addActor(Actor("sprites/gameover.gif"), Location(15, 15))
        refresh()

def canMove(location):
    c = bg.getColor(location)
    #return c != makeColor("black")
    return c != Color.black

def drawMaze():
    for x in range(nbHorzCells):
        for y in range(nbVertCells):
            location = Location(x, y)
            if maze.isWall(location):
                bg.fillCell(location, Color.black)
            else:
                bg.fillCell(location, Color.white)
    return maze
    
# --------------------- main -----------------------------------------
nbHorzCells = 31  # must be odd
nbVertCells = 31  # ditto
cellSize = 18
isGameOver = False
 
makeGameGrid(nbHorzCells, nbVertCells, cellSize, False, keyPressed = keyCallback)
bg = getBg()
exitLocation = Location(nbHorzCells - 1, nbVertCells - 2)
maze = GGMaze(nbHorzCells, nbVertCells)
startLocation = maze.getStartLocation()
drawMaze()
bug = Actor(True, "sprites/ladybug.gif")
addActor(bug, startLocation)
show()  
