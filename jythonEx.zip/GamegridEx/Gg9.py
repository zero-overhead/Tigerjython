# Gg9.py

from gamegrid import *
from soundsystem import *

# --------------------- class Stick ----------------------------------
class Stick(Actor):
    def __init__(self):
        Actor.__init__(self, True, "sprites/stick.gif", 2)  
   
    def act(self):
        step = 1
        loc = self.getLocation()
        dir = (self.getDirection() + step) % 360;
        if loc.x < 50:
            dir = 180 - dir
            self.setLocation(Location(55, loc.y))
        if loc.x > 450:
            dir = 180 - dir
            self.setLocation(Location(445, loc.y))
        if loc.y < 50:
            dir = 360 - dir
            self.setLocation(Location(loc.x, 55))
        if loc.y > 450:
            dir = 360 - dir
            self.setLocation(Location(loc.x, 445))
        self.setDirection(dir)
        self.move()

    def collide(self, actor1, actor2):
        actor1.setDirection(actor1.getDirection() + 180)
        actor2.setDirection(actor2.getDirection() + 180)
        play()
        return 10

# --------------------- main -----------------------------------------
makeGameGrid(500, 500, 1, False)
setSimulationPeriod(10)
stick1 = Stick()
addActor(stick1, Location(200, 200), 30)
stick2 = Stick()
addActor(stick2, Location(400, 400), 30)
stick2.show(1)
stick1.addCollisionActor(stick2)
show()
doRun()
openSoundPlayer("wav/ping.wav")    
