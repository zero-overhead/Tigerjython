# Memory.py

from gamegrid import *

# ---------------- class MemoryCard ----------------
class MemoryCard(Actor):
    def __init__(self, cardNb):
        Actor.__init__(self, ["sprites/cardback.gif", "sprites/card" + str(cardNb) + ".gif"])
        self.cardNb = cardNb
    def getCardNb(self):
        return self.cardNb 
            
def pressCallback(e):
    global card1, card2, takeFirst, nbMoves, isMouseEnabled
    if not isMouseEnabled:
        return
    loc = toLocationInGrid(e.getX(), e.getY())  
    card = getOneActorAt(loc)

    if card.getIdVisible() == 1: # card already visible->ignore
        return True
        
    card.show(1) # make card visible
    if takeFirst: # first card taken
        takeFirst = False
        card1 = card
        setStatusText("# of moves: " + str(nbMoves))
    else:  # second card taken
        card2 = card
        if card1.getCardNb() == card2.getCardNb(): # test if cards have same image
            if isGameOver():
                setStatusText("Game over in " + str(nbMoves) + " trials")
            else:
               takeFirst = True  # yes->may continue with next move
               setStatusText("# of moves: " + str(nbMoves) + ". Pair accepted.")
        else: # no->reject this move, hide the two cards
            isMouseEnabled = False
            wakeUp()

def isGameOver():
   gameOver = True
   for card in getActors():
       if card.getIdVisible() == 0:
          gameOver = False
   return gameOver
   
# ---------------- main ----------------------
takeFirst = True
isMouseEnabled = True
nbMoves = 1
makeGameGrid(4, 4, 115, Color.black, False,  mousePressed = pressCallback)
addStatusBar(30)
setStatusText("Make your choice of card pairs with mouse clicks")
setTitle("Memory")
for i in range(16):
    if i < 8:
        card = MemoryCard(i)
    else:
        card = MemoryCard(i - 8)
    loc = getRandomEmptyLocation()
    addActor(card, loc)   
    card.show(0)  
show()
doRun()

while True:
    putSleep()
    if isDisposed():
       break
    delay(1000)
    card1.show(0)
    card2.show(0)
    takeFirst = True
    setStatusText("# of moves: " + str(nbMoves) + ". Pair rejected. Perform next move.")
    nbMoves += 1
    isMouseEnabled = True
  
