# Gg4a.py

from gamegrid import *

# ------------- class Head ---------------------------
class Head(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/head.png", 3)

    def act(self):     
        self.move()         
        self.showNextSprite()
        if (self.getX() > 500) or (self.getX() < 95):
            self.turn(180)        
                  
# ---------- main ----------------------------  
makeGameGrid(600, 600, 1, Color.lightgray)
addActor(Head(), Location(135, 180))
addActor(Head(), Location(300, 450))
show()
doRun()
