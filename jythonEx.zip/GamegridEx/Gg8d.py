# Gg8d.py

from gamegrid import *
from java.awt import Point

class MyMouseTouchListener(GGMouseTouchListener):
    def mouseTouched(self, actor, mouse, spot):
        actor.removeSelf()
             
# ---------------- main ----------------------
makeGameGrid(600, 120, 1, False)
nbMatches = 20
for i in range(nbMatches):
    match = Actor("sprites/match.gif")
    addActor(match, Location (12 + 30 * i, 60))
    match.addMouseTouchListener(MyMouseTouchListener(), GGMouse.lPress)
show()
doRun()
