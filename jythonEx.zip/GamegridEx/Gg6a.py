# Gg6a.py

from gamegrid import *

# ---------------- Fish ----------------
class Fish(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/nemo.gif")
    
    def act(self):
        self.move()
        if isKeyPressed(38): # UP
            self.setY(self.getY() - 1);
        if isKeyPressed(40): # DOWN
            self.setY(self.getY() + 1);
        if self.getX() == 0 or self.getX() == 9:
            self.turn(180)
            self.setHorzMirror(not self.isHorzMirror())
        
# --------------------- main ---------------------------------
makeGameGrid(10, 10, 60, Color.red, "sprites/reef.gif", False)
setTitle("Push cursor to move up/down")
nemo = Fish()
addActor(nemo, Location(1, 3))
show()
doRun()
