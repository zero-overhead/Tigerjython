# Gg8e.py

from gamegrid import *

class MyMouseTouchListener(GGMouseTouchListener):
    
    def mouseTouched(self, actor, mouse, spot):
        event = mouse.getEvent()
        if event == GGMouse.lPress:
            self.draggedBall = actor
        elif event == GGMouse.lRelease:
            if self.draggedBall != None:
                self.draggedBall.setLocationOffset(Point(0, 0))
        elif event == GGMouse.lDrag:
            if self.draggedBall != None:
                mousePos = Point(mouse.getX(), mouse.getY())
                self.draggedBall.setPixelLocation(mousePos)
        refresh()


makeGameGrid(8, 5, 80, Color.blue, False)
setTitle("Sort Balls")
for i in range(8):
    ball = Actor("sprites/token_1.png")
    addActor(ball, getRandomEmptyLocation())
    ball.addMouseTouchListener(MyMouseTouchListener(),  GGMouse.lPress | 
                                 GGMouse.lRelease | GGMouse.lDrag, True)
show()
