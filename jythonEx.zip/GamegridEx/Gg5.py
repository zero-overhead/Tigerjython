# Gg5.py

from gamegrid import *

# ------------- class Pacman --------------------------
class Pacman(Actor):
     def __init__(self):
         Actor.__init__(self, "sprites/pacman.gif", 2)
     def act(self):
         self.move()
         self.tryToEat()
         self.showNextSprite()
         if self.getX() == 9:
             self.turn(90)
             self.setHorzMirror(True)
         if self.getX() == 0:
             self.turn(270)
             self.setHorzMirror(False)                
     def tryToEat(self):
        self.show(0)
        actor = getOneActorAt(self.getLocation(), Pill)
        if actor != None:
            actor.hide()
            self.show(1)                  
                    
 # ------------- class Pill ---------------------------
class Pill(Actor):
     def __init__(self):
         Actor.__init__(self, "sprites/pill_0.gif")
                        
# ---------------- main ------------------------------
makeGameGrid(10, 10, 60, Color.red)
paki = Pacman()
addActor(paki, Location(0, 0))
for i in range(20):
    addActor(Pill(), getRandomEmptyLocation())
show()
doRun()                                
 
