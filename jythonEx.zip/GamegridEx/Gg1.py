# Gg1.py

from gamegrid import *

makeGameGrid(10, 10, 60, Color.red)
# makeGameGrid(10, 10, 60, Color.red, "sprites/reef.gif")
# makeGameGrid(10, 10, 60, Color.red, "sprites/reef.gif", False)
# makeGameGrid(600, 600, 1, None, "sprites/town.jpg", False)
show()   
