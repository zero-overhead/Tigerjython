# Gg3.py

from gamegrid import *

# -------------- class Fish -----------------------------
class Fish(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/nemo.gif")
    def act(self):
        self.move()
        if (self.getX()== 9) or (self.getX() == 0):
            self.turn(180)
 
# ----------------- main ---------------------------------
makeGameGrid(10, 10, 60, Color.red, "sprites/reef.gif")
nemo = Fish()
addActor(nemo, Location(1, 3))
wanda = Fish()
addActor(wanda, Location(6, 7))
show()
