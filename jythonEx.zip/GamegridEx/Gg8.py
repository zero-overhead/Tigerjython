# Gg8.py

from gamegrid import *

# ---------------- class Fish ----------------
class Fish(Actor):
    def __init__(self):
        Actor.__init__(self, "sprites/nemo.gif");
     
    def act(self):
        self.move()
        if not self.isMoveValid():
            self.turn(180)
            self.setHorzMirror(not self.isHorzMirror())
            
# ---------------- main ----------------------
def pressCallback(e):
    location = toLocationInGrid(e.getX(), e.getY())
    addActor(Fish(), location)

makeGameGrid(10, 10, 60, Color.red, "sprites/reef.gif", False, 
     mousePressed = pressCallback)
show()
doRun()
