# Tu37a.py

from gturtle import *

makeTurtle()
speed(-1)
turtleColor = CheckEntry("Red Turtle Color", False) 
penColor = CheckEntry("Red Pen Color", False)
fillColor = CheckEntry("Red Fill Color", False)
pane1 = EntryPane("Change Standard Turtle Properties", turtleColor, 
        penColor, fillColor)
okBtn = ButtonEntry("Ok") 
pane2 = EntryPane(okBtn)
dlg = EntryDialog(650, 200, pane1, pane2)

while not dlg.isDisposed():
    if isDisposed():
        dlg.dispose()
    if okBtn.isHit():
        tColor = turtleColor.getValue()
        if tColor:
            setColor("red")
        else:
            setColor("cyan")
        pColor = penColor.getValue()
        if pColor:
            setPenColor("red")
        else:
            setPenColor("blue")
        fColor = fillColor.getValue()
        if fColor:
            setFillColor("red")
        else:
            setFillColor("blue")
        clean()    
        for i in range(4):
            forward(150)
            right(90)
        fill(1, 1)        
dispose()  