# pi.py

from gturtle import *
import random

from gturtle import *

def init():
    setPenColor("black")
    for i in range(4):
        forward(200)
        right(90)
    moveTo(0, 200)
    right(90)
    rightArc(200, 90)

makeTurtle() 
hideTurtle()   
addStatusBar(20)
n = 10000
k = 0
init()

for i in range(n):
    zx = random.random()
    zy = random.random()
    if zx * zx + zy * zy <= 1:
        k = k + 1
        setPenColor("red")
    else:
        setPenColor("green")    
    setPos(zx * 200, zy * 200)
    dot(2)
pi = 4 * k/n
setStatusText("PI  =  " + str(pi))           

