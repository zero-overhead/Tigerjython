# Tu8d.py

from gturtle import *
import random

def figure():
    setPenColor("gray")
    setFillColor("gray")
    setPos(0, 100)
    startPath()
    rightArc(100, 90)
    rightArc(50, 180)
    left(180)
    rightArc(50, 180)
    rightArc(100, 90)    
    fillPath()
    
makeTurtle()
hideTurtle()
figure()
n = 20000
hits = 0
addStatusBar(20)

for i in range(n):
    zx = random.randint(0, 200)
    zy = random.randint(0, 200)
    setPos(zx, zy)
    if getPixelColorStr() == "gray" or getPixelColorStr() == "red":
        hits = hits + 1
        setPenColor("red")
    else:
        setPenColor("green")    
    dot(2)
a = hits/n * 100
setStatusText("  Area = " + str(a) + "% of square")  
