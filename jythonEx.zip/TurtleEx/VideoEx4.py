# VideoEx4.py

from gturtle import *

def drawLine(a, b):
    ax = a.getX()
    ay = a.getY()
    a.moveTo(b.getX(), b.getY())
    a.setPos(ax, ay)
    
Options.setPlaygroundSize(320, 240)
tf = TurtleFrame()
rec = VideoRecorder(tf, "multiple.mp4", "320x240")
t1 = Turtle(tf)
t2 = Turtle(tf)
t3 = Turtle(tf)
t4 = Turtle(tf)
t1.setPos(-110, -110)
t2.setPos(-110, 110)
t3.setPos(110, 110)
t4.setPos(110, -110)
t1.speed(-1)
t2.speed(-1)
t3.speed(-1)
t4.speed(-1)    

for i in range(40): 
    drawLine(t1, t2)
    drawLine(t2, t3)
    drawLine(t3, t4)
    drawLine(t4, t1)
    t1.forward(5)
    t2.forward(5)
    t3.forward(5)
    t4.forward(5)
    rec.captureImage(2)
    
rec.finish()
print("all done")   
