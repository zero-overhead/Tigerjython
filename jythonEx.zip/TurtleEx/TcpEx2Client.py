# TcpEx2Client.py

from gturtle import *
from tcpcom import TCPClient

def onCloseClicked():
    client.disconnect()
    dispose()
    
def onStateChanged(state, msg):
    if state == TCPClient.MESSAGE:
        li = msg.split(",")
        if li[0] == "p":
            setPos(float(li[1]), float(li[2]))
        if li[0] == "m":
            moveTo(float(li[1]), float(li[2]))
    if state == TCPClient.DISCONNECTED:
        setStatusText("Server died")          
   
makeTurtle(closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
setPenColor("red")
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
setStatusText("Client connecting...")
if client.connect():
    setStatusText("Connected")

