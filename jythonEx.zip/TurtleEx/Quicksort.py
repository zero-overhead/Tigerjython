# QuickSort.py

from gturtle import *
from random import randint

d = 10
n = 59

def createRandomBars():
    for i in range(n):
        s = randint(1, 500)
        li.append(s) 
    drawAllBars(li)

def drawBar(s):
    left(90)
    penDown()
    forward(s)
    back(s)
    penUp()
    right(90)
    
def drawAllBars(li):
    clear()
    setPos(-290, -250)
    for s in li: 
        drawBar(s)        
        forward(d)
    
def quickSort(li):
   quickSortHelper(li,0,len(li)-1)

def quickSortHelper(li,first,last):
   if first<last:
       splitpoint = partition(li,first,last)
       quickSortHelper(li,first,splitpoint-1)
       quickSortHelper(li,splitpoint+1,last)

def partition(li,first,last):
   pivotvalue = li[first]
   leftmark = first+1
   rightmark = last
   done = False
   while not done:
       while leftmark <= rightmark and li[leftmark] <= pivotvalue:
           leftmark = leftmark + 1
       while li[rightmark] >= pivotvalue and rightmark >= leftmark:
           rightmark = rightmark -1
       if rightmark < leftmark:
           done = True
       else:
           temp = li[leftmark]
           li[leftmark] = li[rightmark]
           li[rightmark] = temp
   temp = li[first]
   li[first] = li[rightmark]
   li[rightmark] = temp
   drawAllBars(li)
   repaint()
   Turtle.sleep(10)     
   return rightmark     

makeTurtle()
enableRepaint(False)
ht()
right(90)
setPenWidth(8)
li = []
createRandomBars()
quickSort(li)