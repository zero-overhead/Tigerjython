# Tu40b.py

from gturtle import *

def fillMe(x, y):
   fill(x, y)   
    
makeTurtle(mouseHit = fillMe)
ht()
  
for n in range (3):
   for k in range(6):
      for i in range(6):
         fd(60).rt(60)   
      left(60) 
   fd(60).rt(120).fd(60)
     
