# TcpEx2Client.py

from gturtle import *
from tcpcom import TCPClient

def onMousePressed(x, y):
    setPos(x, y)
    client.sendMessage("p," + str(x) + "," + str(y) + ",")

def onMouseDragged(x, y):
    moveTo(x, y)         
    client.sendMessage("m," + str(x) + "," + str(y) + ",")

def onCloseClicked():
    client.disconnect()
    dispose()
    
def onStateChanged(state, msg):
    if state == TCPClient.DISCONNECTED:
        setStatusText("Server died")

makeTurtle(mousePressed = onMousePressed, mouseDragged = onMouseDragged, 
           closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
setStatusText("Client connecting...")
if client.connect():
    setStatusText("Dragg the mouse!")
    

    