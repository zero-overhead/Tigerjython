# WebServer2.py

from tcpcom import HTTPServer
from gturtle import *

html = """<!DOCTYPE html>
<html>
  <head> <title>Turtle Remote</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body>
    <h2>Turtle Controller</h2>
    <b>Press to change the direction:</b>
    <form method="get">
    <table>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" style="font-size:24px; height:50px; width:75px" name="btn" value="north"/></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
     <td><input type="submit" style="font-size:24px; height:50px; width:75px" name="btn" value="west"/></td>
     <td><input type="submit" style="font-size:24px; height:50px; width:75px" name="btn" value="stop"/></td>
     <td><input type="submit" style="font-size:24px; height:50px; width:75px" name="btn" value="east"/></td>
    </tr>
    <tr>
     <td>&nbsp;</td>
     <td><input type="submit" style="font-size:24px; height:50px; width:75px" name="btn" value="south"/></td>
     <td>&nbsp;</td>
    </tr>
    </table>
    </form>
  </body>
</html>
"""

def requestHandler(clientIP, filename, params):
    global state     
    if len(params) > 0:
        state = params[0][1]                          
    return html, None        
    
def onCloseClicked():
    server.terminate()
    dispose()

makeTurtle("sprites/beetle.gif", closeClicked = onCloseClicked)
setPos(0, -200)
speed(-1)
server = HTTPServer(requestHandler)
setTitle("Server listening at " + server.getServerIP())
state = 'stop' 
while not isDisposed():
    if state == 'north':
       setHeading(0)     
    elif state == 'west':
       setHeading(-90) 
    elif state == 'south':
       setHeading(180)
    elif state == 'east':
       setHeading(90)          
    if state != 'stop':
       forward(2)        
    delay(10)     
    
   