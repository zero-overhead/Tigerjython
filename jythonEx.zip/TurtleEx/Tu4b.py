# Tu4b.py

from gturtle import *

makeTurtle()

setFillColor("magenta")
startPath()
repeat 5:
    forward(160)
    left(144)
fillPath()



