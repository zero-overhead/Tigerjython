from gturtle import *

def bird1():  
    rightArc(100, 90)
    left(90)    
    rightArc(100, 90)
    left(90)

def bird2():  
    rightArc(100, 98)
    left(135)    
    rightArc(100, 98)
    left(60)
        
makeTurtle()
setLineWidth(3)
hideTurtle()

while True:
    home()
    setPos(-150, 0)
    right(45)    
    bird1()
    delay(200)
    clear()
    home()
    setPos(-151, 50)
    right(60)
    bird2()
    delay(200)
    clear()

    


