# Tu15d.py

from gturtle import *
from random import randint

def star():
    startPath()
    repeat 5:
        forward(40)
        right(144)  
    fillPath()
    
def drawSky():
    clear("darkblue")
    for (x, y, c) in sky:
        setPenColor(c)
        setFillColor(c)
        setPos(x, y)
        star()  
                                
makeTurtle()        
hideTurtle()
sky = []
enableRepaint(False)

repeat(50):
    x = randint (-270, 270)
    y = randint (-320, 320) 
    c = makeColor(randint(0, 255), randint(0, 255), randint(0, 255))
    sky.append((x, y, c))
    
while True:
    drawSky()
    repaint()
    skyTemp = []
    for (x, y, c) in sky:
        if y < -340:
            y = 320
        else:    
            y -= 1
        skyTemp.append((x, y, c))
    sky = skyTemp    
    delay(20)
    
