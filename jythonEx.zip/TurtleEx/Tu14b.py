# Tu14b.py

from gturtle import *

def step():    
    forward(30) 
    right(90)
    forward(30) 
    left(90)   
      
makeTurtle()
f = 262
r = 1.059463

for i in range(2):
    for k in range(3):
        f = f * r * r
        playTone(f, 500, block = False)
        # playTone(f, 500)
        step()        
    f = f * r
    playTone(f, 500, block = False)
    step()
    
