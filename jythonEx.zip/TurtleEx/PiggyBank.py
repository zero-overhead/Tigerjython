# PiggyBank.py

from tcpcom import HTTPServer
from gturtle import *

html = """<!DOCTYPE html>
<html>
  <head> <title>Turtle Donation</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body> 
    <h2>Your Turtle Donation</h2>
    <p><b>Press a button to make a donation for the lucky turtle</b></p>
    <form method="get">
    <input type="submit" style="font-size:40px; height:70px; width:140px" name="donation" value="CHF 1"/>
    <input type="submit" style="font-size:40px; height:70px; width:140px" name="donation" value="CHF 2"/>
    </form>
    <br>
    %s<br>
    Current amount in my piggy bank: %s CHF<br>
  </body>
</html>
"""

thanks = "<b>Thank you for your donation!</b>"

def stateHandler():
    if gift != 0:
        animate(gift)

def requestHandler(clientIP, filename, params):
    global balance, gift
    gift = 0
    if len(params) > 0: 
        value = params[0][1]
        if value == 'CHF+1':
            gift = 1
            balance += gift
        elif value == 'CHF+2':
            gift = 2
            balance += gift
        text = html % (thanks, balance)
    else:
        text = html % ("", balance)
    return text, stateHandler

def onCloseClicked():
    server.terminate()
    dispose()

def animate(gift):
    for y in range(100, -100, -1):
       setPos(0, y)
       if gift == 1:
            drawImage("sprites/onefranc.png")
       else:
            drawImage("sprites/twofranc.png")
       setPos(0, -150)                       
       drawImage("sprites/piggybank.png")
       repaint()
       delay(10)
       clear()
       
makeTurtle(closeClicked = onCloseClicked)
ht()
speed(-1)
balance = 0
gift = 0
server = HTTPServer(requestHandler)
setTitle("Server listening at " + server.getServerIP())
setPos(0, -150)             
drawImage("sprites/piggybank.png")
enableRepaint(False)
