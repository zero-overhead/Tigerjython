# Tu5a.py

from gturtle import *

makeTurtle()
  
addStatusBar(20)
speed(-1)
setPenColor("red")
for s in range(4, 220, 2):
    if s == 140:
        setPenColor("green")
    forward(s)
    right(90)
    setStatusText("Size: " + str(s))

