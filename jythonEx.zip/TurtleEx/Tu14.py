# Tu14.py

from gturtle import *
      
song = [262, 294, 330, 349, 392, 392, 392, 440, 440, 440, 440, 392]

for f in song:
    playTone(f, 200)
    
