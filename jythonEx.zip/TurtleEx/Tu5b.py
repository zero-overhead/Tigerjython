#Tu5b.py

from gturtle import *

makeTurtle()
  
hideTurtle()
for x in range(-200, 200, 20):
    for y in range (-200, 200, 20):
       setPos(x, y)
       if (x > 0 and y > 0) or (x < 0 and y < 0):
            setPenColor("red")
       else:
            setPenColor("green")     
       dot(15)       