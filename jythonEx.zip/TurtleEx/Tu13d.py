# Tu13d.py

from gturtle import *

def onMousePressed(x, y):
    if isLeftMouseButton():
        pt = (x, y)
        setPos(pt)
        dot(8)        
        corner.append(pt)
    if isRightMouseButton():
        setFillColor("red")
        startPath()
        for p in corner:
             moveTo(p)
        fillPath()     
        
makeTurtle(mousePressed = onMousePressed)
hideTurtle()
corner=[]

