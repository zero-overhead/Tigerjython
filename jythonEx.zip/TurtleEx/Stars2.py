# Stars

from gturtle import *
from random import randint

def onMousePressed(x, y): 
    c = colors[randint(0, 4)]
    print(c) 

    setPos(x, y)
    star(c) 

def star(color):
    startPath()
    setFillColor(c)
    repeat 30:
        forward(150)
        right(174.2) 
    fillPath()    

makeTurtle(mousePressed = onMousePressed)
ht()
setPenColor('red')
colors = ["yellow", "green", "blue", "orange", "black"]
c ="yellow"