# VideoEx1.py

from gturtle import *

makeTurtle()
rec = VideoRecorder(getFrame(), "star.mp4", "320x240", -140, -90)

repeat 9:
    forward(150)
    left(160)
    rec.captureImage(10)
rec.finish()
print("all done")   

