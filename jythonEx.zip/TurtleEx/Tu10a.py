# Tu10a.py

from gturtle import *

def figur(size, angle, turn):
    if size < 10:
        return
    while True:  
        flower(size, angle)
        turn = turn + angle
        if turn % 360 == 0:
            break       
def flower(size, angle):
    forward(size)
    dot(15)
    figur(size/2, -angle, 0)
    right(angle)    

makeTurtle()
setPos(-80, -80)
figur(64, 60, 0)
