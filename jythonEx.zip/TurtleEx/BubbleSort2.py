# BubbleSort2.py

from gturtle import *
from random import randint

d = 10
n = 59

def createRandomBars():
    for i in range(n):
        s = randint(1, 500)
        li.append(s) 
    drawAllBars()

def drawBar(s):
    left(90)
    penDown()
    forward(s)
    back(s)
    penUp()
    right(90)
    
def drawAllBars():
    clear()
    setPos(-290, -250)
    for s in li: 
        drawBar(s)        
        forward(d)
    
def bubbleSort():
    for i in range(n-1, 0, -1):
        for k in range(0, i):
            if li[k] > li[k + 1]:
                li[k + 1],li[k] =  li[k],li[k + 1]
                drawAllBars()
                repaint()
                Turtle.sleep(10)                        

makeTurtle()
enableRepaint(False)
ht()
right(90)
setPenWidth(8)
li = []
createRandomBars()
bubbleSort()