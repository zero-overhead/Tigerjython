# Tu5.py

from gturtle import *

makeTurtle()
setPos(-200, -200)
setPenWidth(5)
for i in range(10):
    if i % 2 == 0:
        setPenColor("red")
    else:
        setPenColor("green")
    forward(40)
    right(90)
    forward(40)
    left(90)
