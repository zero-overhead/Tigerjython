 # Rec3.py (p.90)

from gturtle import *

def cornerpoly(size, angle, turn):
   if size < 20:
      return
   while True:  
      cornerpolystep(size, angle)
      turn = turn + angle
      if turn % 360 == 0:
         return       
def cornerpolystep(size, angle):
    forward(size)
    cornerpoly(size/2, -angle, 0)
    right(angle)    

makeTurtle()
setPos(-20, -50)
ht()
cornerpoly(128, 144, 0)
