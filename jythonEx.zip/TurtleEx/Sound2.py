from gturtle import *

def step():    
    forward(30) 
    right(90)
    forward(30) 
    left(90)   
      
makeTurtle()
hideTurtle()
f = 262
r = 1.059463

repeat(2):
    repeat(3):
        step()
        f = f * r * r
        playSound(f, 200)
    step()
    f = f * r
    playSound(f, 200)
    
    
