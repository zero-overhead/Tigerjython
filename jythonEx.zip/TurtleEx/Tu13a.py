#TuA13_1.py

from gturtle import *

makeTurtle()

li = [71, 100, 0, 0, 71, 100]

for s in li:
    right(45)
    forward(s)
    
for s in li:
    right(45)
    forward(3 * s)
    
for s in li:
    right(45)
    forward(0.5 * s)
    

    

