# Tu9b.py

from gturtle import *

def draw(t):
    t.forward(100)
    t.dot(20)
    t.back(100)
    t.right(45)
    
tf = TurtleFrame()
laura = Turtle(tf, "sprites/beetle.gif")
laura.setPenColor("red")
laura.setPos(-140, 0)
luka = Turtle(tf, "sprites/cuteturtle.gif")
luka.setPos(140, 0)

for i in range (8):
    draw(laura)
    draw(luka)
