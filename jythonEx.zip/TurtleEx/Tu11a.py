# Tu11a.py

from gturtle import *

def onKeyPressed(key):

    if key == 37:
        setHeading(-90)
        fd(10)
    elif key == 39:
        setHeading(90)
        fd(10)
    elif key == 38:
        setHeading(0)
        fd(10)
    elif key == 40:
        setHeading(180)
        fd(10)

makeTurtle(keyPressed = onKeyPressed)
speed(-1)
addStatusBar(20)
setStatusText("Use cursor keys to move me!")

