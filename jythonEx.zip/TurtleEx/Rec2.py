 # Rec2.py

from gturtle import *

def cornerpoly(size, angle, turn):
   if size < 20:
      return
   while True:  
      cornerpolystep(size, angle)
      turn = turn + angle
      if turn % 360 == 0:
         break       
def cornerpolystep(size, angle):
    forward(size)
    cornerpoly(size/2, -angle, 0)
    right(angle)    

makeTurtle()
setPos(-80, -80)
cornerpoly(128, 80, 0)
