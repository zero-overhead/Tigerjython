# Tu13e.py

from gturtle import *
import random

def onMousePressed(x, y):
    if isLeftMouseButton():
        pt = (x, y)
        setPos(pt)
        dot(5)        
        corner.append(pt)
    if isRightMouseButton():
        setFillColor("gray")
        startPath()
        for p in corner:
             moveTo(p)
        fillPath()
        wakeUp()        

def startRandomRain():
    nbHit = 0
    for i in range(n):            
            p = (random.randint (-300, 300), random.randint (-300, 300))
            setPos(p)
            color = getPixelColorStr() 
            if color == "white":
                setPenColor("green")                
                dot(2)
            if color == "gray" or color == "red":
                nbHit += 1
                setPenColor("red")                
                dot(2)
    setStatusText("#hits: " + str(nbHit) + " of " + str(n) 
                + " = " + str(nbHit/n * 100) + " % of window area") 
                               
makeTurtle(mousePressed = onMousePressed)
addStatusBar(20)
setStatusText("Left click to select corners, right click to start dropping") 
setPenColor("gray")
hideTurtle()
corner=[]
n = 100000
putSleep()
startRandomRain()

