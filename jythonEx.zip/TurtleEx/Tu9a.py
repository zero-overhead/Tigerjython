# Tu9a.py

from gturtle import *

def segment(t):
    t.forward(140)
    t.right(160)

tf = TurtleFrame()
joe = Turtle(tf)
luka = Turtle(tf)
sara = Turtle(tf)
luka.setColor("red")
sara.setColor("green")
luka.setPenColor("red")
sara.setPenColor("green")
joe.setPos(-135, -50)
luka.setPos(-10,-50)
sara.setPos(115,-50)

for i in range(9):
    segment(joe)
    segment(luka)
    segment(sara)

