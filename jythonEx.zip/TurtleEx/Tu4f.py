from gturtle import *

makeTurtle()
wrap();
left(70)
forward(10000)