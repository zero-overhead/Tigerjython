# Tu7.py

from gturtle import *

def arc():
    for i in range(30):
        forward(4)
        right(3)
  
def petal():
    arc()
    right(90)
    arc()

def flower():
    for k in range(8):
        petal()
        right(45)

makeTurtle()
speed(-1)
flower()
