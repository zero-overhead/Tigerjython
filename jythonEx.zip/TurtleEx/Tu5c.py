# Tu5c.py

from gturtle import *

makeTurtle()
fillToPoint(0, 0)   
for k in range(6):
    if k == 0:
        setPenColor("red")
    elif k == 1:
        setPenColor("yellow")
    elif k == 2:
        setPenColor("blue")
    elif k == 3:
        setPenColor("green")
    else:
        setPenColor("black")
        
    for i in range(3):
        forward(100)
        right(120)
    right(60)
 

