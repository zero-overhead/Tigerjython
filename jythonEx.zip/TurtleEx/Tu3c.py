# Tu3b.py

from gturtle import *

makeTurtle()
  
speed(-1)
for x in range(-200, 200, 70):
    setPos(x, 0)
    for i in range(5):
        forward(80)
        right(144)

