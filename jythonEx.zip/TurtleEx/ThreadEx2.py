# ThreadEx2.py

from gturtle import *
from thread import start_new_thread

def go(t):
    start_new_thread(draw, (t, ))

def draw(t):
    for i in range(5):
        square(t)
    
def square(t):    
    for i in range(4):
        t.forward(40).right(90)
    t.forward(40)

tf = TurtleFrame()
john = Turtle(tf)
laura = Turtle(tf, "red")
sara = Turtle(tf, "green")
john.setPos(-100, -100)
laura.setPos(-20, -100)
sara.setPos(60, -100)
laura.setPenColor("red")
sara.setPenColor("green")
go(john)
go(laura)
go(sara)

