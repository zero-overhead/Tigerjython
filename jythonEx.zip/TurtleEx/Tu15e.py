# Tu15e.py

from gturtle import *

makeTurtle()
hideTurtle()
penUp()
setPos(200, 0)
left(90)
enableRepaint(False)
wrap()

img = ["sprites/pony_0.gif", "sprites/pony_1.gif", "sprites/pony_2.gif",
       "sprites/pony_3.gif", "sprites/pony_4.gif", "sprites/pony_5.gif",
       "sprites/pony_6.gif", "sprites/pony_7.gif"] 
repeat:
    for i in img:
        drawImage(i)
        repaint()
        delay(100)
        clear()
        forward(5)

