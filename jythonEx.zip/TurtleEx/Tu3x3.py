# Tu3x3.py

from gturtle import *

makeTurtle()
ht()
for i in range(50, 150, 8):
    forward(i)
    left(90)    

