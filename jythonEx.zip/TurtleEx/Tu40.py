# Tu40.py

from gturtle import *

def fillMe(x, y):
   fill(x, y)   
    
makeTurtle(mouseHit = fillMe)
ht()
  
for k in range(24):
   for i in range(8):
      forward(60)
      right(45)
   left(15)   
