# Tu21.py

from ch.aplu.turtle import Turtle

class RedTurtle(Turtle):
   def __init__(self):
      self.setColor("red")
      self.setPenColor("red")
   def star(self, s):
      self.fillToPoint(self.getX(), self.getY())
      for i in range(6):
         self.forward(s)
         self.right(140)
         self.forward(s)
         self.left(80)

t = RedTurtle()
t.speed(-1)
t.star(50)
t.setPos(-100, -100)
t.star(30)
t.setPos(100,120)
t.star(40)
t.hideTurtle()
