# WebServer3.py

from tcpcom import HTTPServer
from gturtle import *

html = """<!DOCTYPE html>
<html>
  <head> <title>Turtle Remote</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body>
    <h2>Turtle Controller</h2>
    <b>Press to change the direction:</b>
    <form method="get">
    <table>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" style="font-size:24px; height:50px; width:100px" name="btn" value="forward"/></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><input type="submit" style="font-size:24px; height:50px; width:100px" name="btn" value="left"/></td>
      <td><input type="submit" style="font-size:24px; height:50px; width:100px" name="btn" value="stop"/></td>
      <td><input type="submit" style="font-size:24px; height:50px; width:100px" name="btn" value="right"/></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" style="font-size: 24px; height: 50px; width: 100px" name="btn" value="back" /></td>
      <td>&nbsp;</td>
      </tr>
     </table>
     </form>
  </body>
</html>
"""

def requestHandler(clientIP, filename, params):
    global state 
    if len(params) > 0:
        state = params[0][1]                          
    return html, None         
    
def onCloseClicked():
    server.terminate()
    dispose()

makeTurtle("sprites/tinycar.png", closeClicked = onCloseClicked)
drawImage("sprites/racetrack.gif")
setPos(160, -200)
speed(30)
server = HTTPServer(requestHandler)
setTitle("Server listening at " + server.getServerIP())
state = 'stop'
while not isDisposed():
    if state == 'forward':
       forward(2)
    elif state == 'left':
       leftArc(25, 5)
       forward(2)    
    elif state == "right":
       rightArc(25, 5)
       forward(2) 
    elif state == 'back':
       back(2)        
    else:
        delay(50)   
    
   
