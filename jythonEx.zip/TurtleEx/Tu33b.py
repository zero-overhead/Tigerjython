# Tu33.py

from gturtle import *

def drawPiano():
    setPenColor("brown")
    for x in range(-200, 160, 50):
        setPos(x, -100)
        for k in range(2):
            fd(216).rt(90).fd(50).rt(90)
    setPenColor("black")
    setLineWidth(32)
    for x in [-150, -100, 0, 50, 100, 200]:
        setPos(x, 0)
        fd(100)

def onMouseHit(x, y):
    if x > -200 and x < 215 and y > -100 and y < 100:
        i = int((x + 200)/50)
        setPos(x, y)
        if getPixelColorStr() == "black":
            k = int((x + 215) / 50)
            f = blacktones[k]
        else:
            f = whitetones[i]
        playTone(f, 200, instrument = "piano")

whitetones = ["c'", "d'", "e'", "f'", "g'", "a'", "h'", "c''", 0]
blacktones = [0, "c#'", "d#'", 0, "f#'", "g#'", "a#'", 0, "c#''"]

makeTurtle(mouseHit = onMouseHit)
hideTurtle()
drawPiano()
addStatusBar(20)
setStatusText("Click a piano key to play!") 