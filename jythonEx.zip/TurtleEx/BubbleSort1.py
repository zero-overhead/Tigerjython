# BubleSort1.py

def bubbleSort(li):
    n = len(li)
    for i in range(n - 1, 0, -1):
        for k in range(i):
            if li[k] > li[k + 1]:
                li[k + 1],li[k] =  li[k],li[k + 1]
                 
li = [85, 34, 57, 13, 25, 39, 44, 7, 68, 30]
bubbleSort(li)
print(li)        