# Tu14d.py

from gturtle import *
import random

def drawPiano():
    setPenColor("black")
    for x in range(-200, 160, 50):
        setPos(x, -100)
        for k in range(2):
            fd(216).rt(90).fd(50).rt(90)
    setPenWidth(32)
    for x in [-150, -100, 0, 50, 100, 200]:
        setPos(x, 0)
        fd(100)

whitetones = ["c'", "d'", "e'", "f'", "g'", "a'", "h'", "c''"]
blacktones = ["c#'", "d#'", "f#'", "g#'", "a#'", "c#''"] 

makeTurtle()
hideTurtle()
drawPiano()
showTurtle()

for n in range(30):
    i = random.randint(0, 13)
    if i < 8:
        x = i * 50 - 175
        setPos(x, -50)
        f = whitetones[i]
    else:
        blackPos = [-150, -100, 0, 50, 100]
        k = i - 9 
        x = blackPos[k]
        setPos(x, 30)    
        f = blacktones[k]
    playTone(f, 100, instrument = "piano")    
  
