from gturtle import *

makeTurtle()

KEY_LEFT = 37
KEY_RIGHT = 39
KEY_UP = 38
KEY_DOWN = 40

step = 10

while True:
   key = getKeyCodeWait()
   print(str(key))
   if key == KEY_LEFT:
      setHeading(-90)
      forward(step)
   elif key == KEY_RIGHT:
      setHeading(90)
      forward(step)
   elif key == KEY_UP:
      setHeading(0)
      forward(step)
   elif key == KEY_DOWN:
      setHeading(180)
      forward(step)
