# Tu4d.py

from gturtle import *

makeTurtle()

clear("black")
for x in range(-250, 250, 75):
    setPos(x, x + 30)
    color = askColor("Farbauswahl", "yellow")
    setPenColor(color)
    fillToPoint(x, x)
    for i in range(6):
        fd(30).rt(120).fd(30).lt(60)  
