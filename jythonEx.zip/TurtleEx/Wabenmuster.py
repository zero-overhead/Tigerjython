# Wabenmuster.py

from gturtle import *

def wabe(s):
    if s == 0:
        return
    forward(a)
    left(60)
    wabe(s - 1)
    right(120)
    wabe(s - 1)
    left(60)
    back(a)

makeTurtle()
hideTurtle()
a = 20
s = 12
wabe(s)

