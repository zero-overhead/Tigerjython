# Sierpi.py

from gturtle import *

def triangle(s):
   for i in range(3):
      fd(s)
      lt(120)   
   fill(getX() + 10, getY() + 10)

def sierpi(n, s):
   if n == 0: 
      triangle(s)  
      return
   sierpi(n - 1, s / 2)
   fd(s / 2)
   sierpi(n - 1, s / 2)
   lt(120)
   fd(s / 2)
   rt(120)
   sierpi(n - 1, s / 2)
   lt(60)
   bk(s / 2)
   rt(60)
    
makeTurtle()
n = 4
s = 400
hideTurtle()
setPos( -200, -190)
rt(90)
sierpi(n, s)
