#Tu13c.py

from gturtle import *

makeTurtle()

house = [(0, 60), (50, 110), (100, 60), (100, 0), (0, 0)]

for p in house:
    moveTo(p)
