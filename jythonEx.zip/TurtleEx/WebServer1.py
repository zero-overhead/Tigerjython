# WebServer1.py

from tcpcom import HTTPServer
from gturtle import *

html = """<!DOCTYPE html>
<html>
  <head> <title>Turtle Remote</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body>
     <h2>Turtle Controller</h2>
     <b>Press to change the color:</b><br><br>
     <form method="get">
       <input type="submit" style="font-size:40px; height:60px; width:150px" name="c" value="red"/>
       <input type="submit" style="font-size:40px; height:60px; width:150px" name="c" value="green"/>
     </form>   
  </body>
</html>
"""

def requestHandler(clientIP, filename, params):        
    if len(params) > 0:
        color = params[0][1]
        star(color)
    return html,None 

def star(color):
    setFillColor(color)
    setPenColor(color)
    startPath()
    repeat 5:
        forward(200)
        left(144)
    fillPath() 
    
def onCloseClicked():
    server.terminate()
    dispose()      
          
makeTurtle(closeClicked = onCloseClicked)
ht()
server = HTTPServer(requestHandler)
setTitle("Server listening at " + server.getServerIP())
star("red")
  