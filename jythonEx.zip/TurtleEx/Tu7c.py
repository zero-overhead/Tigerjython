# Tu7c.py
from gturtle import *

def figure(a, q, s):
    for i in range(1, q):
        forward(s * i)
        left(180 - a)    

makeTurtle()
#hideTurtle()
n = 4
repeat n:
   figure(90, 8, 20)

