 # Rec1.py

from gturtle import *

def figur(size, angle, turn):
   if size < 10:
      return
   while True:  
      step(size, angle)
      turn = turn + angle
      if turn % 360 == 0:
         break       
def step(size, angle):
    forward(size)
    figur(size/2, -angle, 0)
    right(angle)    

makeTurtle()
#ht()
setPos(-80, -80)
figur(64, 60, 0)
