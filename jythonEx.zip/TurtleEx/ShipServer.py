# ShipServer.py

from gturtle import *
from tcpcom import TCPServer
import random 

def drawBoard():    
    setPenColor("gray")
    clear("aliceblue")
    for x in range(-250, 250, 50):   
        setPos(x, 0)
        setFillColor("blue")
        startPath()
        repeat 4:
            forward(50)
            right(90)
        fillPath()  
     
def createShips():    
    li = random.sample(range(1, 10), 4) # 4 unique random numbers 1..10
    for i in li:       
        setPos(-275 + i * 50, 25)
        drawImage("sprites/boat.gif")                                 
                                                                             
def onMousePressed(x, y):
    global isMyTurn
    setPos(x, y) 
    if getPixelColorStr() == "aliceblue" or isOver or not isMyTurn:
        return
    nb = int((x + 250) / 50) + 1 # cell number
    server.sendMessage(str(nb))
    isMyTurn = False

def onCloseClicked():
    server.terminate()
    dispose()
    
def onStateChanged(state, msg):
    global isMyTurn, myHits, partnerHits 
    if state == TCPServer.CONNECTED:
        setStatusText("Partner entered my game room")        
    if state == TCPServer.MESSAGE:        
        if msg == "hit":
            myHits += 1
            setStatusText("Hit! Partner's remaining fleet size " + str(4 - myHits))
            if myHits == 4:
                setStatusText("Game over, You won!") 
                isOver = True
        elif msg == "miss":
            setStatusText("Miss! Partner's remaining fleet size " + str(4 - myHits))
        else:        
            nb = int(msg) # cell number          
            x = -275 + nb * 50            
            setPos(x , 25)  
            if getPixelColorStr() != "blue":
                server.sendMessage("hit")                
                setPenColor("blue")
                dot(45) # erase ship
                partnerHits += 1                     
                if partnerHits == 4:
                    setStatusText("Game over! Partner won!")
                    isOver = True
                    return                                        
            else:
                server.sendMessage("miss")
            setStatusText("Make your move!")         
            isMyTurn = True
    
makeTurtle(mousePressed = onMousePressed, closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
drawBoard()
createShips()
port = 5000
server = TCPServer(port, stateChanged = onStateChanged)
setStatusText("Waiting for game partner to enter the game room...")
isOver = False
isMyTurn = False
myHits = 0
partnerHits = 0