# Tu8b.py

from gturtle import *
import random

makeTurtle()        
speed(-1)
wrap()
fillToPoint(0, 0)
for i in range(200):
     r = random.randint(0, 255)
     g = random.randint(0, 255)
     b = 255
     c = Color(r, g, b)
     setPenColor(c)
     if random.random() < 0.5:
         right(90)
     else:
         left(90)
     forward(80 * random.random())

