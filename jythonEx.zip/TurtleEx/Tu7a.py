# Tu7a.py

from gturtle import *

def arc():
    for i in range(30):
        forward(3)
        right(3)
  
def petal():
    arc()
    right(90)
    arc()

def flower(x, y, color):
    setPos(x, y)
    setPenColor(color)
    fillToPoint(x, y)
    for k in range(6):
        petal()
        right(30)
    setPenColor("green")
    dot(20)          
    
makeTurtle()
ht()
speed(-1) 
flower(-150, -100, "red")
hideTurtle()
flower(-100, 120, "yellow")
flower(120, 30, "blue")
flower(color = "magenta", x = 80, y = -150)
