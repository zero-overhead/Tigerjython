# BubbleSort3.py

from gturtle import *
from random import randint

d = 15
n = 41

def createRandomDots():
    for i in range(n):
        c = makeColor("rainbow", randint(10, 90) / 100)
        li.append(c)
    drawAllDots()    
        
def drawAllDots():
    setPos(-295, 0)
    for c in li:
        setPenColor(c)
        dot(d - 1)
        forward(d)    

def getHsb(c):
    hsb = Color.RGBtoHSB(c.getRed(), c.getGreen(), c.getBlue(), [0, 0, 0])
    return hsb[0]
   
def bubbleSort():
    for i in range(n - 1, 0, -1):
        for k in range(i):
            if getHsb(li[k]) > getHsb(li[k + 1]):
                li[k + 1],li[k] =  li[k],li[k + 1]                
                drawAllDots()
                repaint()
                Turtle.sleep(10)
 
makeTurtle()
clear("black")
enableRepaint(False)
right(90)
li = []
createRandomDots()
bubbleSort()