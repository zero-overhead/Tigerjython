from gturtle import *

def quadrat(seite):    
    repeat(4): 
        forward(seite) 
        right(90)
      
makeTurtle()
hideTurtle()
s = 5
f = 264

repeat(2):
    repeat(3):
        quadrat(s)
        s = s + 10
        f = 1.122 * f
        playTone(f, 200)
    repeat(1):
        quadrat(s)
        s = s + 10
        f = 1.059 * f
        playTone(f, 200)
    
    
