# VideoEx3.py 

from gturtle import *

def drawBird(angle):
    dot(20)
    right(angle)
    rightArc(80, 90)
    home()
    left(angle)
    leftArc(80, 90)
    home()
    
def move(start, end, step):
    for a in range(start, end, step):
        clear("lightSkyBlue")   
        drawBird(a)
        rec.captureImage()
    
Options.setPlaygroundSize(320, 240)
t = makeTurtle()
rec = VideoRecorder(t, "bird.mp4", "320x240")
hideTurtle()
setPenWidth(5)
setPenColor("black")

for i in range(4):
    move(55, 5, -2)
    move(5, 55, 2) 

rec.finish()
print("all done")   

