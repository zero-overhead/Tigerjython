#Tu4c.py

from gturtle import *

makeTurtle()

hideTurtle()
c = makeColor(19, 97, 129)
c2 = makeColor(198, 21 , 58)
setPenColor(c)
dot(100)
forward(100)
setPenColor(c2)
dot(100)