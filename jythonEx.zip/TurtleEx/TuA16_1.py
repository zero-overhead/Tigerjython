# VideoA_1.py

from gturtle import *
from random import randint

Options.setPlaygroundSize(320, 240)
makeTurtle()
rec = VideoRecorder(getFrame(), "flowers.mp4", "320x240")
hideTurtle()
clear("green")

for n in range(15):
    x = randint(-150, 150)
    y = randint(-100, 100)
    setPos(x, y)
    setPenColor("red")
    for i in range(6):
        forward(15)
        dot(15)
        back(15)
        left(60)
    setPenColor("yellow")   
    dot(15)
    rec.captureImage(10)
rec.finish()
print("all done")   

