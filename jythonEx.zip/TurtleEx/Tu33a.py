# Tu33.py

from gturtle import *

def drawPiano():
    setPenColor("black")
    for x in range(-200, 160, 50):
        setPos(x, -100)
        for k in range(2):
            fd(216).rt(90).fd(50).rt(90)
    setLineWidth(32)
    for x in [-150, -100, 0, 50, 100, 200]:
        setPos(x, 0)
        fd(100)

def play(x, y):
    if x > -200 and x < 200 and y > -100 and y < 0:
        i = int((x + 200)/50)
        f = tones[i]
        playTone(f, 300)    

tones = [262, 294, 330, 349, 392, 440, 494, 524]

makeTurtle(mouseHit = play)
hideTurtle()
drawPiano()
addStatusBar(20)
setStatusText("Click white piano keys to play!")


    
