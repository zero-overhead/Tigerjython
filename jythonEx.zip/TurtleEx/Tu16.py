# Tu16.py

from gturtle import *

makeTurtle()
hideTurtle()
drawImage("sprites/ch.gif")
setPos(-365, -155)
drawImage("sprites/sunny.png")
setPos(-150, 40)
drawImage("sprites/changable.png")
setPos(125, -205)
drawImage("sprites/sunny.png")
setPos(40, 140)
drawImage("sprites/cloudy.png")
setPos(220, -10)
drawImage("sprites/rain.png")
setPos(20, 60)
drawImage("sprites/strongrain.png")
setPos(-110, 180)
drawImage("sprites/lightcloudy.png")
setPos(-250, -85)
drawImage("sprites/lightcloudy.png")
setPos(80, 170)
drawImage("sprites/strongrain.png")



