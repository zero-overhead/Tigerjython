# Tu1a.py

from gturtle import *

makeTurtle()

forward(30)
right(90)
forward(30)
left(90)
forward(30)
right(90)
forward(30)
left(90)
forward(30)

  
