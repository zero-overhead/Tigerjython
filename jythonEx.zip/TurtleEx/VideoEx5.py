# VideoEx5.py

from gturtle import *

makeTurtle()
Options.setPlaygroundSize(640, 480)
rec = VideoRecorder(getFrame(), "pony.mp4", "640x480")
hideTurtle()
penUp()
wrap()
setPos(200, -30)
left(90)

img = [0] * 8
for i in range(8):
    img[i] = "sprites/pony_" + str(i) + ".gif"    

i = 0
nbFrames = 200
n = 0
while n < nbFrames:
    clear()
    drawBkImage("sprites/catbg.png")
    drawImage(img[i])
    rec.captureImage(2)
    forward(5)
    i += 1
    if i == 7:
        i = 0
    n += 1    

rec.finish()
print("all done")   