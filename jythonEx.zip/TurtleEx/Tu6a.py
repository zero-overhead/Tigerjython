# Tu6a.py

from gturtle import *

makeTurtle()
setPos(-50, -100)
speed(-1)
    
a = 180
while a > 5:
    for i in range(4):
        forward(a)
        right(90)
    left(10)
    a = a * 0.9

