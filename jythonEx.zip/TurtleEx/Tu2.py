# Tu2.py

from gturtle import *

makeTurtle()

repeat 4:
    forward(100)
    right(90)