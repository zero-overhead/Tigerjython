# TcpEx1Server.py

from gturtle import *
from tcpcom import TCPServer
                                                                          
def onMousePressed(x, y):
    server.sendMessage("moveTo(" + str(x) + "," + str(y) + ")")
    moveTo(x, y)
    dot(10)   

def onCloseClicked():
    server.terminate()
    dispose()
    
def onStateChanged(state, msg):
    if state == TCPServer.CONNECTED:
        setStatusText("Partner ready. Click to draw a dot!") 
    
makeTurtle(mousePressed = onMousePressed, closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
port = 5000
server = TCPServer(port, stateChanged = onStateChanged)
setStatusText("Waiting for a partner...")