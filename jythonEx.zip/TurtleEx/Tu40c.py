# Tu40c.py

from gturtle import *

def peano(n, s, w):
   if n == 0:   
      return
   lt(w)
   peano(n - 1, s, -w)
   fd(s)
   rt(w)
   peano(n - 1, s, w)
   fd(s)
   peano(n - 1, s, w)
   rt(w)
   fd(s)
   peano(n - 1, s, -w)
   lt(w)

def fillMe(x, y):
   fill(x, y)   
    
makeTurtle(mouseHit = fillMe)
ht()
setPos(160, -160)
for i in range(4):
   fd(310).lt(90) 
peano(5, 10, 90)
  
