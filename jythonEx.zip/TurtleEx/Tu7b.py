# Tu7b.py

from gturtle import *

def square(size):
    for i in range(4):
        forward(size)
        right(90)

makeTurtle()  
s = 140
while s > 5:
    square(s)
    left(180)
    s = s * 0.9

