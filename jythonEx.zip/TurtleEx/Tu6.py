# Tu6.py

from gturtle import *

makeTurtle()

s = inputInt("Gib die Seitenlänge ein")
  
for i in range(4): 
    forward(s) 
    right(90)
      
