 # SquarePattern.py

from gturtle import *

def square(s):
    for i in range(4):
        forward(s)
        right(90)

def figure(x, y, s):
    if s < 2:
        return
    setPos(x - s/2, y - s/2)
    square(s)
    figure(x + s, y + s, s/2)
    figure(x - s, y + s, s/2) 

makeTurtle()
speed(-1)
figure(0, 0, 64)

