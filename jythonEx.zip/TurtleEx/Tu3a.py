# Tu3a.py

from gturtle import *

makeTurtle()

for i in range(10, 200, 5):
    forward(i)
    left(90)    

