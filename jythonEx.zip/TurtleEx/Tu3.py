# Tu3.py

from gturtle import *

makeTurtle()
  
for i in range(5):
    forward(160)
    right(144)
 


 
