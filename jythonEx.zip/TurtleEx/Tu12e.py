# Tu12e.py

from gturtle import *

def onMousePressed(x, y):
    if isLeftMouseButton():
        setPos(x, y)

    if isRightMouseButton():
        fill(x, y)

def onMouseDragged(x, y): 
    moveTo(x, y)

makeTurtle(mousePressed = onMousePressed,
           mouseDragged = onMouseDragged)
hideTurtle()
addStatusBar(20)
setStatusText("Drag turtle to paint!")
