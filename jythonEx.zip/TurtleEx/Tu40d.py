# Tu40d.py

from gturtle import *

def fillMe(x, y):
   fill(x, y)   
    
makeTurtle(mouseHit = fillMe)
ht()
setPos(-40, -100)
for i in range(9):
   forward(300)
   right(160)
