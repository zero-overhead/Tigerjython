# Tu 12g.py

from gturtle import*

def onPressed(x,y):
    global mx, my 
    if isLeftMouseButton():
        setPenColor("blue")
    if isRightMouseButton():
        setPenColor("green")        
    setPos(x, y) 
    dot(20)               
    mx = x
    my = y    
    
def onKeyPressed(key):
    print(key)
    if key==10:#Enter
        setPos(mx,my)
        setPenColor("red")
        dot(20)
        
makeTurtle(mousePressed=onPressed,keyPressed=onKeyPressed)
hideTurtle()
mx = 0
my = 0 