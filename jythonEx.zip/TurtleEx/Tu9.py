# Tu9.py

from gturtle import *

def square(t):
    for i in range(4):
        t.forward(40)
        t.right(90)
    t.forward(40)    

tf = TurtleFrame()
joe = Turtle(tf)
luka = Turtle(tf)
luka.setColor("red")
luka.setPenColor("green")
joe.setPos(-100, -100)
luka.setPos(50,-100)

for i in range(5):
    square(joe)
    square(luka)
