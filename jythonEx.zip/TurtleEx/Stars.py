# Stars

from gturtle import *
from random import randint

def onMousePressed(x, y): 
    c = colors[randint(0, 4)]
    setFillColor(c)
    setPos(x, y)
    star() 

def star():
    startPath()
    repeat 30:
        forward(150)
        right(174.2) 
    fillPath()    

makeTurtle(mousePressed = onMousePressed)
ht()
setPenColor('red')
colors = ["yellow", "green", "blue", "orange", "black"]
c ="yellow"