# Tu1b.py

from gturtle import *

makeTurtle()

right(30)
forward(80)
dot(20)
right(120)
forward(80)
dot(20)
right(120)
forward(80)
dot(20)
hideTurtle()
