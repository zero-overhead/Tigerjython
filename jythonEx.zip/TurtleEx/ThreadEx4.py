# ThreadEx4.py

from gturtle import *
from thread import start_new_thread

def onMousePressed(e):
    t = Turtle(tf)
    t.setScreenPos(e.getPoint())
    start_new_thread(star, (t, ))

def star(t):
    t.startPath()
    for i in range(9):
        t.fd(70).rt(160)
    t.fillPath()
    
tf = TurtleFrame(mousePressed = onMousePressed)
tf.addStatusBar(20)
tf.setStatusText("Click to create a new star")
