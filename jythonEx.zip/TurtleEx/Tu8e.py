# Tu8e.py

from gturtle import *
import random

makeTurtle()
hideTurtle()
addStatusBar(20) 
dot(10)
openDot(400)
n = 0
r = 0
while r < 200:
    z = random.random()
    angle = z * 360
    heading(angle)
    forward(20)
    r = distance(0, 0)
    setStatusText("Number of steps: " + str(n) + ". Distance: " + str(r))
    n += 1     

