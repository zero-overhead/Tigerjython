# Tu37.py

from gturtle import *

makeTurtle()
stepEntry = FloatEntry("Step", 200)
pane1 = EntryPane(stepEntry)
setColor("red")
red = RadioEntry("Red")
red.setValue(True)
green = RadioEntry("Green")
blue = RadioEntry("Blue")
pane2 = EntryPane("Turtle Color", red, green, blue)
dlg = EntryDialog(650, 200, pane1, pane2)

while not dlg.isDisposed():
    if isDisposed():
        dlg.dispose()
    if dlg.isModified():  
        isRed = red.getValue()
        isGreen = green.getValue()
        isBlue = blue.getValue()
        if isRed:
            setColor("red")
            setPenColor("red")
        if isGreen:
            setColor("green")
            setPenColor("green")
        if isBlue:
            setColor("blue")
            setPenColor("blue")
        step = stepEntry.getValue()
        if step == None:
            continue
        forward(step)
        right(160)
dispose() 