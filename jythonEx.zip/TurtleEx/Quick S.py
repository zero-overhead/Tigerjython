
def quicksort(li):
    if len(li) <= 1:
        return li
    links, rechts = [], []          # leere Listen für links und rechts anlegen
    pivotelement = li.pop()
    print(pivotelement) # das letzte Element aus der Liste nehmen als Referenz
    for element in li:           # die restlichen Elemente der Liste durchlaufen ...
        if element < pivotelement:  # ... und mit dem pivotelement vergleichen
            links .append(element)  # wenn kleiner: dann an linke Liste anhängen
            print(links)
        else:
            rechts.append(element)  # ansonsten wenn nicht kleiner: dann an rechte Liste anhängen
            print(rechts)
    return quicksort(links) + [pivotelement] + quicksort(rechts)    
    
li = [4, 7, 5, 1 ,3, 2]
print(li)
quicksort(li)
print(li)
