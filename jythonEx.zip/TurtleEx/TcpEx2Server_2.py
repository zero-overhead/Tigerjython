# TcpEx2Server.py

from gturtle import *
from tcpcom import TCPServer                                                                       
   
def onCloseClicked():
    server.terminate()
    dispose()

def onStateChanged(state, msg):
    if state == TCPServer.CONNECTED:
        setStatusText("Client connected")  
    if state == TCPServer.MESSAGE:
        li = msg.split(",")
        if li[0] == "p":
            setPos(float(li[1]), float(li[2]))
        if li[0] == "m":
            moveTo(float(li[1]), float(li[2]))

makeTurtle(closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
setPenColor("red")
port = 5000
server = TCPServer(port, stateChanged = onStateChanged)
setStatusText("Waiting for a client...")



