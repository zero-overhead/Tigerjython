# Tu15a.py

from gturtle import *

def propeller():
    repeat 3:
        fillToPoint()    
        rightArc(60, 90)
        right(90)
        rightArc(60, 90)
        left(30)       
    
makeTurtle()
hideTurtle()
enableRepaint(False)

while True:         
    propeller() 
    repaint()  
    delay(40)
    clear()     
    right(10)  