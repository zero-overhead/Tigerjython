# Tu38a.py

from gturtle import *

makeTurtle()
hideTurtle()
sliderRed = SliderEntry(0, 255, 255, 20, 50)  
sliderGreen = SliderEntry(0, 255, 1, 20, 50)  
sliderBlue = SliderEntry(0, 255, 240, 20, 50)  
pane1 = EntryPane("Fill Color", sliderRed, sliderGreen, sliderBlue)
sliderSize = SliderEntry(20, 200, 100, 20, 5)
pane2 = EntryPane("Size", sliderSize)
toneEntry = SliderEntry(200, 1000, 262, 100, 50)  
pane3 = EntryPane("Sound frequency", toneEntry)
dlg = EntryDialog(650, 200, pane1, pane2, pane3)
while not dlg.isDisposed():
    if isDisposed():
        dlg.dispose()
    if dlg.isModified():          
        r = sliderRed.getValue()
        g = sliderGreen.getValue()
        b = sliderBlue.getValue()
        setFillColor(makeColor(r, g, b))
        setPenColor(makeColor(r, g, b))
        clean()
        size = sliderSize.getValue()
        setPos(-size/2, size/2)
        startPath()
        for i in range(6):
            forward(size)
            right(140)
            forward(size)
            left(80)
        fillPath()
        f = toneEntry.getValue()        
        playTone(f, 500, block = False)      
dispose()        