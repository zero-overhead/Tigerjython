# Tu15c.py

from gturtle import *

def bird(angle):
    dot(20)
    right(angle)
    rightArc(100, 90)
    home()
    left(angle)
    leftArc(100, 90)
    home()
    
def move(start, end, step):
    for a in range(start, end, step):
        clear("lightSkyBlue")   
        bird(a)
        repaint()
        delay(40) 
    
makeTurtle()
hideTurtle()
setPenWidth(5)
setPenColor("black")
enableRepaint( False)

while True:
    move(55, 5, -2)
    move(5, 55, 2)    

