#Tu11d.py
from gturtle import *

def go(t):
    if k == 37:
        t.setHeading(-90)
    elif k == 39:
        t.setHeading(90)
    elif k == 38:
        t.setHeading(0)
    elif k == 40:
        t.setHeading(180)
    t.fd(20) 

t1 = makeTurtle()
t1.setPos(-50, 0)
t2 = Turtle(t1)
t2.setColor("red")
t2. setPos(50, 0)
t = t1

while True:
    k = getKeyCodeWait()
    print(k)
    go(t)
    if t == t1:
        t = t2
    else:
        t = t1    
       
        

