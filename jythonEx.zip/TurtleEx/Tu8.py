 # Tu8.py

from gturtle import *
import random

def star(x, y):
    setPos(x, y)
    fillToPoint(x, y)
    for i in range(6):
        forward(10)
        right(140)
        forward(10)
        left(80)

makeTurtle()        
hideTurtle()
clear("blue")
setPenColor("yellow")
for i in range(50):
    x = random.randint (-270, 270)
    y = random.randint (-270, 270)
    star(x, y)

