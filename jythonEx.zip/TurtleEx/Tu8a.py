# Tu8a.py

from gturtle import *
from random import randint

makeTurtle()
hideTurtle()

for i in range(100):
    x = randint(-300, 300)
    y = randint(-300, 300)
    setPos(x, y)
    r = randint(0, 255)
    g = randint(0, 255)
    b = randint(0, 255)
    c = Color(r, g, b)
    setPenColor(c)
    d = randint(50, 300)
    dot(d)

