# Tu12.py

from gturtle import *

def onMousePressed(x, y):
   fill(x, y)   
    
makeTurtle(mousePressed = onMousePressed)
hideTurtle()  
for k in range(12):
   for i in range(6):
      forward(80)
      right(60)
   left(30)
addStatusBar(20)
setStatusText('Click to fill some parts!')      

