# TcpEx3Server.py

from gturtle import *
from tcpcom import TCPServer
                                                                          
def onMousePressed(x, y):
    global isMyTurn
    if not isMyTurn:
        return   
    setPos(x, y)
    setFillColor("green")
    fill(x, y)      
    server.sendMessage("fill(" + str(x) + "," + str(y) + ")")
    isMyTurn = False 
    setStatusText("Wait!") 

def onCloseClicked():
    server.terminate()
    dispose()
    
def onStateChanged(state, msg):
    global isMyTurn
    if state == TCPServer.CONNECTED:
        setStatusText("Partner entered my game room")        
    if state == TCPServer.MESSAGE:        
        setFillColor("red")
        exec(msg)      
        setStatusText("Click to fill any part!")         
        isMyTurn = True
    
makeTurtle(mousePressed = onMousePressed, closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
for k in range(12):
   for i in range(6):
      forward(50)
      right(60)
   left(30) 
port = 5000
server = TCPServer(port, stateChanged = onStateChanged)
setStatusText("Waiting for a partner...")
isMyTurn = False