# Tu38.py

from gturtle import *

makeTurtle()
hideTurtle()
sliderRed = SliderEntry(0, 255, 255, 20, 10)  
sliderGreen = SliderEntry(0, 255, 1, 20, 10)  
sliderBlue = SliderEntry(0, 255, 240, 20, 10)  
pane1 = EntryPane("Star Color", sliderRed, sliderGreen, sliderBlue)
sliderSize = SliderEntry(20, 200, 100, 20, 5)
pane2 = EntryPane("Star Size", sliderSize)
dlg = EntryDialog(650, 200, pane1, pane2)
while not dlg.isDisposed():
    if isDisposed():
        dlg.dispose()
    if dlg.isModified():          
        r = sliderRed.getValue()
        g = sliderGreen.getValue()
        b = sliderBlue.getValue()
        setFillColor(makeColor(r, g, b))
        setPenColor(makeColor(r, g, b))
        clean()
        size = sliderSize.getValue()
        setPos(-size/2, size/2)
        startPath()
        for i in range(6):
            forward(size)
            right(140)
            forward(size)
            left(80)
        fillPath()  
dispose()        