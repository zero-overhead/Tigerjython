 # Tu4b.py

from gturtle import *

makeTurtle()

setFillColor("magenta")
for i in range(4):
    startPath()
    forward(100)
    right(90)
    forward(100)
    fillPath()
