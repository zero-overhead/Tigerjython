from gturtle import *

def move(t): 
    t.forward(30)
   
def onKeyPressed(key):
    code = key.getKeyCode()
    tf.setStatusText("Code: " + str(code))
    if code == 88: # x
       move(t1)
    if code == 89: # y
       move(t2)

tf = TurtleFrame()
t1 = Turtle(tf, keyPressed = onKeyPressed)
t2 = Turtle(tf)
t1.setPos(100,-300)
t2.setPos(-100,-300)
tf.addStatusBar(20)