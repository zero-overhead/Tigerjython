# Tu12f.py

from gturtle import *

def onMouseHit(x, y):
    t = Turtle(tf)
    t.setPos(x, y)
    t.fillToPoint(x, y) 
    star(t)

def star(t):
    for i in range(6): 
        t.fd(20).rt(140).fd(20).lt(80)

tf = TurtleFrame(mouseHit = onMouseHit)
tf.addStatusBar(20)
tf.setStatusText("Click to create a new star")

