# Tu5b.py

from gturtle import *

makeTurtle()

hideTurtle()
clear("black")
for x in range(-250, 250, 70):
    setPos(x, x)
    color = askColor("Farbauswahl", "yellow")
    if color == None:
        break
    setPenColor(color)
    dot(70)
