# Tu4e.py

from gturtle import *

makeTurtle()
wrap();
speed(-1)
setPenColor("green")
fillToPoint(0, 175)
setPos(150, 180)
repeat 90:
   forward(10)
   left(4)

