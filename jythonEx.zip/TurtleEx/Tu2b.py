# Tu2b.py

from gturtle import *

makeTurtle()

i = 0
while i < 4:
    forward(100)
    right(90)
    i = i + 1     