# TcpEx3Client.py

from gturtle import *
from tcpcom import TCPClient

def onMousePressed(x, y):
    global isMyTurn
    if not isMyTurn:
        return 
    setPos(x, y)
    setFillColor("red")
    fill(x, y)     
    client.sendMessage("fill(" + str(x) + "," + str(y) + ")")
    isMyTurn = False
    setStatusText("Wait!")  

def onCloseClicked():
    client.disconnect()
    dispose()
    
def onStateChanged(state, msg):
    global isMyTurn 
    if state == TCPClient.MESSAGE:               
        setFillColor("green")
        exec(msg)      
        setStatusText("Click to fill any part!")         
        isMyTurn = True
    elif state == TCPClient.DISCONNECTED:
        setStatusText("Server died")
        isMyTurn = False

makeTurtle(mousePressed = onMousePressed, closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
for k in range(12):
   for i in range(6):
      forward(50)
      right(60)
   left(30)
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
setStatusText("Client connecting...")
if client.connect():
    setStatusText("Click to fill any part!")
    isMyTurn = True     