# ThreadEx3.py

from gturtle import *
from thread import start_new_thread

def go(t):
    start_new_thread(draw, (t, ))

def draw(t):
    for i in range(9):
        segment(t);
    
def segment(t):    
    t.forward(140)
    t.right(160)

tf = TurtleFrame()
john = Turtle(tf)
laura = Turtle(tf, "red")
sara = Turtle(tf, "green")
john.setPos(-100, -100)
laura.setPos(-20, -100)
sara.setPos(60, -100)
laura.setPenColor("red")
sara.setPenColor("green")
go(john)
go(laura)
go(sara)

