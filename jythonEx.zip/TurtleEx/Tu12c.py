#Tu12c.py

from gturtle import *

def onMousePressed(x, y):
    if isLeftMouseButton():
        setFillColor("red")
    if isRightMouseButton():    
        setFillColor("blue")
    fill(x, y)   

makeTurtle(mousePressed = onMousePressed)
hideTurtle()
setPenColor("black")
for x in range(-180, 190, 40): 
    setPos(x, -180)
    forward(360) 
right(90)
for y in range(-180, 190, 40): 
    setPos(-180, y)
    forward(360)
addStatusBar(20)
setStatusText('Click left or right Mousebutton to fill some fields!')
