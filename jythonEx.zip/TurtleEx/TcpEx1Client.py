# TcpEx1Client.py

from gturtle import *
from tcpcom import TCPClient

def onCloseClicked():
    client.disconnect()
    dispose()
    
def onStateChanged(state, msg):
    if state == TCPClient.MESSAGE:              
        exec(msg)
        dot(10)               
    elif state == TCPClient.DISCONNECTED:
        setStatusText("Server died")
 
makeTurtle(closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
setStatusText("Client connecting...")
if client.connect():
    setStatusText("Connected")

