# Tu2d.py

from gturtle import *

makeTurtle()
speed(-1)

while True:
    forward(4)
    left(3)