# Tu6b.py

from gturtle import *

makeTurtle()

hideTurtle()
a = 5
while a < 250:
    forward(a)
    right(70)
    a = a + 1

