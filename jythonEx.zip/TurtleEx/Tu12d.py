# Tu12d.py

from gturtle import *

def onMousePressed(x, y):
    setPos(x, y)

def onMouseDragged(x, y):
    moveTo(x, y)

makeTurtle(mousePressed = onMousePressed,
           mouseDragged = onMouseDragged)
speed(-1)
setPenColor("red")
addStatusBar(20)
setStatusText("Drag turtle to paint!")
