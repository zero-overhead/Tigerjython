# BubbleSort.py

from gturtlex import *
from random import randint

d = 10
n = 61

def createRandomDots():
    setPos(-300, 0)
    repeat n:
        c = makeColor("rainbow", randint(10, 90) / 100)
        setPenColor(c)
        dot(d - 1)
        forward(d)

def swapColors():
    setFillColor(getColor())
    setColor(getPixelColor())
    fill()
       
def bubbleSortStep():
    setPos(-300, 0)
    repeat n - 1:
        setColor(getPixelColor())
        forward(d)
        if getPixelColorHue() < getTurtleColorHue():
            swapColors()
            back(d)
            swapColors()
            forward(d)
   
def bubbleSort():
    repeat n - 1:
        bubbleSortStep()

makeTurtle()
right(90)
clear("black")
penUp()
createRandomDots()
bubbleSort()