# Tu33.py

from gturtle import *

def drawPiano():
    setPenColor("black")
    for x in range(-200, 160, 50):
        setPos(x, -100)
        for k in range(2):
            fd(216).rt(90).fd(50).rt(90)
    setLineWidth(32)
    for x in [-150, -100, 0, 50, 100, 200]:
        setPos(x, 0)
        fd(100)

def onMouseHit(x, y):
    if x > -200 and x < 215 and y > -100 and y < 100:
        i = int((x + 200)/50)
        setPos(x, y)
        if getPixelColorStr() == "black":
            k = int((x + 215) / 50)
            f = blacktones[k]
        else:
            f = whitetones[i]
        playTone(f, 200)

whitetones = [262, 294, 330, 349, 392, 440, 494, 524]
blacktones = [0, 277, 311, 0, 360, 415, 466, 0, 555]

makeTurtle(mouseHit = onMouseHit)
hideTurtle()
drawPiano()
addStatusBar(20)
setStatusText("Click a piano key to play!")
