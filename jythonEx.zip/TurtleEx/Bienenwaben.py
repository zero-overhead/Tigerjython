# Bienenwaben.py

from gturtle import *

angle = 60
length = 20

def line(s):
    forward(s)
    back(s)
    
def ypsilon(depth):
    if depth == 0:
        line(length)
    else:
        forward(length)
        left(angle)
        ypsilon(depth-1)
        right(2*angle)
        ypsilon(depth-1)
        left(angle)
        back(length)
        
makeTurtle()
hideTurtle()
ypsilon(7)