# Georgia.py

from gturtle import *

makeTurtle()

clear ('black')

for a_color, a_pensize, start_radius, stop_radius, radius_step in (
    ('green', 1, 82, 40, -6),        
    ('red', 1, 84, 40, -6),    
    ('blue', 2, 98, 50, -5),
    ('yellow', 2, 70, 50, -5),
    ('red', 3, 97, 70, -5),
    ('orange', 2, 87, 40, -17),
    ('red', 3, 102, 60, -17),    
):
    penWidth (a_pensize)
    setPenColor (a_color)
    for angle_index in range (10):
        for radius in range (start_radius, stop_radius, radius_step):
            rightCircle (radius)
        right (36)

