# Tu2e.py

from gturtle import *

makeTurtle()
speed(-1)

repeat:
    forward(4)
    left(3) 