# Tu22.py

from ch.aplu.turtle import Turtle

class MyTurtle(Turtle):
   def setColor(self, color):
      super(MyTurtle, self).setColor(color)
  #    self.setPenColor(color);
      return self

t = MyTurtle()
t.setColor("red")
t.forward(100)
