# ThreadEx1.py

from gturtle import *
from thread import start_new_thread

def go(t):
    start_new_thread(draw, (t, ))

def draw(t):
    for i in range(8):
        step(t)
    
def step(t):    
    t.forward(20)
    t.left(90)
    t.forward(20)
    t.right(90)

tf = TurtleFrame()
john = Turtle(tf)
laura = Turtle(tf)
laura.setColor("red")
laura.setPenColor("red")
laura.setPos(0, 160)
laura.left(90)
go(john)
go(laura)

