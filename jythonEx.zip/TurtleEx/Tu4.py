# Tu4.py

from gturtle import *

makeTurtle("red")
setPos(-50, 50)
setPenColor("red")
setPenWidth(8)
repeat 4:
    repeat 3:
        forward(100)
        right(90)
    left(180)
setFillColor("red")
#fill(-60, 60)
fill(0, 0)
hideTurtle()

 
