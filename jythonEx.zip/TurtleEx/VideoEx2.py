# VideoEx2.py

from gturtle import *
import random

Options.setPlaygroundSize(640, 480)
makeTurtle()
rec = VideoRecorder(getFrame(), "randomwalk.mp4", "640x480")
hideTurtle()
dot(10)
openDot(400)
n = 0
r = 0
while r < 200:
    z = random.random()
    angle = z * 360
    heading(angle)
    forward(20)
    r = distance(0, 0)
    print("Steps: " + str(n))
    n += 1
    rec.captureImage(3) 
rec.finish()
print("all done")         