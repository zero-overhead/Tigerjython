# Tu15f.py

from gturtle import *

tf = TurtleFrame()
t1 = Turtle(tf)
t2 = Turtle(tf)
t1.ht()
t2.ht()
t1.setPos(120, 0)
t2.setPos(250, 0)
t1.left(90)
t2.left(90)
tf.enableRepaint(False)

imgT1 = [0] * 8
imgT2 = [0] * 8
for i in range(8):
    imgT1[i] = "sprites/pony_" + str(i) + ".gif"   
for i in range(8):     
    imgT2[i] = "sprites/pony2_" + str(i) + ".gif"  

repeat:
    for i in range(8):
        t1.drawImage(imgT1[i])
        t2.drawImage(imgT2[i])
        tf.repaint()
        tf.delay(100)
        tf.clear()
        t1.forward(5)
        t2.forward(5)
