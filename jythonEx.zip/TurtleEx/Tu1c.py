# Tu1c.py

from gturtle import *

makeTurtle()
rightArc(100, 360)
leftArc(100, 360)
rightArc(50, 360)
leftArc(50, 360)
rightArc(200, 70)
home()
leftArc(200, 70)
home()



