from gturtle import *
import time

def wall():
    setPenColor("green")
    setLineWidth(10)
    setPos(-200, -50)
    forward(100)
    setPos(200, -50)
    forward(100)    

makeTurtle()
hideTurtle()
enableRepaint(False)

x = -170
v = 10

while True:
    startTime = time.clock()
    clear()
    wall()
    setPos(x, 0)
    setPenColor("red")
    dot(60)
    repaint()
    x = x + v
    while (time.clock() - startTime)  < 0.020:
        delay(1)
    if x > 165 or x < -165:
        v = -v    
