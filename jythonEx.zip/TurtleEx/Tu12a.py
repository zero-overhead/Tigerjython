# Tu12a.py

from gturtle import *

def onMousePressed(x, y):
    setPos(x, y)
    for i in range(6):
        fd(20).bk(20).rt(60)

makeTurtle(mousePressed = onMousePressed)
hideTurtle()
addStatusBar(20)
setStatusText("click to paint!")
