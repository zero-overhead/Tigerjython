from gturtle import *

makeTurtle()
hideTurtle()
g = 255
d = 510
while d > 0:
    c = makeColor(0, g, 0)
    setPenColor(c)
    dot(d)
    g = g - 1
    d = d - 2