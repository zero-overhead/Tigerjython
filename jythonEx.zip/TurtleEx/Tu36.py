# Tu36.py

from gturtle import *

makeTurtle()
hideTurtle()
stepEntry = IntEntry("Step:", 200)
angleEntry = FloatEntry("Angle:", 144)
repEntry = IntEntry("Repeat:", 5)
pane1 = EntryPane("Select values and press OK", stepEntry, angleEntry, repEntry)
okBtn = ButtonEntry("OK") 
pane2 = EntryPane(okBtn)
statusEntry = StringEntry("", "")
pane3 = EntryPane("Status", statusEntry)
dlg = EntryDialog(700, 10, pane1, pane2, pane3)
dlg.setAlwaysOnTop(True)
 
while not dlg.isDisposed():
    if okBtn.isTouched():
        step = stepEntry.getValue()
        angle = angleEntry.getValue()
        n = repEntry.getValue()
        if step == None or angle == None or n == None:
            statusEntry.setValue("Illegal input")
            continue        
        clean()    
        for i in range(n):
            forward(step)
            right(angle)
        statusEntry.setValue("") 
dispose()

