# Tu12b.py

from gturtle import *

def onMouseHit(x, y):
    setPos(x, y)
    for i in range(5):
        fd(50).rt(144)

makeTurtle(mouseHitX = onMouseHit)
#makeTurtle(mousePressed = onMousePressed)
speed(-1)
addStatusBar(20)
setStatusText("click to paint!")
