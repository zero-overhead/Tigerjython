# TcpEx2Server.py

from gturtle import *
from tcpcom import TCPServer
                                                                          
def onMousePressed(x, y):
    setPos(x, y)
    server.sendMessage("p," + str(x) + "," + str(y))

def onMouseDragged(x, y):
    moveTo(x, y)         
    server.sendMessage("m," + str(x) + "," + str(y))

def onCloseClicked():
    server.terminate()
    dispose()
    
def onStateChanged(state, msg):
    if state == TCPServer.CONNECTED:
        setStatusText("Partner ready, Dragg the mouse!")        
  
makeTurtle(mousePressed = onMousePressed, mouseDragged = onMouseDragged, 
           closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
port = 5000
server = TCPServer(port, stateChanged = onStateChanged, )
setStatusText("Waiting for a client...")

