# ShipClient.py

from gturtle import *
import random
from tcpcom import TCPClient

def drawBoard():
    clear("aliceblue")
    setPenColor("gray")    
    for x in range(-250, 250, 50):   
        setPos(x, 0)
        setFillColor("blue")
        startPath()
        repeat 4:
            forward(50)
            right(90)
        fillPath()    

def createShips():    
    li = random.sample(range(1, 10), 4) # 4 unique random numbers 1..10
    for i in li:       
        setPos(-275 + i * 50, 25) 
        drawImage("sprites/boat.gif")   

def onMousePressed(x, y):
    global isMyTurn
    setPos(x, y) 
    if getPixelColorStr() == "aliceblue" or isOver or not isMyTurn:
        return
    nb = int((x + 250) / 50) + 1 # cell number
    client.sendMessage(str(nb))
    isMyTurn = False  

def onCloseClicked():
    client.disconnect()
    dispose()
    
def onStateChanged(state, msg):
    global isMyTurn, myHits, partnerHits  
    if state == TCPClient.MESSAGE:
        if msg == "hit":
            myHits += 1
            setStatusText("Hit! Partner's remaining fleet size " + str(4 - myHits))
            if myHits == 4:
                setStatusText("Game over, You won!")
                isOver = True            
        elif msg == "miss":
            setStatusText("Miss! Partner's remaining fleet size " + str(4 - myHits))
        else:        
            nb = int(msg) # cell number          
            x = -275 + nb * 50            
            setPos(x , 25)  
            if getPixelColorStr() != "blue":
                client.sendMessage("hit")                
                setPenColor("blue")
                dot(45) # erase ship
                partnerHits += 1                      
                if partnerHits == 4:
                    setStatusText("Game over! Partner won")
                    isOver = True 
                    return                            
            else:
                client.sendMessage("miss")
            setStatusText("Make your move!")          
            isMyTurn = True
    elif state == TCPClient.DISCONNECTED:
        setStatusText("Server died")
        drawBoard()
        isMyTurn = False

makeTurtle(mousePressed = onMousePressed, closeClicked = onCloseClicked)
addStatusBar(30)
hideTurtle()
drawBoard()
host = "localhost"
port = 5000
client = TCPClient(host, port, stateChanged = onStateChanged)
setStatusText("Client connecting...")
isOver = False
myHits = 0
partnerHits = 0
if client.connect():
    setStatusText("Make a move!")
    createShips()
    isMyTurn = True
else:
    setStatusText("Server game room closed")

