# Tu39.py

from entrydialog import *

r = 1.05946309
freq = SliderEntry(200, 1000, 444, 100, 50) 
pane1 = EntryPane("f(root) = 444 Hz", freq)
status = StringEntry("", "Waiting for user action")
pane2 = EntryPane("Status", status)

dlg = EntryDialog(pane1, pane2)
dlg.setTitle("Select Root Note")

while not dlg.isDisposed():
    if dlg.isChanged():
        f = freq.getValue() 
        status.setValue("f(root) = %6.1f  Hz" % f)  
        for i in range(13):
            fnext = f * r**i
            status.setValue("Playing with f = %6.1f  Hz" % fnext)  
            playTone(f * r**i, 500, block = True)       
        status.setValue("Waiting for user action")
