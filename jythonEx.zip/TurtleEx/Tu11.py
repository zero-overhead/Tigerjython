# Tu11.py

from gturtle import *

def onKeyPressed(key):
    step()
    setStatusText("Code: " + str(key))

def step():
    forward(20)
    dot(10)
    right(90)
    forward(20)
    left(90)
  
makeTurtle(keyPressed = onKeyPressed)
hideTurtle()
setPos(-250, -250)
addStatusBar(20)
setStatusText("Press any key!")

