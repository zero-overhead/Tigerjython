# Tu4a.py

from gturtle import *

makeTurtle()
speed(-1)
setPenColor("yellow")
setPos(-150, 100)
fillToPoint(-100, 75)
repeat 6:
    fd(60).rt(140).fd(60).lt(80)  
setPenColor("green")
rt(30)
setPos(-180, -150)
fillToHorizontal(-100)     
repeat 3:
    fd(120).rt(120).fd(120).lt(120)
setPenColor("red")
fillToVertical(100)
home() 
rt(45)
fd(250)
