# Tu2a.py

from gturtle import *

makeTurtle()

repeat 6:
    forward(80)
    dot(20)
    back(80)
    left(60)