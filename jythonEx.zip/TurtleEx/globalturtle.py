# globalturtle.py

import __builtin__

from ch.aplu.turtle import Turtle

g = None

def createTurtle():
   global g
   if g == None or g.isReleased():
      g = Turtle()
   return g

def forward(distance):
   g.forward(distance)

def _getX():
   return g._getX()
	
def _getY():
   return g._getY()
   
def back(distance):
   g.back(distance)

def beep():
   g.beep()

def bk(distance):
   g.bk(distance)

def bong():
   g.bong()

def clean(colorStr):
   g.clean(colorStr)

def clear(colorStr):
   g.clear(colorStr)

def clip():
   g.clip()

def distance(x, y):
   g.distance(x, y)

def dot(radius):
   g.dot(radius)

def enableRepaint(b):
   g.enableRepaint(b)

def fd(distance):
   g.fd(distance)

def fill(x, y):
   g.fill(x, y)

def fillOff():
   g.fillOff()

def fillToHorizontal(y):
   g.fillToHorizontal(y)

def fillToPoint(x, y):
   g.fillToPoint(x, y)

def fillToVertical(x):
   g.fillToVertical(x)

def getColor():
   return g.getColor()

def getFillColor():
   return g.getFillColor()

def getPenColor():
   return g.getPenColor()

def getPixelColor():
   return g.getPixelColor()

def getPos():
   return g.getPos()

def getSpeed():
   return g.getSpeed()

def getX():
   return g.getX()

def getY():
   return g.getY()

def heading(degrees):
   g.heading(degrees)

def hideTurtle():
   g.hideTurtle()

def home():
   g.home()

def ht():
   g.ht()

def isClip():
   return g.isClip()

def isHidden():
   return g.isHidden()

def isPenUp():
   return g.isPenUp()

def isWrap():
   return g.isWrap()

def label(text):
   g.label(text)

def left(degrees):
   g.left(degrees)

def leftCircle(radius):
   g.leftCircle(radius)

def lt(degrees):
   g.lt(degrees)

def openDot(radius):
   g.openDt(radius)

def pd():
   g.pd()

def pe():
   g.pe()

def penDown():
   g.penDown()

def penErase():
   g.penErase()

def penUp():
   g.penUp()

def penWidth(width):
   g.penWidth(width)

def pu():
   g.pu()

def repaint():
   g.repaint()

def right(degrees):
   g.right(degrees)

def rightCircle(radius):
   g.rightCircle(radius)

def rt(degrees):
   g.rt(degrees)

def setColor(colorStr):
   g.setColor(colorStr)

def setFillColor(colorStr):
   g.setFillColor(colorStr)

def setFontSize(size):
   g.FontSize(size)

def setH(degrees):
   g.setH(degrees)

def setHeading(degrees):
   g.setHeading(degrees)

def setLPenWidth(lineWidth):
   g.setLPenWidth(lineWidth)

def setPenColor(color):
   g.setPenColor(color)

def setPos(x, y):
   g.setPos(x, y)

def setScreenX(x):
   g.setScreenX(x)

def setScreenY(y):
   g.setScreenY(y)

def setStatusText(text):
   g.setStatusText(text)

def setTitle(text):
   g.setTitle(title)

def setX(x):
   g.setX(x)

def setY(y):
   g.setY(y)

def showStatusBar(show):
   g.showStatusBar(show)

def showTurtle():
   g.showTurtle()

def sleep(time):
   g.sleep()

def speed(speed):
   g.speed(speed)

def st():
   g.st()

def stampTurtle():
   g.stampTurtle()

def toBottom():
   g.toBottom()

def toTop():
   g.toTop()

def toTurtlePos(x, y):
   g.toTurtlePos(x, y)

def toTurtleX(x):
   g.toTurtleX(x)

def toTurtleY(y):
   g.toTurtleY(y)

def towards(x, y):
   g.towards(x, y)

def wrap():
   g.wrap()
 

__builtin__.createTurtle=createTurtle
__builtin__._getX=_getX
__builtin__._getY=_getY
__builtin__.back=back
__builtin__.beep=beep
__builtin__.bk=bk
__builtin__.bong=bong
__builtin__.clean=clean
__builtin__.clear=clear
__builtin__.clip=clip
__builtin__.distance=distance
__builtin__.dot=dot
__builtin__.enableRepaint=enableRepaint
__builtin__.fd=fd
__builtin__.fill=fill
__builtin__.fillOff=fillOff
__builtin__.fillToHorizontal=fillToHorizontal
__builtin__.fillToPoint=fillToPoint
__builtin__.fillToVertical=fillToVertical
__builtin__.forward=forward
__builtin__.getColor=getColor
__builtin__.getFillColor=getFillColor
__builtin__.getPenColor=getPenColor
__builtin__.getPixelColor=getPixelColor
__builtin__.getPos=getPos
__builtin__.getSpeed=getSpeed
__builtin__.getX=getX
__builtin__.getY=getY
__builtin__.heading=heading
__builtin__.hideTurtle=hideTurtle
__builtin__.home=home
__builtin__.ht=ht
__builtin__.isClip=isClip
__builtin__.isHidden=isHidden
__builtin__.isPenUp=isPenUp
__builtin__.isWrap=isWrap
__builtin__.label=label
__builtin__.left=left
__builtin__.leftCircle=leftCircle
__builtin__.lt=lt
__builtin__.openDot=openDot
__builtin__.pd=pd
__builtin__.pe=pe
__builtin__.penDown=penDown
__builtin__.penErase=penErase
__builtin__.penUp=penUp
__builtin__.penWidth=penWidth
__builtin__.pu=pu
__builtin__.repaint=repaint
__builtin__.right=right
__builtin__.rightCircle=rightCircle
__builtin__.rt=rt
__builtin__.setColor=setColor
__builtin__.setFillColor=setFillColor
__builtin__.setFontSize=setFontSize
__builtin__.setH=setH
__builtin__.setHeading=setHeading
__builtin__.setLPenWidth=setLPenWidth
__builtin__.setPenColor=setPenColor
__builtin__.setPos=setPos
__builtin__.setScreenX=setScreenX
__builtin__.setScreenY=setScreenY
__builtin__.setStatusText=setStatusText
__builtin__.setTitle=setTitle
__builtin__.setX=setX
__builtin__.setY=setY
__builtin__.showStatusBar=showStatusBar
__builtin__.showTurtle=showTurtle
__builtin__.sleep=sleep
__builtin__.speed=speed
__builtin__.st=st
__builtin__.stampTurtle=stampTurtle
__builtin__.toBottom=toBottom
__builtin__.toTop=toTop
__builtin__.toTurtleX=toTurtleX
__builtin__.toTurtleY=toTurtleY
__builtin__.towards=towards
__builtin__.wrap=wrap

