# Tu3a.py

from gturtle import *

makeTurtle()
  
for k in range(10):
    for i in range(4):
        forward(80)
        right(90)
    left(36)    

