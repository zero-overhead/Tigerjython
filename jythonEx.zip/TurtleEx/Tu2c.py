#Tu2c.py

from gturtle import *

makeTurtle()
y = 0
while y < 300:
    forward(20)
    right(90)
    forward(20)
    left(90)
    y = y + 20
hideTurtle()    

	