# Tu40a.py

from gturtle import *

def fillMe(x, y):
   fill(x, y)   
    
makeTurtle(mouseHit = fillMe)
ht()
  
for k in range(12):
   for i in range(6):
      forward(80)
      right(60)
   left(30)   
