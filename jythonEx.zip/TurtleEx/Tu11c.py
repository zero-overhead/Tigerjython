# Tu11c.py
from gturtle import *

def move(t): 
    t.forward(30)
   
def onKeyPressed(key):
    code = tf.getKeyCode()
    print(code)
    if code == 88: # x
       move(t1)
    elif code == 89: # y
       move(t2)

tf = TurtleFrame(keyPressed = onKeyPressed)
t1 = Turtle(tf)
t2 = Turtle(tf)
t1.setPos(100,-290)
t2.setPos(-100,-290)
t2.setColor("red")
tf.addStatusBar(20)
tf.setStatusText("Press x or y")