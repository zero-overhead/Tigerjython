from gturtle import *

def figure():
    fillToPoint(0, 0)
    repeat 2:
        forward(150)
        right(60)
        forward(150)
        right(120)
    
makeTurtle()
hideTurtle()
enableRepaint(False)

while True:
    clean()    
    figure()
    repaint()
    delay(2)
    right(3)
    


