# Tu34.py

from gturtle import *
import random

def drawPiano():
    setPenColor("black")
    for x in range(-200, 160, 50):
        setPos(x, -100)
        for k in range(2):
            fd(216).rt(90).fd(50).rt(90)
    setLineWidth(32)
    for x in [-150, -100, 0, 50, 100, 200]:
        setPos(x, 0)
        fd(100)

white = [262, 294, 330, 349, 392, 440, 494, 524]
black = [277, 311, 370, 415, 466]

makeTurtle()
hideTurtle()
drawPiano()
showTurtle()

for n in range(30):
    i = random.randint(0, 13)
    if i < 8:
        x = i * 50 - 175
        setPos(x, -50)
        f = white[i]
    else:
        blackPos = [-150, -100, 0, 50, 100]
        k = i - 9 
        x = blackPos[k]
        setPos(x, 30)    
        f = black[k]
    playTone(f, 300)    
  
