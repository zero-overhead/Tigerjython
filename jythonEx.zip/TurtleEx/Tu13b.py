#Tu13b.py

from gturtle import *

makeTurtle()

house = [60, 71, 0, 71, 60, 0, 100]

for s in house:
    forward(2 * s)
    right(45)

