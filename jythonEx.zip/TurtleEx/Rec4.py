# Rec4.py

from gturtle import *

def nest(size, level):
   if level == 0:
       return
   forward(size/2)
   subnest(size, level)
   forward(size/2)
   repeat 2:
      right(120)
      forward(size)
   right(120)

def subnest(size, level):
   right(60)
   nest(size/2, level - 1)
   left(60)  

makeTurtle()
setPos(-100, -200)
ht()
nest(400, 10)       
