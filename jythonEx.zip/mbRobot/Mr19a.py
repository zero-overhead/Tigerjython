from mbrobot_plus import *
#from mbrobot import *

setServo("S1", 160)
setSpeed(20)
forward()
repeat:
    d = getDistance()
    print(d)
    if d < 12: 
        stop()
        delay(1000)
        setServo("S1", 100)
        setSpeed(20)        
        backward()       
        delay(4000)               
        stop()
        setServo("S1", 160)
    delay(100)            
      

    

