# Mr2c.py
from mbrobot import * 
       
setSpeed(40)  
leftArc(0.1)
delay(2000)
rightArc(0.1)
delay(2000)
stop() 
