# Mr2g.py
from music import *

song = ENTERTAINER
play(song)
