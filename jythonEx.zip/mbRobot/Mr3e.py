# Mr3e.py
from mbrobot import *

mesh = [[50, 0], [25, 43], [-25, 43], [-50, 0],[-25, -43], [25, -43]] 
RobotContext.useTarget("sprites/redtarget.gif", mesh, 400, 400)

def searchTarget():
   global lt, rt
   found = False
   step = 0
   repeat:  
      right()
      sleep(50)
      step = step + 1
      dist = getDistance()
      if dist != -1:
         if not found:
            found = True
            lt = step
      else:
         if found:   
            rt = step
            break

setBeamAreaColor(Color.green)  
setProximityCircleColor(Color.lightGray)
setSpeed(10)
searchTarget()
left()
sleep((rt - lt) * 25)
forward()

while True:
   dist = getDistance()
   print "Distance = " + str(dist)
   if dist < 40:
      stop()
      break
print "done"
