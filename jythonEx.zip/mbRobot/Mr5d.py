# Mq5d.py (receiver)
import radio
from microbit import *
from mbrobot import *

radio.on()
print("ok")
setSpeed(15)
while True:
    rec = radio.receive()    
    if rec == "FORWARD":
        forward()  
    elif rec == "LEFT":
        leftArc(0.1)
    elif rec == "RIGHT":
        rightArc(0.1) 
    elif rec == "STOP":
        stop()     
    sleep(100)
