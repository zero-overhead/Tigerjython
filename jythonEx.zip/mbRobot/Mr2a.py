# Mr2a.py
from mbrobot import *
            
forward()
sleep(2000)
left()
sleep(550)
forward()
sleep(2000)
stop()    


