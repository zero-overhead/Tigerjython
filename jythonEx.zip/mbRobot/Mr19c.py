from mbrobot import *
#from mbrobot_plus import *

setServo("S1", 60)
forward()
repeat:
    d = getDistance()
    print(d)
    if d < 20: 
        stop()
        delay(500)
        setServo("S1", 95)
        delay(500)             
        backward()
        delay(2500)
        left()
        delay(700)      
        stop()
        setServo("S1", 60)
    delay(100)  
