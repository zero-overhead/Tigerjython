# Mr2d.py
from mbrobot import *

repeat 10:
    setLED(1)
    delay(500)
    setLED(0)
    delay(500)

