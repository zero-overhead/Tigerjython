# Mr5b.py (receiver)
import radio
from microbit import *
from mbrobot import *

radio.on()
while not button_a.was_pressed():    
    rec = radio.receive()
    if rec != None:
        if rec == "on":
            ledLeft.write_digital(1)
            ledRight.write_digital(1)
        elif rec == "off":
            ledLeft.write_digital(0)
            ledRight.write_digital(0)
stop()