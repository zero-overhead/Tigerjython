# Mqtt2.py
import mqtt
from mbrobot import *
from microbit import *
host = "broker.hivemq.com"
topic = "/ch/lamp"

mqtt.connectAP("mySSID", "myPassword")
mqtt.broker(host)
mqtt.connect()
mqtt.subscribe(topic)
while True:
    topic, payload = mqtt.receive()
    if topic != None:
        if payload == "on":
            ledLeft.write_digital(1)
            ledRight.write_digital(1)
            display.show(Image.YES)
        elif payload == "off":
            ledLeft.write_digital(0)
            ledRight.write_digital(0)
            display.show(Image.NO)
    sleep(1000)