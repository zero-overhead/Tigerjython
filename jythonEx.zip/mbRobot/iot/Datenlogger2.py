#Datenlogger2.py
from microbit import *
from linkup import *
from mbrobot import *
import sht
import ntptime, utime

def synchTime():
    Wlan.connect(ssid, pwd)
    ntptime.settime()
    Wlan.disconnect()

def sendMail(log): 
    Wlan.connect(ssid, pwd)
    client = HTTPClient()
    client.connect(host, port)
    request = inquiry + log
    print(request)
    reply = client.sendGetRequest(request)
    print(reply)
    client.closeConnection()
    Wlan.disconnect()

ssid = "myssid"
pwd = "mypassword"
host = "maker.ifttt.com"
port = 80
key = "jGKt1Nz6XXRMfJGBhje0_FFWXMecvWkEs5wwSQ"
inquiry = "/trigger/MyLogger/with/key/" + key + "?value1="
synchTime()
logFile = "data.txt"
f = open(logFile, "w") 
ready = True
while True:
    t, h = sht.getValues()
    temp = int(t + 0.5)
    yy, mm, dd, h, m, s, w, b = utime.localtime()
    f.write("%02d:%02d:%02d;%02d<br>" %(h, m, s, temp))
    display.scroll(temp)
    if m % 5 == 0 and ready:
        insertBigChar(">", GREEN)
        ready = False
        f.close()
        f = open(logFile)
        log = f.read()
        sendMail(log)
        f.close()
        f = open(logFile, "w") 
    if m % 5 == 1 and not ready:
        ready = True
    sleep(100)    