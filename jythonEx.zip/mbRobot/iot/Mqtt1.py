# MQTTDist.py
import mqtt
from microbit import *
from mbrobot import *

host = "broker.hivemq.com" 
topic = "/ch/mbrobot"

mqtt.connectAP("mySSID", "myPassword")
mqtt.broker(host)
mqtt.connect()
while True:
    dist = getDistance() 
    print(dist)
    mqtt.publish(topic, "Distance: " + str(dist))
    sleep(5000)
