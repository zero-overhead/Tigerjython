# WebServer2.py
from linkup import *
from mbrobot import *
from music import *

def onRequest(clientIP, filename, params):
    if filename == "/jump_up":
        play(JUMP_UP)      
    elif filename == "/jump_down":
        play(JUMP_DOWN)

ipAddress = connectAP(ssid = "xxx", password = "yyy")
display.scroll(ipAddress, wait = False)
startHTTPServer(onRequest)       
