# Datenlogger1.py
from microbit import *
from linkup import *
from mbrobot import *
import sht

alarmTemp = 28
alarmRearmTemp = 27
host = "maker.ifttt.com"
port = 80
key = "oPn2kQcK5zgWtX_eR4JB6LKAc9xcpN6lm5WRty"
inquiry = "/trigger/overheat/with/key/" + key + "?value1=%d"
Wlan.connect("myssid", "mypassword")
client = HTTPClient()
alarmArmed = True
while True:
    t, h = sht.getValues()
    temp = int(t + 0.5)
    display.scroll(temp)
    if alarmArmed:
        if temp >= alarmTemp:
            print("Triggering alarm")
            alarmArmed = False
            insertBigChar(">", RED)
            client.connect(host, port)
            request = inquiry % temp
            print(request)
            reply = client.sendGetRequest(request)
            print(reply)
            client.closeConnection()
    else:    
       if temp < alarmRearmTemp:
           print("Rearming alarm")
           alarmArmed = True 
           insertBigChar("<", GREEN)
           sleep(100)