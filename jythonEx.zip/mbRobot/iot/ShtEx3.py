# ShtEx3.py
from linkup import *
from microbit import *
import sht

def onRequest(clientIP, filename, params):
   temp, humi = sht.getValues()
   return [temp, humi]

createAP(ssid="mbRobot", password="")
startHTTPServer(onRequest)