# ShtEx2.py

from linkup import *
from microbit import *
import sht

def onRequest(clientIP, filename, params):
   temp, humi = sht.getValues()
   return [temp]

ipAddress = connectAP(ssid = "MySSID", password = "pw")
display.scroll(ipAddress, wait = False)
startHTTPServer(onRequest)

