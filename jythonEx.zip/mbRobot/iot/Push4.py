# Push4.py
from microbit import *
from linkup import *

def sendNotification(v):
    print("Sending push notification")
    connectAP("mySSID", "MyPassword")
    url  = "https://api.pushover.net/1/messages.json"
    message = "Movement detected"
    content = "token=%s&user=%s&title=%s&message=%s"  %(token, user, title, message)
    httpPost(url, content)

token = "amnvfdsnj5zo9h4v8okpc5ug74desn"
user = "kjugfhdp6qe8pqynnejrm6wx8fi36098"
title =  "motion detector"
state = "IDLE"

while True:
    v = pin2.read_analog()
    print(v) 
    if v > 500 and state =="IDLE":
        sendNotification(v)         
    if v < 200 and state == "ALARM":
        state = "IDLE"
    sleep(500)