# ThingSpeekDel.py
from linkup import *

channelId = "123456"
userKey = "A4YKXGJEIC8J1L48"

connectAP("myssid", "mypassword")
url = "https://api.thingspeak.com/channels/" + channelId + "/feeds.json?api_key=" + userKey
httpDelete(url)