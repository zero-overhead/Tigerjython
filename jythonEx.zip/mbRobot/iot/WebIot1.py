# WebIot1.py
from linkup import *
from mbrobot import *

def onRequest(clientIP, filename, params):
   d = getDistance()
   return d

ipAddress = connectAP(ssid = "xx", password = "yy")
display.scroll(ipAddress, wait = False)
startHTTPServer(onRequest)

      
                
