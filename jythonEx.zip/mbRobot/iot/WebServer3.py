# WebServer3.py
from linkup import *
from mbrobot import *

def onRequest(clientIP, filename, params):
    if filename == "/on":
        ledLeft.write_digital(1)
        ledRight.write_digital(1)
    elif filename == "/off":
        ledLeft.write_digital(0)
        ledRight.write_digital(0)

ipAddress = connectAP(ssid = "xx", password = "yy")
display.scroll(ipAddress, wait = False)
startHTTPServer(onRequest)
