# Mqtt4.py

from microbit import *
import mqtt, rtc, gc
import sht

host = "broker.hivemq.com"

while True:
    try:
        gc.collect()
        display.show('L')     
        if mqtt.connectAP("raspilink", "aabbaabbaabb"):
            display.show('B')      
            mqtt.broker(host)
            if mqtt.connect():
                while True:
                    display.show(Image.ARROW_E)
                    temp, humi = sht.getValues() 
                    tme = rtc.get()
                    payload_date = "%d.%d\n%02d:%02d" %(tme[2], tme[1], tme[3], tme[4])
                    if not (mqtt.publish("/ch/home/date", payload_date) and 
                            mqtt.publish("/ch/home/temp", "%.1f" % temp) and 
                            mqtt.publish("/ch/home/humi", "%.1f%%" % humi)):
                        display.show('e')
                        sleep(3000)
                        break
                    sleep(2000)
                    s = " : : %.1f - %.1f" % (temp, humi)
                    for _ in range(3):
                        display.scroll(s)
            else:
                display.show('b')
                sleep(3000)
        else:
            display.show('l')
            sleep(3000)
    except:
        display.show('z')
        sleep(3000)
