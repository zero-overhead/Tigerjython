from linkup import *

token = "aeqskdsnj5zo9h4v8okpc5ug74desn"
user = "u781hdp6qe8pqynnejrm6wx8fi36q6"
title =  "micro:bit"
message = "Greetings from mbRobot"

connectAP("raspi", "112211221122")
url  = "https://api.pushover.net/1/messages.json"
content = "token=%s&user=%s&title=%s&message=%s"  %(token, user, title, message)
response = httpPost(url, content)
print("response:", response)

