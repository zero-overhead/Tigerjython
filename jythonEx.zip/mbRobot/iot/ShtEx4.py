#ShtEx4.py
from microbit import *
import sht
import oled

oled.init()
while True:
   temp, humi = sht.getValues()
   print(temp, humi)
   oled.text(0, 0, "Temp:" + str(temp))
   oled.text(0, 1, "Humi:" + str(humi))
   sleep(500)