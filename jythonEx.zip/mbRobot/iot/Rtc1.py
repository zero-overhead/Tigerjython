# Rtc1.py
import rtc
from microbit import *
    
rtc.set(2019, 7, 11, 14, 55, 20, 2)
 
while True:
    data = rtc.get()
    display.scroll("%02d:%02d:%02d" % (data[3], data[4], data[5]))
    sleep(10000)
