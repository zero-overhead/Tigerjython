# SaveHTMLIot2.py
from linkup import *

html = """<!DOCTYPE html>
<html>
  <head> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="5">
  </head>
  <body> 
     <h2>Remote services</h2>
     Current humidity: %s<br>
  </body>
</html>
"""

print("Saving HTML...")
saveHTML(html)
print("Done")

