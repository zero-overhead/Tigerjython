#ShtEx1.py

from microbit import *
import sht

while True:
   temp, humi = sht.getValues()
   print(temp, humi)
   display.scroll(str(temp))
   sleep(200)