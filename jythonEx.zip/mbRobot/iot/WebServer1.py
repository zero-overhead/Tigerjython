# WebServer1.py
from linkup import *
from mbrobot import *

def onRequest(clientIP, filename, params):   
    return

ipAddress = connectAP(ssid = "mySSID", password = "myPassword")
display.scroll(ipAddress, wait = False)
startHTTPServer(onRequest)   