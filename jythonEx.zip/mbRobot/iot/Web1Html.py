# Web1Html.py: SaveHtmlWeb1
from linkup import *

html = """<!DOCTYPE html>
<html>
  <head> <title>LinkUp</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body> 
     <h1>Welcome to the MicroBit</h1>
     <b>Press to change light state:</b>
     <form method="get">
       <input type="submit" style="font-size: 50px; 
           height: 100px; width: 150px" name="light" value="ON" />
       <input type="submit" style="font-size: 50px; 
           height: 100px; width: 150px" name="light" value="OFF" />
     </form>
     <br>
    Current light state: %s<br>
  </body>
</html>
"""
print("Saving HTML...")
saveHTML(html)
print("Done")
