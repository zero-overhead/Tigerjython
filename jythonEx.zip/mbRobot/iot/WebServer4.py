# WebServerWeb4.py 
from linkup import *
from mbrobot import *

def onRequest(clientIP, filename, params):
    if 'btn' in params:
        state = params['btn']
        if state == 'Left':
            leftArc(0.1) 
        elif state == 'Right':
            rightArc(0.1) 
        elif state == 'Forward':
            forward()    
        elif state == 'Back':
            backward()    
        elif state == 'Stop':
            stop()    
    else:
        state = 'Stop' 
    display.show(state[0])
    return [state]

stop()
createAP(ssid = "mbRobot", password = "")
startHTTPServer(onRequest)
      
                
