# SaveHTMLWeb2.py
from linkup import *

html = """<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body> 
    <h2>Welcome to the mbRobot</H2>
     <p><a href="jump_up">Play JUMP_UP </a></p>
     <p><a href="jump_down">Play JUMP_DOWN</a></p>
</body>
</html>
"""   

print("Saving HTML...")
saveHTML(html)