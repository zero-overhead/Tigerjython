# SmartHome5.py
from microbit import *
import mqtt, sys

host = "broker.hivemq.com" 
topic_switch = "/ch/lamp"
topic_state = "/ch/lamp/state"
pin0.write_digital(0)
display.show(Image.NO)
while True:
    try:
        print("Connecting to AP...")      
        if mqtt.connectAP("mySSID", "myPassword"):
            print("OK. Connecting to broker...")      
            mqtt.broker(host)
            if mqtt.connect():
                print("OK. Connection to broker established")      
                mqtt.subscribe(topic_switch)
                count = 0
                state = "OFF"
                while True:
                    count += 1
                    if count % 10 == 0:
                        print("Publishing topic:", topic_state, "payload:", state)
                        if not mqtt.publish(topic_state, state):
                            print("Error. Publish failed")
                            break
                    data = mqtt.receive()
                    if data == None:
                        print("Error. Connection to broker lost")
                        break    
                    topic, payload = data
                    if topic != None:
                        print("Got topic:", topic, "payload:", payload)
                        if payload == "on":
                            pin0.write_digital(1)
                            display.show(Image.YES)
                            state = "ON"
                        elif payload == "off":
                            pin0.write_digital(0)
                            display.show(Image.NO)
                            state = "OFF"
                    sleep(1000)
            else:
                print("Error. Broker unreachable")      
        else:
            print("Error. Can't connect to AP")      
    except Exception as e:
        sys.print_exception(e)
