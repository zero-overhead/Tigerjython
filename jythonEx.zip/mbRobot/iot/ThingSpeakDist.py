# ThingSpeakDist.py
from microbit import *
from linkup import *
from mbrobot import *

key = "771FPOXESR6L8WU0"
print("Sending AP connection command")
connectAP("raspi", "112211221122")
while True:
    dist = getDistance()
    print("Sending new distance:", dist)
    url = "http://api.thingspeak.com/update?api_key=" + key + "&field1=" + str(dist)
    httpGet(url)    
    sleep(15000)
                              
                 
