# SmartHome3.py
from microbit import *
from linkup import *

def onRequest(clientIP, filename, params):
    if filename == "/on":
        pin0.write_digital(1)
        display.show(Image.YES)
    elif filename == "/off":
        pin0.write_digital(0)
        display.show(Image.NO)

ipAddress = connectAP(ssid = "mySSID", password = "myPassword")
display.scroll(ipAddress)
pin0.write_digital(0)
display.show(Image.NO)
startHTTPServer(onRequest)
