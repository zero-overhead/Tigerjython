# ThingSpeakFeeds.py
import urllib2
from gpanel import *

makeGPanel(-2, 22, -600, 600)
drawGrid(0, 20, -500, 500)
x = 0

readKey = "LGHJ1UDKXABYCIJ"
channelID = "4924629"

url = "http://api.thingspeak.com/channels/"+channelID+"/feeds.json?api_key="+readKey+"&results=100" 
data = urllib2.urlopen(url).read()
dataDict = eval(data)
print dataDict
feeds = dataDict['feeds']
for feed in feeds:
    a = feed['field1']
    y = int(a)
    if x == 0:
        pos(x, y)
    else:
        draw(x, y)
    x += 1