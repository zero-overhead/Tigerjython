# Rtc3.py
from microbit import *
import linkup
import ntptime
import rtc

print("Requesting time...")
linkup.connectAP("raspilink", "aabbaabbaabb")
tme = ntptime.getTimeRaw()
print("Got:", tme)
rtc.set(tme)
 
while True:
    data = rtc.get()
    display.scroll("%02d:%02d:%02d" % (data[3], data[4], data[5]))
    sleep(10000)
