# ThingSpeakAcc.py
from microbit import *
from linkup import *
from mbrobot import *

key = "771FPOXESR6L8WU0"
print("Sending AP connection command")
connectAP("raspi", "112211221122")
while True:
    acc = accelerometer.get_x()
    print("Sending acc:", acc)
    url = "http://api.thingspeak.com/update?api_key=" + key + "&field1=" + str(acc)
    response = httpGet(url)
    print("Response:", response)
    sleep(5000)
                              
