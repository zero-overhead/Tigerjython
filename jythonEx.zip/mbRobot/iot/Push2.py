# Push2.py
from linkup import *
from mbrobot import *

token = "aeqskhjloizzo9h4v8okpc5ug74desn"
user = "u781hdp6qe8oiuznnejrm6wx8fi36q6"
title =  "movement detector"

def sendNotification(distance):
    print("Sending push notification")
    connectAP("mySSID", "myPassword")
    url  = "https://api.pushover.net/1/messages.json"
    message = "Object detected. Distance: " + str(distance)
    content = "token=%s&user=%s&title=%s&message=%s"  %(token, user, title, message)
    httpPost(url, content)

while True:
    d = getDistance()
    print(d)
    if 50 < d < 500:
        sendNotification(d)
    sleep(10000)    