# Puah3.html
from linkup import *
from mbrobot import *

token = "aeqsgkdrnj5zo9h4v8okpc5ug74desn"
user = "jlutg81hdp6qe8pqynnejrm6wx8fi36q6"
title =  "mbRobot"

def sendNotification(distance):
    print("Sending push notification")
    connectAP("mySSID", "myPassword")
    url  = "https://api.pushover.net/1/messages.json"
    message = "I need water!"
    content = "token=%s&user=%s&title=%s&message=%s"  %(token, user, title, message)
    httpPost(url, content)

while True:
    v = pin1.read_analog()
    print(v)
    if v < 500:
        sendNotification(v)
        break
    sleep(1000)    