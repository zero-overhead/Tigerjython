from microbit import *
from mbrobot import *
from music import *

state = "IDLE"

while True:
    v = pin2.read_analog()
    print(v) 
    if v > 500 and state =="IDLE":
        state = "ALARM" 
        play(JUMP_UP)
    if v < 200 and state == "ALARM":
        state = "IDLE"
    sleep(500)