# SaveHTMLWeb1.py
from linkup import *

html = """<!DOCTYPE html>
<html>
  <head> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body> 
     <h2>Welcome to the mbRobot</h2>
     <p>My first homepage.</p>     
  </body>
</html>
"""

print("Saving HTML...")
saveHTML(html)
print("Done")