# SmartHome4.py
from microbit import *
import mqtt

host = "broker.hivemq.com" 
topic = "/ch/lamp"

mqtt.connectAP("mySSID", "myPassword")
mqtt.broker(host)
mqtt.connect()
mqtt.subscribe(topic)
pin0.write_digital(0)
display.show(Image.NO)
count = 0
while True:
    count += 1
    if count % 10 == 0:
        mqtt.ping()    
    topic, payload = mqtt.receive()
    if topic != None:
        if payload == "on":
            pin0.write_digital(1)
            display.show(Image.YES)
        elif payload == "off":
            pin0.write_digital(0)
            display.show(Image.NO)
    sleep(1000)
