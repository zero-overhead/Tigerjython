# SaveHTMLShtEx3.py
from linkup import *

html = """<!DOCTYPE html>
<html>
  <head> 
    <title>Sensirion</title> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="5">
  </head>
  <body> 
     <h1>Sensirion</h1>
     Temperature, humi: %s,%s<br>
  </body>
</html>
"""

print("Saving HTML...")
saveHTML(html)
print("Done")