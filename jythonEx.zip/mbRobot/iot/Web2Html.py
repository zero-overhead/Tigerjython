# SaveHTMLWeb2.py
from linkup import *

html = """<!DOCTYPE html>
<html>
  <head> <title>LinkUp</title> 
  <meta http-equiv="refresh" content="10">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body> 
     <h1>Welcome to the MicroBit</h1>
      Current humidity  %s<br>
  </body>
</html>
"""

print("Saving HTML...")
saveHTML(html)
print("Done")
