# SaveHTMLWeb4.py (RemoteRover)
from linkup import *

html = """<!DOCTYPE html>
<html>
  <head> <title>MicroBit Rover</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body> 
    <h1>MicroBit Rover</h1>
    <form method="get">
    <table>
    <tr>
      <td></td>
      <td><input type="submit" style="font-size:22px; height:50px; 
           width:110px" name="btn" value="Forward"/></td>
      <td></td>
    </tr>
    <tr>
      <td><input type="submit" style="font-size:22px; height:50px;
           width:110px" name="btn" value="Left"/></td>
      <td><input type="submit" style="font-size:22px; height:50px;
           width:110px" name="btn" value="Stop"/></td>
      <td><input type="submit" style="font-size:22px; height:50px;
           width:110px" name="btn" value="Right"/></td>
    </tr>
    <tr>
      <td></td>
      <td><input type="submit" style="font-size:22px; height:50px;
           width:110px" name="btn" value="Back"/></td>
      <td></td>
    </tr>
    </table>
    </form><br>
    Current state: %s<br>
  </body>
</html>
"""

print("Saving HTML...")
saveHTML(html)
print("Done")
