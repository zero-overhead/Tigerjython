# WebIot2.py
from linkup import *
from mbrobot import *
from microbit import *

def onRequest(clientIP, filename, params):
   v = pin1.read_analog()
   return v

ipAddress = connectAP(ssid = "raspi", password = "112211221122")
display.scroll(ipAddress, wait = False)
startHTTPServer(onRequest)       

                
