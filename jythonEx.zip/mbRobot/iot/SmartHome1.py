# SmarHome1.py
from microbit import *

while True:
    pin0.write_digital(0)
    sleep(10000)
    pin0.write_digital(1)
    sleep(10000)
