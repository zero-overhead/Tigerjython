# SmartHome6GUI.py
from tcpcom import *
from entrydialog import *

url_on = "http://api.thingspeak.com/update?api_key=0IKY85R1E3AO403U&field1=1"
url_off = "http://api.thingspeak.com/update?api_key=0IKY85R1E3AO403U&field1=0"

btn1 = ButtonEntry("On")
btn2 = ButtonEntry("Off")
pane1 = EntryPane(btn1, btn2)
dlg = EntryDialog(pane1)
dlg.setTitle("Remote Lamp Manager")

while not dlg.isDisposed():
    if btn1.isTouched():
        HTTPClient.getRequest(url_on)
    elif btn2.isTouched():
        HTTPClient.getRequest(url_off)
