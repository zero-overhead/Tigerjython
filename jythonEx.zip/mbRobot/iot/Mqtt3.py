# MQTT3.py
import mqtt
from microbit import *
from music import *

host = "broker.hivemq.com" 
topic = "/ch/pir"
mqtt.connectAP("mySSID", "myPassword")
mqtt.broker(host)
mqtt.connect()
pitch(1000, 100)
state = "IDLE"
while True:
    v = pin2.read_analog()    
    if v > 500 and state =="IDLE":
        state = "ALARM"
        mqtt.publish(topic, state)
        play(JUMP_UP)       
    if v < 200 and state == "ALARM":    
        state = "IDLE" 
        mqtt.publish(topic, state)
        play(JUMP_DOWN)              
    sleep(500)