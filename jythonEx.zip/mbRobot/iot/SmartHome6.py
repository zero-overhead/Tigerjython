# SmartHome6.py
from linkup import *
from microbit import *

readKey = "B1DYQZUGF0H3UZSL"
channelID = "802864"

def extractValue(response):
    try:
        start = response.find('{')
        end = response.rfind('}')
        dataDict = eval(response[start : end + 1])
        return dataDict['feeds'][0]['field1']
    except:
        return ""

pin0.write_digital(0)
display.show(Image.NO)
print("Connecting to AP...")
if connectAP("MySSID", "MaPassword"):
    print("Connecting to AP successful")
    while True:
        url = "http://api.thingspeak.com/channels/"+channelID+"/feeds.json?api_key="+readKey+"&results=1" 
        response = httpGet(url)
        print("got response:", response)
        value = extractValue(response)
        print("got value:", value)
        if value == '1':
            pin0.write_digital(1)
            display.show(Image.YES)
        elif value == '0':
            pin0.write_digital(0)
            display.show(Image.NO)
        sleep(5000)
else:
    print("Connection to AP failed")
    display.show(Image.SAD)
