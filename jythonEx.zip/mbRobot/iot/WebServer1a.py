# WebServer1a.py
from linkup import *
from mbrobot import *

def onRequest(clientIP, filename, params):   
    return

createAP(ssid = "mbRobot", password = "")
startHTTPServer(onRequest)   