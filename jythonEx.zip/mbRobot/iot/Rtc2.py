# Rrc2.py
import linkup
import ntptime

linkup.connectAP("raspilink", "aabbaabbaabb")
data = ntptime.getTimeRaw()
print("Current time raw:", data)
data = ntptime.getTime("ch.pool.ntp.org")
print("Current time:", data)
