from maqueen import *
from microbit import *

while True:
    d = getDistance()
    print(d)
    sleep(200)
