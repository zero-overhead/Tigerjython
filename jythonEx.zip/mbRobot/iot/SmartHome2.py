# SmartHome2.py
from microbit import *

pin1.write_digital(0)

while True:
    v = pin0.read_analog()
    print(v)
    if v < 200:
        pin1.write_digital(1)
        display.show(Image.YES)
    if v > 250:
        pin1.write_digital(0)
        display.show(Image.NO)
    sleep(100)

