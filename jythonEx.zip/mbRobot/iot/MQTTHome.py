# MQTTHome.py

import mqtt
from mbrobot import *
from microbit import *

broker = "broker.hivemq.com"
topic = "/ch/home"

mqtt.connectAP("raspi", "112211221122")
rc = mqtt.connect(broker)
mqtt.subscribe(topic)
while True:
    topic, payload = mqtt.receive()
    if topic != None:
        if payload == "on":
            ledLeft.write_digital(1)
            ledRight.write_digital(1)
            display.show(Image.YES)
        elif payload == "off":
            ledLeft.write_digital(0)
            ledRight.write_digital(0)
            display.show(Image.NO)
    sleep(1000) 