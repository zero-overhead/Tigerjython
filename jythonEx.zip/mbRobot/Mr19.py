from mbrobot import*
#from mbrobot_plus import *

setServo("S1", 160)
delay(2000)
setServo("S1", 100)
delay(2000)          
setServo("S1", 160)
         
      

    

