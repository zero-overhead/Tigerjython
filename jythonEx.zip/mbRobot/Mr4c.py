# Mr4c.py
from microbit import *
from mbrobot import *

setSpeed(15)
forward()
while not button_a.was_pressed():
    d = getDistance()
    if d < 10:
        backward()
        sleep(1000) 
        forward()
    sleep(200)
stop()    