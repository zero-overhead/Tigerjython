from mbrobot import *
#from mbrobot_plus import *

setServo("S1", 95)
delay(1000)
setServo("S1", 60)
forward()
delay(1000)
stop()
setServo("S1", 95)
backward()
delay(500)
left()
delay(700)
stop()
setServo("S1", 60)
  
   
