# Mr4a.py
from mbrobot import *
from microbit import *

def blink(led):
    led.write_digital(1)
    sleep(200)
    led.write_digital(0)    
    sleep(200)

while True:
    if button_a.is_pressed():
        blink(ledRight)
    if button_b.is_pressed():
        blink(ledLeft)    
    sleep(200)    
