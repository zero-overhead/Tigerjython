# Mr2e.py
from mbrobot import *
           
repeat 2:
    leftArc(0.15)
    ledLeft.write_digital(1)
    ledRight.write_digital(0)    
    sleep(3000)
    rightArc(0.15)
    ledLeft.write_digital(0)
    ledRight.write_digital(1)
    sleep(3000)
ledRight.write_digital(0)
stop()    

