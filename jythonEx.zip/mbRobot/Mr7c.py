#Mr7c.py
from microbit import *

if not compass.is_calibrated():
    print("Perform calibration please!")
    compass.calibrate()

while True:
    h = compass.heading()
    print(h)
    if h >= 22.5 and h < 67.5:
        display.show(Image.ARROW_NW) 
    elif h >= 67.5 and h < 112.5:
        display.show(Image.ARROW_W)    
    elif h >= 112.5 and h < 157.5:
        display.show(Image.ARROW_SW)    
    elif h >= 157.5 and h < 202.5:
        display.show(Image.ARROW_S)    
    elif h >= 202.5 and h < 247.5:
        display.show(Image.ARROW_SE) 
    elif h >= 247.5 and h < 292.5:
        display.show(Image.ARROW_E)          
    elif h >= 292.5 and h < 337.5:
        display.show(Image.ARROW_NE)
    else:
        display.show(Image.ARROW_N)
    sleep(10) 