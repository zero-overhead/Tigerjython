# Mq6b.html (receiver)
from microbit import *
from mbrobot import *
import radio

def fd():
    forward()
    sleep(moveTime)
    stop()
    
def run():
    for k in memory:
            if k == 0:
                left()
                sleep(turnTime)                
            elif k == 1:         
                right()
                sleep(turnTime)
            fd()

moveTime = 1000
turnTime = 500
radio.on()
setSpeed(20)
memory= []
while not button_a.was_pressed():   
    rec = radio.receive()    
    if rec == "LEFT":
        memory.append(0)
        left()
        sleep(turnTime)
        fd()
    elif rec == "RIGHT":
        memory.append(1)
        right() 
        sleep(turnTime)
        fd()
    else:    
        stop() 
run()            
exit()