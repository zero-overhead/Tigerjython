from mbrobotmot import *

motL.rotate(50)
delay(3000)
motL.rotate(-30)
delay(2000)
motL.rotate(0)