# Mr3b.py
from mbrobot import *

setSpeed(10)
while True:
    d = getDistance()
    if d < 10:
        backward()
    elif d >= 10 and d < 40: 
        forward()
    else:
        stop()
    sleep(100)    
    