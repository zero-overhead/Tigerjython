# Mr2b.py
from mbrobot import *
            
repeat 4: 
    forward()
    sleep(2000)
    left()
    sleep(550)
stop()    


