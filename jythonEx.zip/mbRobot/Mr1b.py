from mbrobot import *

repeat:
    d = getDistance()
    print(d)    
    sleep(200)
