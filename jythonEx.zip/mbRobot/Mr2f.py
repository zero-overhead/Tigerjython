# Mr2f.py
from music import *
 
repeat 10: 
    pitch(524, 400)            
    pitch(784, 400)    




