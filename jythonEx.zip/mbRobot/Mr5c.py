#Mq5c.py
from microbit import *
import radio

radio.on()
state = "STOP"
oldState = ""
while True:
    if button_a.is_pressed() and button_b.is_pressed():
        state = "FORWARD" 
        display.show('F')
    elif button_a.is_pressed():
        state = "LEFT"
        display.show('L')
    elif button_b.is_pressed():
        state = "RIGHT"
        display.show('R')
    else:
        state = "STOP"
        display.show('S')
    if oldState != state:
        radio.send(state)
        oldState = state
    sleep(10)  
