# Mr3d.py 
from mbrobot import *

RobotContext.setStartPosition(250, 250)
RobotContext.setStartDirection(-90)
RobotContext.useBackground("sprites/track.gif")

state = "GOTRACK"

#setSpeed(10)
while True:
    left = irLeft.read_digital()
    right = irRight.read_digital()
    if left == 0 and right == 0 and state != "FORWARD":  
        forward()
        state = "FORWARD"
    elif left == 0 and right == 1 and state != "LEFT":
        leftArc(0.1)
        state = "LEFT"
    elif left == 1 and right == 0 and state != "RIGHT":
        rightArc(0.1)
        state = "RIGHT"
    elif left == 1 and right == 1:  # out of track
        if state == "LEFT":
            leftArc(0.1)
        elif state == "RIGHT":
            rightArc(0.1)
        state = "GOTRACK"
    sleep(100)
