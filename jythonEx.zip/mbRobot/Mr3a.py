# Mr3a.py
from mbrobot import *

mesh_hbar = [[200, 10], [-200, 10], [-200, -10], [200, -10]]
RobotContext.useTarget("sprites/bar0.gif", mesh_hbar, 250, 100)

forward()
while True:
    d = getDistance()
    print(d)
    if d < 20:
        backward()
        sleep(2000)
        forward()
    sleep(100)