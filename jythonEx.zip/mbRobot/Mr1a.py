from mbrobot import *
            
forward()
sleep(2000)
stop() 



