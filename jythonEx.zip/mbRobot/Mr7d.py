from microbit import *

while True:
    b = compass.get_field_strength()
    z = min(9, int(b / 500000)) # brightness
    display.set_pixel(2, 2, z)
    sleep(10)