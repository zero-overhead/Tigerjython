from mbrobot import *
#from mbrobot_plus import *

setServo("S2", 90)
delay(2000)
setServo("S2", 0)
delay(2000)
setServo("S2", 90)
delay(2000)

angle = 90
while angle >= 0:
    setServo("S2", angle)
    delay(500)
    angle = angle - 10
    
angle = 0
while angle <= 90:
    setServo("S2", angle)
    delay(500)
    angle = angle + 10 

