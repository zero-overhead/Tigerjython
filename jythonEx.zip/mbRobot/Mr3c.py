# Mr3c.py
from mbrobot import *

RobotContext.useBackground("sprites/circle.gif")

#setSpeed(15)
forward()
while True:
    v1 = irLeft.read_digital()
    v2 = irRight.read_digital()
    if v1 == 0 or v2 == 0:
        backward()
        sleep(1400)
        forward()
        left()
        sleep(550)
        forward()        
    sleep(100)

