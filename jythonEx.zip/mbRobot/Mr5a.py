#Mq5a.py (send)
from microbit import *
import radio

radio.on()
while True:
    if button_a.was_pressed():
        radio.send("on")
    elif button_b.was_pressed():
        radio.send("off")