#Mq6a.py
from microbit import *
import radio

radio.on()
state = "STOP"
oldState = ""
while True:
    if button_a.was_pressed():
        state = "LEFT"
        display.show('L')
    elif button_b.was_pressed():
        state = "RIGHT"
        display.show('R')
    else:
        state = "STOP"
        display.show('S')
    if oldState != state:
        radio.send(state)
        oldState = state   
    sleep(10)