# Mr4b.py
from microbit import *
from mbrobot import *
from music import *

def blink():
    ledLeft.write_digital(1)
    ledRight.write_digital(1)
    sleep(500)
    ledLeft.write_digital(0)
    ledRight.write_digital(0)
    sleep(500)

while True:
    if button_a.was_pressed():
        play(JUMP_UP)
    if button_b.was_pressed():
        play(JUMP_DOWN)    
    blink()

