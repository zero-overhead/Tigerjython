# Mr7a.py
from microbit import *

while True:
    v = pin0.read_analog()
    print(v)   
    sleep(500)
